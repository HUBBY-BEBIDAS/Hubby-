"use client";

import { useEffect, useState, useCallback, useMemo } from "react";
import { useParams, useRouter } from "next/navigation";
import { useSession } from "next-auth/react";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { Navbar } from "@/components/Navbar";
import { useApiToken, apiFetch } from "@/hooks/useApiToken";

// ─── Tipos da API ─────────────────────────────────────────────────────────────

type MatchedItem = {
  quotation_item_name: string;
  quotation_item_brand: string;
  product_name: string;
  quantity: number;
  unit_price_cents: number;
  total_price_cents: number;
  price_change_pct: number | null;
};

type RankingEntry = {
  distributor_id: string;
  company_name: string;
  whatsapp_commercial: string;
  email_commercial: string;
  total_cents: number;
  total_brl: string;
  all_items_available: boolean;
  matched_items: MatchedItem[];
  unmatched_items: string[];
  estimated_delivery_date: string;
  total_business_days: number;
  within_deadline: boolean;
  price_updated_at: string;
  status: "within_deadline" | "out_of_deadline";
  average_rating: number | null;
  review_count: number;
};

type RankingResult = {
  within_deadline: RankingEntry[];
  out_of_deadline: RankingEntry[];
  quotation_id: string;
  delivery_city: string;
  delivery_state: string;
  from_cache: boolean;
};

// ─── Tipos da view por produto ────────────────────────────────────────────────

type ProductOffer = {
  key: string; // "distributorId:itemIndex" — chave de seleção
  distributor_id: string;
  company_name: string;
  whatsapp_commercial: string;
  unit_price_cents: number;
  total_price_cents: number;
  quantity: number;
  product_name: string;
  quotation_item_name: string;
  estimated_delivery_date: string;
  total_business_days: number;
  within_deadline: boolean;
  average_rating: number | null;
  review_count: number;
  price_change_pct: number | null;
};

type ProductGroup = {
  quotation_item_name: string;
  quantity: number;
  offers: ProductOffer[];       // ordenadas conforme filtro ativo
  cheapestCents: number;        // menor preço entre todas as ofertas
};

type SortBy = "cheapest" | "most_expensive" | "fastest";

// ─── Helpers ──────────────────────────────────────────────────────────────────

function formatBRL(cents: number) {
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(cents / 100);
}

function buildWhatsAppUrl(
  entry: RankingEntry,
  items: MatchedItem[],
  totalCents: number,
  city: string
): string {
  const lines = items.map(
    (item) =>
      `• ${item.product_name} x ${item.quantity} — ${formatBRL(item.unit_price_cents)}/un`
  );
  const message = [
    `Olá, ${entry.company_name}! Quero fazer o seguinte pedido:`,
    ...lines,
    `Total: ${formatBRL(totalCents)}`,
    ``,
    `Poderia confirmar disponibilidade e prazo para ${city}? Obrigado!`,
  ].join("\n");
  const phone = entry.whatsapp_commercial.replace(/\D/g, "");
  return `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
}

function buildEmailUrl(
  entry: RankingEntry,
  items: MatchedItem[],
  totalCents: number,
  city: string
): string {
  const subject = `Cotação de bebidas — ${items.map((i) => i.product_name).join(", ")}`;
  const body = [
    `Olá, ${entry.company_name}!`,
    ``,
    `Gostaria de fazer o seguinte pedido:`,
    ...items.map(
      (i) => `• ${i.product_name} × ${i.quantity} — ${formatBRL(i.unit_price_cents)}/un`
    ),
    ``,
    `Total: ${formatBRL(totalCents)}`,
    ``,
    `Poderia confirmar disponibilidade e prazo de entrega para ${city}?`,
    ``,
    `Obrigado!`,
  ].join("\n");
  return `mailto:${encodeURIComponent(entry.email_commercial)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}

// ─── Indicador de variação de preço ──────────────────────────────────────────

function PriceChangeIndicator({ pct }: { pct: number | null }) {
  if (pct === null || pct === 0) return null;

  const isUp = pct > 0;
  const abs  = Math.abs(pct);
  const label = `${isUp ? "+" : "-"}${abs.toFixed(1)}%`;

  return (
    <span
      title={`${isUp ? "Alta" : "Queda"} de ${abs.toFixed(1)}% em relação à última consulta`}
      className={[
        "inline-flex items-center gap-0.5 rounded-full px-1.5 py-0.5 text-[10px] font-bold leading-none",
        isUp ? "bg-red-100 text-red-600" : "bg-green-100 text-green-700",
      ].join(" ")}
    >
      {isUp ? (
        <svg className="h-2.5 w-2.5" viewBox="0 0 10 10" fill="currentColor">
          <path d="M5 1l4 8H1z" />
        </svg>
      ) : (
        <svg className="h-2.5 w-2.5" viewBox="0 0 10 10" fill="currentColor">
          <path d="M5 9L1 1h8z" />
        </svg>
      )}
      {label}
    </span>
  );
}

// ─── Estado vazio: sem distribuidoras na região ───────────────────────────────

type EmptyRegionProps = {
  city: string;
  state: string;
  email: string;
  onEmailChange: (v: string) => void;
  status: "idle" | "sending" | "done" | "error";
  onSubmit: () => void;
};

function EmptyRegion({ city, state, email, onEmailChange, status, onSubmit }: EmptyRegionProps) {
  return (
    <div className="rounded-3xl border border-[#DBEAFE] bg-white p-8">
      {/* Ícone */}
      <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-[#EFF6FF]">
        <svg className="h-7 w-7 text-[#2563EB]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
            d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
            d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
        </svg>
      </div>

      <h2 className="mb-1 text-center text-lg font-bold text-[#0F172A]">
        Ainda sem distribuidoras em {city} / {state}
      </h2>
      <p className="mb-6 text-center text-sm text-slate-500">
        Ainda não temos distribuidoras cadastradas na sua região. Entre na lista de espera
        e avise quando novas distribuidoras chegarem.
      </p>

      {status === "done" ? (
        <div className="flex flex-col items-center gap-2 rounded-2xl bg-green-50 px-5 py-4">
          <svg className="h-6 w-6 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
          </svg>
          <p className="text-sm font-bold text-green-700">Você entrou na lista de espera!</p>
          <p className="text-xs text-green-600">Te avisaremos quando uma distribuidora chegar em {city}.</p>
        </div>
      ) : (
        <form
          onSubmit={(e) => { e.preventDefault(); onSubmit(); }}
          className="flex flex-col gap-3"
        >
          <div className="flex gap-2">
            <input
              type="email"
              required
              placeholder="Seu melhor e-mail"
              value={email}
              onChange={(e) => onEmailChange(e.target.value)}
              disabled={status === "sending"}
              className="flex-1 rounded-xl border border-[#DBEAFE] bg-[#F5F7FB] px-4 py-2.5 text-sm text-[#0F172A] placeholder-slate-400 outline-none focus:border-[#2563EB] focus:ring-2 focus:ring-[#DBEAFE] disabled:opacity-60"
            />
            <button
              type="submit"
              disabled={status === "sending" || !email}
              className="flex shrink-0 items-center gap-1.5 rounded-xl bg-[#2563EB] px-5 py-2.5 text-sm font-bold text-white transition hover:opacity-90 disabled:opacity-50"
            >
              {status === "sending" ? (
                <span className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
              ) : (
                "Entrar na lista"
              )}
            </button>
          </div>

          {status === "error" && (
            <p className="text-xs text-red-600">Erro ao registrar. Tente novamente.</p>
          )}

          <p className="text-center text-xs text-slate-400">
            Sem spam. Só um aviso quando uma distribuidora chegar na sua cidade.
          </p>
        </form>
      )}
    </div>
  );
}

// ─── Componente principal ─────────────────────────────────────────────────────

export default function RankingPage() {
  useSession({ required: true });
  const { id: quotationId } = useParams<{ id: string }>();
  const router = useRouter();
  const token = useApiToken();

  const [ranking, setRanking] = useState<RankingResult | null>(null);
  const [loadingRanking, setLoadingRanking] = useState(true);
  const [rankingError, setRankingError] = useState("");
  const [sortBy, setSortBy] = useState<SortBy>("cheapest");

  // Seleção: chave "distributorId:itemIndex"
  const [selectedKeys, setSelectedKeys] = useState<Set<string>>(new Set());

  // ── Waitlist ──────────────────────────────────────────────────────────────
  const [waitlistEmail, setWaitlistEmail] = useState("");
  const [waitlistState, setWaitlistState] = useState<"idle" | "sending" | "done" | "error">("idle");

  // ── Fetch ────────────────────────────────────────────────────────────────

  const fetchRanking = useCallback(async () => {
    if (!token) return;
    setLoadingRanking(true);
    setRankingError("");
    setSelectedKeys(new Set());

    const res = await apiFetch(`/api/quotations/${quotationId}/ranking`, {
      method: "GET",
      token,
    });
    const data = await res.json();
    setLoadingRanking(false);

    if (!res.ok) {
      setRankingError(data.error ?? "Erro ao carregar ranking.");
      return;
    }
    setRanking(data as RankingResult);
  }, [token, quotationId]);

  useEffect(() => {
    fetchRanking();
  }, [fetchRanking]);

  // ── Todas as entradas (flat, sem ordenação) ───────────────────────────────

  const allEntries = useMemo(
    () => [
      ...(ranking?.within_deadline ?? []),
      ...(ranking?.out_of_deadline ?? []),
    ],
    [ranking]
  );

  // ── Grupos por produto, com ofertas ordenadas pelo filtro ativo ───────────

  const productGroups = useMemo((): ProductGroup[] => {
    const map = new Map<string, ProductGroup>();

    for (const entry of allEntries) {
      entry.matched_items.forEach((item, itemIndex) => {
        const name = item.quotation_item_name;
        if (!map.has(name)) {
          map.set(name, {
            quotation_item_name: name,
            quantity: item.quantity,
            offers: [],
            cheapestCents: Infinity,
          });
        }
        const group = map.get(name)!;
        group.offers.push({
          key: `${entry.distributor_id}:${itemIndex}`,
          distributor_id: entry.distributor_id,
          company_name: entry.company_name,
          whatsapp_commercial: entry.whatsapp_commercial,
          unit_price_cents: item.unit_price_cents,
          total_price_cents: item.total_price_cents,
          quantity: item.quantity,
          product_name: item.product_name,
          quotation_item_name: item.quotation_item_name,
          estimated_delivery_date: entry.estimated_delivery_date,
          total_business_days: entry.total_business_days,
          within_deadline: entry.within_deadline,
          average_rating: entry.average_rating,
          review_count:   entry.review_count,
          price_change_pct: item.price_change_pct,
        });
        if (item.unit_price_cents < group.cheapestCents) {
          group.cheapestCents = item.unit_price_cents;
        }
      });
    }

    // Ordena as ofertas dentro de cada produto conforme filtro
    for (const group of map.values()) {
      group.offers.sort((a, b) => {
        if (sortBy === "cheapest")       return a.unit_price_cents - b.unit_price_cents;
        if (sortBy === "most_expensive") return b.unit_price_cents - a.unit_price_cents;
        if (sortBy === "fastest")        return a.total_business_days - b.total_business_days;
        return 0;
      });
    }

    return [...map.values()];
  }, [allEntries, sortBy]);

  // Produtos sem nenhuma oferta (constam apenas nos unmatched_items)
  const unavailableProducts = useMemo(() => {
    const available = new Set(productGroups.map((g) => g.quotation_item_name));
    const unavailable = new Set<string>();
    for (const entry of allEntries) {
      entry.unmatched_items.forEach((name) => {
        if (!available.has(name)) unavailable.add(name);
      });
    }
    return [...unavailable];
  }, [productGroups, allEntries]);

  // ── Sugestão inteligente ──────────────────────────────────────────────────
  // Para cada produto: distribuidora com menor unit_price_cents

  const smartSuggestion = useMemo(() => {
    if (productGroups.length === 0) return null;

    type BestOffer = { offer: ProductOffer; entry: RankingEntry };
    const best: BestOffer[] = [];

    for (const group of productGroups) {
      const cheapest = group.offers.reduce((min, o) =>
        o.unit_price_cents < min.unit_price_cents ? o : min
      );
      const entry = allEntries.find((e) => e.distributor_id === cheapest.distributor_id)!;
      best.push({ offer: cheapest, entry });
    }

    const totalCents = best.reduce((s, { offer }) => s + offer.total_price_cents, 0);
    const latestItem = best.reduce((latest, curr) =>
      curr.offer.total_business_days > latest.offer.total_business_days ? curr : latest
    );

    return {
      best,
      totalCents,
      latestDeliveryDate: latestItem.offer.estimated_delivery_date,
    };
  }, [productGroups, allEntries]);

  // ── Funções de seleção ────────────────────────────────────────────────────

  function toggleItem(key: string) {
    setSelectedKeys((prev) => {
      const next = new Set(prev);
      next.has(key) ? next.delete(key) : next.add(key);
      return next;
    });
    // Volta para a fase de seleção se o usuário alterar os itens
    setConfirmPhase(false);
  }

  function applySmartSuggestion() {
    if (!smartSuggestion) return;
    setSelectedKeys(new Set(smartSuggestion.best.map(({ offer }) => offer.key)));
    setConfirmPhase(false);
  }

  const suggestionApplied =
    smartSuggestion !== null &&
    smartSuggestion.best.every(({ offer }) => selectedKeys.has(offer.key)) &&
    selectedKeys.size === smartSuggestion.best.length;

  // ── Agrupamento por distribuidora ─────────────────────────────────────────

  const selectedByDistributor = useMemo(() => {
    const map = new Map<
      string,
      { entry: RankingEntry; items: MatchedItem[]; totalCents: number }
    >();

    for (const key of selectedKeys) {
      const colon = key.indexOf(":");
      const distId = key.slice(0, colon);
      const idx = Number(key.slice(colon + 1));

      const entry = allEntries.find((e) => e.distributor_id === distId);
      if (!entry) continue;
      const item = entry.matched_items[idx];
      if (!item) continue;

      if (!map.has(distId)) map.set(distId, { entry, items: [], totalCents: 0 });
      const group = map.get(distId)!;
      group.items.push(item);
      group.totalCents += item.total_price_cents;
    }

    return map;
  }, [selectedKeys, allEntries]);

  const totalSelectedCents = useMemo(
    () => [...selectedByDistributor.values()].reduce((s, g) => s + g.totalCents, 0),
    [selectedByDistributor]
  );

  // ── Fase do fluxo: seleção → confirmação ─────────────────────────────────

  const [confirmPhase, setConfirmPhase] = useState(false);

  // ── Estado por distribuidora: idle | sending | sent ───────────────────────

  const [distState, setDistState] = useState<Map<string, "idle" | "sending" | "sent">>(
    new Map()
  );
  const [distError, setDistError] = useState<Map<string, string>>(new Map());

  function getDistState(id: string): "idle" | "sending" | "sent" {
    return distState.get(id) ?? "idle";
  }

  // ── Modal de envio ────────────────────────────────────────────────────────

  const [sendModal, setSendModal] = useState<{ distId: string } | null>(null);

  // Distribuidoras com credencial já confirmada como aprovada nesta sessão
  const [approvedCredentials, setApprovedCredentials] = useState<Set<string>>(new Set());

  // ── Registra o pedido na API ──────────────────────────────────────────────
  // send_channel controla se email/whatsapp server-side disparam.
  // Retorna o resultado da API ou null em caso de erro.

  async function registerOrder(
    distId: string,
    send_channel: "whatsapp" | "email" | "both"
  ): Promise<{ credential_status: string } | null> {
    if (!token || !ranking) return null;
    const group = selectedByDistributor.get(distId);
    if (!group) return null;

    setDistState((prev) => new Map(prev).set(distId, "sending"));
    setDistError((prev) => { const n = new Map(prev); n.delete(distId); return n; });

    try {
      const res = await apiFetch(`/api/quotations/${quotationId}/send`, {
        method: "POST",
        token,
        body: JSON.stringify({
          orders: [
            {
              distributor_id: distId,
              items: group.items.map((i) => ({
                product_name: i.product_name,
                brand: i.quotation_item_brand,
                category: "other",
                packaging: "",
                quantity: i.quantity,
                unit_price_cents: i.unit_price_cents,
              })),
              total_cents: group.totalCents,
              estimated_delivery_date: group.entry.estimated_delivery_date,
              send_channel,
            },
          ],
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        setDistState((prev) => new Map(prev).set(distId, "idle"));
        setDistError((prev) =>
          new Map(prev).set(distId, data.error ?? "Erro ao registrar pedido.")
        );
        return null;
      }

      setDistState((prev) => new Map(prev).set(distId, "sent"));

      // Atualiza mapa de credenciais aprovadas
      const orderResult = data.orders?.[0];
      if (orderResult?.credential_status === "existing" || orderResult?.credential_status === "approved") {
        setApprovedCredentials((prev) => new Set(prev).add(distId));
      }

      return orderResult ?? {};
    } catch {
      setDistState((prev) => new Map(prev).set(distId, "idle"));
      setDistError((prev) =>
        new Map(prev).set(distId, "Erro de conexão. Tente novamente.")
      );
      return null;
    }
  }

  // ── Envia por canal escolhido ─────────────────────────────────────────────
  // Na primeira chamada registra o pedido; nas seguintes só reabre o link.

  async function handleSend(distId: string, channel: "whatsapp" | "email" | "both") {
    if (!ranking) return;
    const group = selectedByDistributor.get(distId);
    if (!group) return;

    const state = getDistState(distId);
    if (state === "sending") return;

    // Registra o pedido apenas uma vez
    if (state === "idle") {
      const result = await registerOrder(distId, channel);
      if (!result) return;
    }

    // WhatsApp: abre wa.me no navegador do comprador
    if (channel === "whatsapp" || channel === "both") {
      window.open(
        buildWhatsAppUrl(group.entry, group.items, group.totalCents, ranking.delivery_city),
        "_blank",
        "noopener,noreferrer"
      );
    }
    // Email: já disparado server-side — sem ação adicional no cliente
  }

  const allSent =
    selectedByDistributor.size > 0 &&
    [...selectedByDistributor.keys()].every((id) => getDistState(id) === "sent");

  // ── Skeleton ──────────────────────────────────────────────────────────────

  if (loadingRanking) {
    return (
      <div className="flex min-h-screen flex-col bg-[#F5F7FB]">
        <Navbar />
        <main className="mx-auto w-full max-w-2xl flex-1 px-4 py-8">
          <div className="mb-4 h-8 w-48 animate-pulse rounded bg-[#DBEAFE]" />
          <div className="mb-6 h-36 animate-pulse rounded-3xl bg-[#2563EB]/20" />
          {[1, 2, 3].map((n) => (
            <div key={n} className="mb-4 h-40 animate-pulse rounded-3xl bg-[#DBEAFE]/50" />
          ))}
        </main>
      </div>
    );
  }

  const selectedCount = selectedKeys.size;

  // ── Fase de confirmação: substitui o conteúdo principal ───────────────────

  if (confirmPhase) {
    return (
      <div className="flex min-h-screen flex-col bg-[#F5F7FB]">
        <Navbar />
        <main className="mx-auto w-full max-w-2xl flex-1 px-4 pb-12 pt-8">

          {/* Cabeçalho da fase de confirmação */}
          <div className="mb-6 flex items-center gap-3">
            <button
              onClick={() => setConfirmPhase(false)}
              className="flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-sm font-medium text-slate-500 hover:bg-[#DBEAFE] hover:text-[#0F172A] transition-colors"
            >
              <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
              Editar seleção
            </button>
            <div className="flex-1">
              <h1 className="text-2xl font-semibold text-[#0F172A]">
                Resumo do pedido
              </h1>
              <p className="text-sm text-slate-500">
                {selectedByDistributor.size} distribuidora(s) · {selectedCount} item(ns) selecionado(s)
              </p>
            </div>
          </div>

          {/* Blocos por distribuidora */}
          {[...selectedByDistributor.entries()].map(([distId, group]) => {
            const state = getDistState(distId);
            const err = distError.get(distId);
            const isSent = state === "sent";
            const isSending = state === "sending";

            return (
              <div
                key={distId}
                className={[
                  "mb-4 overflow-hidden rounded-3xl border shadow-sm transition-all",
                  isSent ? "border-green-200 bg-green-50/40" : "border-[#DBEAFE] bg-white",
                ].join(" ")}
              >
                {/* Header */}
                <div className={["border-b px-5 py-3", isSent ? "border-green-200" : "border-[#DBEAFE]"].join(" ")}>
                  <p className="text-xs font-semibold uppercase tracking-[0.14em] text-slate-400">Distribuidora</p>
                  <p className="font-semibold text-[#0F172A]">{group.entry.company_name}</p>
                </div>

                {/* Itens */}
                <ul className="divide-y divide-[#DBEAFE] px-5">
                  {group.items.map((item, i) => (
                    <li key={i} className="flex items-center justify-between py-3 text-sm">
                      <span className="text-[#0F172A]">
                        {item.product_name}{" "}
                        <span className="text-slate-400">× {item.quantity}</span>
                      </span>
                      <span className="font-medium text-[#0F172A]">
                        {formatBRL(item.total_price_cents)}
                      </span>
                    </li>
                  ))}
                </ul>

                {/* Footer */}
                <div className={["flex items-center justify-between border-t px-5 py-4", isSent ? "border-green-200" : "border-[#DBEAFE]"].join(" ")}>
                  <div>
                    <p className="text-sm font-bold text-[#0F172A]">
                      Subtotal: <span className="text-[#2563EB]">{formatBRL(group.totalCents)}</span>
                    </p>
                    <p className="text-xs text-slate-400">
                      📅 entrega {group.entry.estimated_delivery_date}
                    </p>
                  </div>

                  <div className="flex flex-col items-end gap-1">
                    {err && <p className="text-xs text-red-600">{err}</p>}
                    {isSent ? (
                      <div className="flex flex-col items-end gap-1.5">
                        <span className="flex items-center gap-1.5 rounded-xl bg-green-100 px-4 py-2 text-sm font-bold text-green-700">
                          <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                          </svg>
                          Cotação enviada
                        </span>
                        <button
                          onClick={() => setSendModal({ distId })}
                          className="text-xs text-slate-400 underline hover:text-slate-600"
                        >
                          Reenviar por outro canal
                        </button>
                      </div>
                    ) : (
                      <Button
                        size="sm"
                        loading={isSending}
                        onClick={() => setSendModal({ distId })}
                      >
                        Confirmar cotação
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}

          {/* Total geral */}
          <div className="mb-6 flex items-center justify-between rounded-2xl border border-[#DBEAFE] bg-white px-5 py-4 shadow-sm">
            <p className="font-bold text-[#0F172A]">Total geral</p>
            <p className="text-2xl font-semibold text-[#2563EB]">{formatBRL(totalSelectedCents)}</p>
          </div>

          {/* Ver histórico quando tudo for enviado */}
          {allSent && (
            <Button
              fullWidth
              variant="secondary"
              size="lg"
              onClick={() => router.push("/historico")}
            >
              Ver histórico de pedidos →
            </Button>
          )}
        </main>

        {/* ── Modal de envio ──────────────────────────────────────────────── */}
        {sendModal && (() => {
          const { distId } = sendModal;
          const group = selectedByDistributor.get(distId);
          if (!group) return null;
          const state = getDistState(distId);
          const err = distError.get(distId);
          const isSending = state === "sending";
          const isSent = state === "sent";

          return (
            <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center p-4">
              {/* Overlay */}
              <div
                className="absolute inset-0 bg-black/40 backdrop-blur-sm"
                onClick={() => { if (!isSending) setSendModal(null); }}
              />

              {/* Painel */}
              <div className="relative w-full max-w-md rounded-3xl bg-white p-6 shadow-2xl">

                {/* Header */}
                <div className="mb-5 flex items-start justify-between gap-3">
                  <div>
                    <p className="text-xs font-bold uppercase tracking-[0.14em] text-slate-400">
                      Enviar cotação para
                    </p>
                    <p className="text-lg font-bold text-[#0F172A]">
                      {group.entry.company_name}
                    </p>
                    <p className="text-xs text-slate-400">
                      📅 entrega {group.entry.estimated_delivery_date}
                    </p>
                  </div>
                  {!isSending && (
                    <button
                      onClick={() => setSendModal(null)}
                      className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-[#F5F7FB] text-slate-400 hover:bg-[#DBEAFE] hover:text-[#0F172A]"
                    >
                      ✕
                    </button>
                  )}
                </div>

                {/* Itens */}
                <ul className="mb-4 divide-y divide-[#DBEAFE] rounded-2xl border border-[#DBEAFE]">
                  {group.items.map((item, i) => (
                    <li key={i} className="flex items-center justify-between px-4 py-2.5 text-sm">
                      <span className="text-[#0F172A]">
                        {item.product_name}{" "}
                        <span className="text-slate-400">× {item.quantity}</span>
                      </span>
                      <span className="font-medium">{formatBRL(item.total_price_cents)}</span>
                    </li>
                  ))}
                  <li className="flex items-center justify-between rounded-b-2xl bg-[#F5F7FB] px-4 py-2.5 text-sm font-bold">
                    <span>Total</span>
                    <span className="text-[#2563EB]">{formatBRL(group.totalCents)}</span>
                  </li>
                </ul>

                {/* Aviso de credencial — exibe quando não há credencial confirmada */}
                {!approvedCredentials.has(distId) && !isSent && (
                  <div className="mb-3 flex items-start gap-2 rounded-xl border border-amber-200 bg-amber-50 px-3 py-2.5">
                    <svg className="mt-0.5 h-4 w-4 shrink-0 text-amber-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                    <p className="text-xs text-amber-800">
                      Sua ficha cadastral será enviada junto com a cotação para análise de crédito desta distribuidora.
                    </p>
                  </div>
                )}

                {/* Feedback */}
                {err && (
                  <p className="mb-3 rounded-xl bg-red-50 px-3 py-2 text-xs text-red-700">{err}</p>
                )}
                {isSent && (
                  <div className="mb-3 flex items-center gap-2 rounded-xl bg-green-50 px-3 py-2 text-xs font-bold text-green-700">
                    <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7"/>
                    </svg>
                    Cotação enviada — use os canais abaixo para reenviar se necessário
                  </div>
                )}

                {/* Botão principal: ambos os canais */}
                <button
                  onClick={() => handleSend(distId, "both")}
                  disabled={isSending}
                  className="flex w-full items-center justify-center gap-2 rounded-2xl bg-[#0B1220] py-3.5 text-sm font-bold text-white transition hover:opacity-90 disabled:opacity-50"
                >
                  {isSending ? (
                    <>
                      <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent"/>
                      Enviando…
                    </>
                  ) : (
                    <>
                      <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"/>
                      </svg>
                      {isSent ? "Reenviar por WhatsApp e E-mail" : "Enviar por WhatsApp e E-mail"}
                    </>
                  )}
                </button>

                {/* Botões secundários lado a lado */}
                <div className="mt-2 grid grid-cols-2 gap-2">
                  <button
                    onClick={() => handleSend(distId, "whatsapp")}
                    disabled={isSending}
                    className="flex items-center justify-center gap-1.5 rounded-2xl border border-[#DBEAFE] bg-white py-3 text-sm font-bold text-[#0F172A] transition hover:bg-[#F5F7FB] disabled:opacity-50"
                  >
                    <svg className="h-4 w-4 text-[#25D366]" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                    </svg>
                    Só WhatsApp
                  </button>
                  <button
                    onClick={() => handleSend(distId, "email")}
                    disabled={isSending}
                    className="flex items-center justify-center gap-1.5 rounded-2xl border border-[#DBEAFE] bg-white py-3 text-sm font-bold text-[#0F172A] transition hover:bg-[#F5F7FB] disabled:opacity-50"
                  >
                    <svg className="h-4 w-4 text-[#2563EB]" viewBox="0 0 24 18" fill="none">
                      <rect x="1" y="1" width="22" height="16" rx="2.5" stroke="currentColor" strokeWidth="1.6"/>
                      <path d="M1.5 2L12 10.5 22.5 2" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/>
                    </svg>
                    Só E-mail
                  </button>
                </div>

                <p className="mt-2 text-center text-xs text-slate-400">
                  "Só E-mail" envia automaticamente — sem abrir o app
                </p>
              </div>
            </div>
          );
        })()}
      </div>
    );
  }

  // ── Fase de seleção ───────────────────────────────────────────────────────

  return (
    <div className="flex min-h-screen flex-col bg-[#F5F7FB]">
      <Navbar />

      <main className="mx-auto w-full max-w-2xl flex-1 px-4 pb-36 pt-8">

        {/* Cabeçalho */}
        <div className="mb-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold text-[#0F172A]">
              Ranking de preços
            </h1>
            <p className="text-sm text-slate-500">
              {productGroups.length} produto(s) · {allEntries.length} distribuidora(s)
              {ranking?.from_cache && (
                <span className="ml-2 text-xs text-slate-400">(cache)</span>
              )}
            </p>
          </div>
          <button
            onClick={fetchRanking}
            className="rounded-xl p-2 text-slate-400 hover:bg-[#DBEAFE] hover:text-[#0F172A]"
            title="Atualizar ranking"
          >
            <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
            </svg>
          </button>
        </div>

        {/* Filtros */}
        <div className="mb-5 flex flex-wrap gap-2">
          {(
            [
              { key: "cheapest",       label: "Mais barato" },
              { key: "most_expensive", label: "Mais caro" },
              { key: "fastest",        label: "Entrega mais rápida" },
            ] as { key: SortBy; label: string }[]
          ).map(({ key, label }) => (
            <button
              key={key}
              onClick={() => setSortBy(key)}
              className={`rounded-full px-4 py-1.5 text-sm font-medium transition-colors ${
                sortBy === key
                  ? "bg-[#2563EB] text-white"
                  : "border border-[#DBEAFE] bg-white text-slate-600 hover:bg-[#EFF6FF]"
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        {rankingError && (
          <div className="mb-4 rounded-xl bg-red-50 px-4 py-3 text-sm text-red-700">
            {rankingError}
          </div>
        )}

        {productGroups.length === 0 && !rankingError && ranking && (
          <EmptyRegion
            city={ranking.delivery_city}
            state={ranking.delivery_state}
            email={waitlistEmail}
            onEmailChange={setWaitlistEmail}
            status={waitlistState}
            onSubmit={async () => {
              if (!waitlistEmail || waitlistState !== "idle") return;
              setWaitlistState("sending");
              try {
                const res = await fetch("/api/waitlist", {
                  method:  "POST",
                  headers: { "Content-Type": "application/json" },
                  body:    JSON.stringify({
                    email: waitlistEmail,
                    city:  ranking.delivery_city,
                    state: ranking.delivery_state,
                  }),
                });
                setWaitlistState(res.ok ? "done" : "error");
              } catch {
                setWaitlistState("error");
              }
            }}
          />
        )}

        {/* ── Sugestão inteligente ──────────────────────────────────────────── */}
        {smartSuggestion && (
          <div className="mb-6 overflow-hidden rounded-3xl bg-[#2563EB] shadow-lg">
            <div className="px-5 pt-5 pb-4">
              <div className="mb-1">
                <span className="rounded-full bg-white/20 px-2.5 py-0.5 text-xs font-bold uppercase tracking-wide text-white">
                  ✦ Sugestão inteligente
                </span>
              </div>
              <h2 className="text-xl font-semibold text-white">Melhor combinação de preços</h2>
              <p className="mt-0.5 text-sm text-white/70">
                O menor preço disponível para cada produto da sua cotação.
              </p>
            </div>

            <div className="mx-5 mb-4 overflow-hidden rounded-2xl bg-white/10">
              {smartSuggestion.best.map(({ offer }, i) => (
                <div
                  key={offer.key}
                  className={[
                    "flex items-start gap-3 px-4 py-3 text-sm",
                    i < smartSuggestion.best.length - 1 ? "border-b border-white/10" : "",
                  ].join(" ")}
                >
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-white truncate">
                      {offer.quotation_item_name ?? offer.product_name}
                    </p>
                    <p className="text-xs text-white/60">
                      {offer.company_name} · 📅 {offer.estimated_delivery_date}
                    </p>
                  </div>
                  <div className="shrink-0 text-right">
                    <p className="font-bold text-white">{formatBRL(offer.total_price_cents)}</p>
                    <p className="text-xs text-white/60">
                      {formatBRL(offer.unit_price_cents)}/un × {offer.quantity}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex items-center justify-between border-t border-white/20 px-5 py-4">
              <div>
                <p className="text-xs font-bold uppercase tracking-wide text-white/60">Total combinado</p>
                <p className="text-2xl font-semibold text-white">{formatBRL(smartSuggestion.totalCents)}</p>
                <p className="mt-0.5 text-xs text-white/60">
                  Chegará tudo até {smartSuggestion.latestDeliveryDate}
                </p>
              </div>
              <button
                onClick={applySmartSuggestion}
                disabled={suggestionApplied}
                className={[
                  "rounded-xl px-5 py-2.5 text-sm font-bold transition-all",
                  suggestionApplied
                    ? "cursor-default bg-white/20 text-white/60"
                    : "bg-white text-[#2563EB] hover:bg-white/90 active:scale-95",
                ].join(" ")}
              >
                {suggestionApplied ? "✓ Sugestão aplicada" : "Usar esta sugestão"}
              </button>
            </div>
          </div>
        )}

        {/* ── Cards por produto ────────────────────────────────────────────── */}
        {productGroups.map((group) => {
          const anySelected = group.offers.some((o) => selectedKeys.has(o.key));

          return (
            <div
              key={group.quotation_item_name}
              className={[
                "mb-4 overflow-hidden rounded-3xl border bg-white shadow-sm transition-all",
                anySelected ? "border-[#2563EB] ring-2 ring-[#DBEAFE]" : "border-[#DBEAFE]",
              ].join(" ")}
            >
              <div className="flex items-center justify-between border-b border-[#DBEAFE] px-5 py-4">
                <div>
                  <h3 className="font-bold text-[#0F172A]">{group.quotation_item_name}</h3>
                  <p className="text-xs text-slate-400">
                    Quantidade: {group.quantity} · {group.offers.length} oferta(s)
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-slate-400">A partir de</p>
                  <p className="font-semibold text-[#2563EB]">{formatBRL(group.cheapestCents)}/un</p>
                </div>
              </div>

              <ul className="divide-y divide-[#DBEAFE]">
                {group.offers.map((offer, offerIdx) => {
                  const checked = selectedKeys.has(offer.key);
                  const isCheapest = offer.unit_price_cents === group.cheapestCents;
                  const isFastest =
                    offer.total_business_days ===
                    Math.min(...group.offers.map((o) => o.total_business_days));

                  return (
                    <li
                      key={offer.key}
                      onClick={() => toggleItem(offer.key)}
                      className={[
                        "flex cursor-pointer items-center gap-3 px-5 py-3.5 transition-colors",
                        checked ? "bg-[#EFF6FF]" : "hover:bg-[#F5F7FB]",
                        !offer.within_deadline ? "opacity-60" : "",
                      ].join(" ")}
                    >
                      <input
                        type="checkbox"
                        checked={checked}
                        onChange={() => toggleItem(offer.key)}
                        onClick={(e) => e.stopPropagation()}
                        className="h-4 w-4 shrink-0 rounded accent-[#2563EB]"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-sm font-medium text-[#0F172A] truncate">
                            {offer.company_name}
                          </span>
                          {offerIdx === 0 && sortBy === "cheapest" && isCheapest && (
                            <span className="rounded-full bg-green-100 px-2 py-0.5 text-xs font-bold text-green-700">
                              Mais barato
                            </span>
                          )}
                          {offerIdx === 0 && sortBy === "fastest" && isFastest && (
                            <span className="rounded-full bg-blue-100 px-2 py-0.5 text-xs font-bold text-blue-700">
                              Mais rápido
                            </span>
                          )}
                          {!offer.within_deadline && (
                            <Badge variant="yellow">fora do prazo</Badge>
                          )}
                          {offer.average_rating !== null && offer.review_count > 0 && (
                            <span className="text-[11px] text-slate-500">
                              ⭐ {offer.average_rating.toFixed(1)} ({offer.review_count})
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-400">📅 {offer.estimated_delivery_date}</p>
                      </div>
                      <div className="shrink-0 text-right">
                        <p className={["font-bold text-sm", checked ? "text-[#2563EB]" : "text-[#0F172A]"].join(" ")}>
                          {formatBRL(offer.total_price_cents)}
                        </p>
                        <div className="flex items-center justify-end gap-1">
                          <p className="text-xs text-slate-400">{formatBRL(offer.unit_price_cents)}/un</p>
                          <PriceChangeIndicator pct={offer.price_change_pct} />
                        </div>
                      </div>
                    </li>
                  );
                })}
              </ul>
            </div>
          );
        })}

        {/* Produtos indisponíveis */}
        {unavailableProducts.length > 0 && (
          <div className="mb-4 rounded-3xl border border-[#DBEAFE] bg-white shadow-sm">
            <div className="border-b border-[#DBEAFE] px-5 py-4">
              <h3 className="font-bold text-slate-400">Produtos indisponíveis</h3>
              <p className="text-xs text-slate-400">
                Nenhuma distribuidora da sua região oferece estes itens.
              </p>
            </div>
            <ul className="divide-y divide-[#DBEAFE]">
              {unavailableProducts.map((name) => (
                <li key={name} className="flex items-center justify-between px-5 py-3">
                  <span className="text-sm text-slate-400 line-through">{name}</span>
                  <Badge variant="gray">indisponível</Badge>
                </li>
              ))}
            </ul>
          </div>
        )}
      </main>

      {/* ── Barra fixa: Concluir pedido ───────────────────────────────────── */}
      {selectedCount > 0 && (
        <div className="fixed bottom-0 left-0 right-0 z-40 border-t border-[#DBEAFE] bg-white/95 px-4 py-4 backdrop-blur-sm">
          <div className="mx-auto flex w-full max-w-2xl items-center justify-between gap-4">
            <div>
              <p className="text-sm font-bold text-[#0F172A]">
                {selectedCount} item(ns) selecionado(s)
              </p>
              <p className="text-xs text-slate-400">
                {selectedByDistributor.size} distribuidora(s) · {formatBRL(totalSelectedCents)}
              </p>
            </div>
            <Button size="lg" onClick={() => setConfirmPhase(true)}>
              Concluir pedido →
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
