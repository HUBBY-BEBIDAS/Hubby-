import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { Providers } from "@/components/Providers";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

export const metadata: Metadata = {
  title: "HUBBY — SIC · Sistema Integrado de Cotações",
  description: "Plataforma B2B de cotação e distribuição de bebidas para bares, restaurantes e adegas.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR" className={`${inter.variable} h-full antialiased`}>
      <body className="min-h-full bg-[#F5F7FB] font-sans text-[#0F172A]">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
