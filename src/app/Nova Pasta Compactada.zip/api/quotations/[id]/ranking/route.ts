import { NextRequest } from "next/server";
import { withAuth } from "@/lib/with-auth";
import { prisma } from "@/lib/prisma";
import { computeRanking, extractDistributorIds } from "@/lib/ranking-engine";
import { getRankingCache, setRankingCache } from "@/lib/ranking-cache";
import type { RankingResult, RankedDistributor } from "@/lib/ranking-engine";

// ─── Shape esperado pelo frontend ─────────────────────────────────────────────

type MatchedItem = {
  quotation_item_name: string;
  quotation_item_brand: string;
  product_name: string;
  quantity: number;
  unit_price_cents: number;
  total_price_cents: number;
  /** Variação percentual em relação à última consulta. null = sem histórico. */
  price_change_pct: number | null;
};

type RankingEntry = {
  distributor_id: string;
  company_name: string;
  whatsapp_commercial: string;
  email_commercial: string;
  total_cents: number;
  total_brl: string;
  all_items_available: boolean;
  matched_items: MatchedItem[];
  unmatched_items: string[];
  estimated_delivery_date: string;
  total_business_days: number;
  within_deadline: boolean;
  price_updated_at: string;
  status: "within_deadline" | "out_of_deadline";
};

type ApiRankingResult = {
  within_deadline: RankingEntry[];
  out_of_deadline: RankingEntry[];
  quotation_id: string;
  delivery_city: string;
  delivery_state: string;
  from_cache: boolean;
};

// ─── Histórico de preços: busca última referência antes de gravar ─────────────

/** Chave no mapa: "productId:distributorId" */
type PriceHistoryMap = Map<string, number>;

async function buildPriceHistoryMap(
  clientId: string,
  result: Omit<RankingResult, "from_cache">
): Promise<PriceHistoryMap> {
  const map: PriceHistoryMap = new Map();

  for (const dist of result.distributors) {
    for (const item of dist.items) {
      if (!item.matched_product) continue;

      const productId = item.matched_product.id;
      const key = `${productId}:${dist.distributor_id}`;
      if (map.has(key)) continue;

      const last = await prisma.priceHistory.findFirst({
        where: {
          product_id:     productId,
          distributor_id: dist.distributor_id,
          client_id:      clientId,
        },
        orderBy: { recorded_at: "desc" },
        select:  { price_cents: true },
      });

      if (last) map.set(key, last.price_cents);
    }
  }

  return map;
}

// ─── Transforma saída do motor para o shape da API ────────────────────────────

function toEntry(d: RankedDistributor, historyMap: PriceHistoryMap): RankingEntry {
  const matched_items: MatchedItem[] = d.items
    .filter((i) => i.available && i.matched_product !== null)
    .map((i) => {
      const currentCents = i.matched_product!.price_cents;
      const key = `${i.matched_product!.id}:${d.distributor_id}`;
      const prevCents = historyMap.get(key) ?? null;

      let price_change_pct: number | null = null;
      if (prevCents !== null && prevCents > 0) {
        price_change_pct = Math.round(((currentCents - prevCents) / prevCents) * 10000) / 100;
      }

      return {
        quotation_item_name: i.product_name,
        quotation_item_brand: i.brand,
        product_name: i.matched_product!.name,
        quantity: i.quantity,
        unit_price_cents: currentCents,
        total_price_cents: i.matched_product!.subtotal_cents,
        price_change_pct,
      };
    });

  const unmatched_items: string[] = d.items
    .filter((i) => !i.available)
    .map((i) => i.product_name);

  // Usa a atualização de preço mais recente entre os produtos casados
  const updatedAts = d.items
    .filter((i) => i.matched_product)
    .map((i) => i.matched_product!.price_updated_at);
  const price_updated_at =
    updatedAts.length > 0
      ? updatedAts.sort().at(-1)!
      : new Date().toISOString();

  const isWithin = d.status === "dentro_do_prazo";

  return {
    distributor_id: d.distributor_id,
    company_name: d.company_name,
    whatsapp_commercial: d.whatsapp_commercial,
    email_commercial: d.email_commercial,
    total_cents: d.total_cents,
    total_brl: d.total_brl,
    all_items_available: d.all_items_available,
    matched_items,
    unmatched_items,
    estimated_delivery_date: d.delivery_date,
    total_business_days: d.total_business_days,
    within_deadline: isWithin,
    price_updated_at,
    status: isWithin ? "within_deadline" : "out_of_deadline",
  };
}

async function toApiResult(
  result: Omit<RankingResult, "from_cache">,
  from_cache: boolean,
  clientId: string
): Promise<ApiRankingResult> {
  // Busca histórico ANTES de gravar o novo snapshot
  const historyMap = await buildPriceHistoryMap(clientId, result);

  const within_deadline = result.distributors
    .filter((d) => d.status === "dentro_do_prazo")
    .map((d) => toEntry(d, historyMap));

  const out_of_deadline = result.distributors
    .filter((d) => d.status === "fora_do_prazo")
    .map((d) => toEntry(d, historyMap));

  console.log(`[ranking] resposta: ${within_deadline.length} dentro do prazo | ${out_of_deadline.length} fora do prazo | cache=${from_cache}`);

  return {
    within_deadline,
    out_of_deadline,
    quotation_id: result.quotation_id,
    delivery_city: result.delivery_city,
    delivery_state: result.delivery_state,
    from_cache,
  };
}

/**
 * GET /api/quotations/:id/ranking
 */
export const GET = withAuth(
  async (req: NextRequest, user, context) => {
    const quotationId = context?.params.id;
    if (!quotationId) {
      return Response.json({ error: "ID da cotação não fornecido" }, { status: 400 });
    }

    const { searchParams } = new URL(req.url);
    const forceRefresh = searchParams.get("refresh") === "1";

    const quotation = await prisma.quotation.findUnique({
      where: { id: quotationId },
      include: { items: true, client: true },
    });

    if (!quotation) {
      return Response.json({ error: "Cotação não encontrada" }, { status: 404 });
    }

    if (user.role === "client" && quotation.client.user_id !== user.userId) {
      return Response.json({ error: "Acesso não autorizado" }, { status: 403 });
    }

    if (quotation.status === "draft") {
      return Response.json(
        { error: "Cotação ainda em rascunho — publique antes de ver o ranking" },
        { status: 400 }
      );
    }

    console.log(`[ranking] requisição | quotation=${quotationId} cidade="${quotation.delivery_city}" estado="${quotation.delivery_state}" itens=${quotation.items.length} forceRefresh=${forceRefresh}`);

    if (!forceRefresh) {
      const cached = await getRankingCache<ApiRankingResult>(quotationId);
      if (cached) {
        console.log(`[ranking] servindo do cache`);
        return Response.json({ ...cached.data, from_cache: true });
      }
    }

    const result = await computeRanking(quotation, quotation.client);
    const distributorIds = extractDistributorIds(result);

    // buildPriceHistoryMap é chamado DENTRO de toApiResult, antes de gravar o novo snapshot
    const apiResult = await toApiResult(result, false, quotation.client.id);

    setRankingCache(quotationId, apiResult, distributorIds).catch((err) => {
      console.error("[ranking] erro ao salvar cache:", err);
    });

    // Registra histórico de preços em background (fire-and-forget)
    if (quotation.client.id && result.distributors.length > 0) {
      recordPriceHistory(quotation.client.id, result).catch(() => {});
    }

    return Response.json(apiResult);
  },
  { roles: ["client", "platform_admin"] }
);

// ─── Histórico de preços ──────────────────────────────────────────────────────

async function recordPriceHistory(
  clientId: string,
  result: Omit<RankingResult, "from_cache">
): Promise<void> {
  // Busca os produtos reais correspondentes a cada item matched no ranking.
  // O ranking-engine retorna o nome do produto mas não o product_id.
  // Precisamos cruzar pelo nome + distribuidora.
  const records: Array<{ product_id: string; distributor_id: string; price_cents: number }> = [];

  for (const dist of result.distributors) {
    for (const item of dist.items) {
      if (!item.matched_product) continue;

      // Busca o product_id pelo nome + distribuidora
      const product = await prisma.product.findFirst({
        where: {
          distributor_id: dist.distributor_id,
          name:           item.matched_product.name,
          available:      true,
        },
        select: { id: true },
      });

      if (product) {
        records.push({
          product_id:     product.id,
          distributor_id: dist.distributor_id,
          price_cents:    item.matched_product.price_cents,
        });
      }
    }
  }

  if (records.length === 0) return;

  // Usa createMany com skipDuplicates para evitar explosion de registros
  // (limita a 1 registro por produto+distribuidora por hora para o mesmo cliente)
  const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000);

  for (const rec of records) {
    const recentExists = await prisma.priceHistory.findFirst({
      where: {
        product_id:     rec.product_id,
        distributor_id: rec.distributor_id,
        client_id:      clientId,
        recorded_at:    { gte: oneHourAgo },
      },
      select: { id: true },
    });

    if (!recentExists) {
      await prisma.priceHistory.create({
        data: {
          product_id:     rec.product_id,
          distributor_id: rec.distributor_id,
          client_id:      clientId,
          price_cents:    rec.price_cents,
        },
      });
    }
  }
}
