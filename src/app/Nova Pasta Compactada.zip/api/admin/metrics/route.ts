import { NextRequest } from "next/server";
import { withAuth } from "@/lib/with-auth";
import { prisma } from "@/lib/prisma";

/**
 * GET /api/admin/metrics
 *
 * Métricas gerais da plataforma para o admin.
 * Calculadas em tempo real.
 */
export const GET = withAuth(
  async (_req: NextRequest, _user) => {
    // Início do mês corrente em UTC
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

    // Início do mês anterior (para comparação MoM)
    const startOfLastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);

    const [
      totalClients,
      totalDistributors,
      approvedDistributors,
      pendingDistributors,
      distributorsByPlan,
      ordersThisMonth,
      ordersLastMonth,
      quotationsThisMonth,
      newClientsThisMonth,
      newDistributorsThisMonth,
    ] = await Promise.all([
      prisma.client.count(),
      prisma.distributor.count(),
      prisma.distributor.count({ where: { approved_by_admin: true } }),
      prisma.distributor.count({ where: { approved_by_admin: false } }),

      // Distribuidoras por plano
      prisma.distributor.groupBy({
        by: ["plan"],
        _count: { id: true },
      }),

      // Pedidos do mês atual
      prisma.order.count({
        where: { sent_at: { gte: startOfMonth } },
      }),

      // Pedidos do mês anterior
      prisma.order.count({
        where: {
          sent_at: { gte: startOfLastMonth, lt: startOfMonth },
        },
      }),

      // Cotações abertas este mês
      prisma.quotation.count({
        where: { created_at: { gte: startOfMonth } },
      }),

      // Novos clientes este mês
      prisma.client.count({
        where: { user: { created_at: { gte: startOfMonth } } },
      }),

      // Novas distribuidoras este mês
      prisma.distributor.count({
        where: { created_at: { gte: startOfMonth } },
      }),
    ]);

    const planMap: Record<string, number> = {};
    for (const row of distributorsByPlan) {
      planMap[row.plan] = row._count.id;
    }

    // Variação percentual de pedidos mês a mês
    const ordersMoM =
      ordersLastMonth === 0
        ? null
        : Math.round(((ordersThisMonth - ordersLastMonth) / ordersLastMonth) * 10000) / 100;

    return Response.json({
      period_month: `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`,
      clients: {
        total: totalClients,
        new_this_month: newClientsThisMonth,
      },
      distributors: {
        total: totalDistributors,
        approved: approvedDistributors,
        pending_approval: pendingDistributors,
        new_this_month: newDistributorsThisMonth,
        by_plan: {
          vitrine: planMap["vitrine"] ?? 0,
          operacional: planMap["operacional"] ?? 0,
          enterprise: planMap["enterprise"] ?? 0,
        },
      },
      orders: {
        this_month: ordersThisMonth,
        last_month: ordersLastMonth,
        mom_change_percent: ordersMoM,
      },
      quotations: {
        this_month: quotationsThisMonth,
      },
    });
  },
  { roles: ["platform_admin"] }
);
