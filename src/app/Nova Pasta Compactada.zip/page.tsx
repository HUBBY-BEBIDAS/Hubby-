"use client";

// Página pública — usuários autenticados são redirecionados pelo proxy (src/proxy.ts)
// antes de chegarem aqui.

import { useState, useEffect, useRef } from "react";

// ─── Tabela de preços (espelha lib/stripe.ts, mas no cliente sem importar o módulo server) ──

type PeriodKey = "monthly" | "quarterly" | "semiannual" | "annual";

const PERIOD_LABELS: Record<PeriodKey, string> = {
  monthly: "Mensal", quarterly: "Trimestral", semiannual: "Semestral", annual: "Anual",
};

const PERIOD_DISCOUNTS: Record<PeriodKey, number> = {
  monthly: 0, quarterly: 10, semiannual: 15, annual: 20,
};

const PERIOD_MONTHS: Record<PeriodKey, number> = {
  monthly: 1, quarterly: 3, semiannual: 6, annual: 12,
};

// Preço mensal equivalente por plano+período (centavos)
const DIST_MONTHLY: Record<string, Record<PeriodKey, number>> = {
  starter:  { monthly: 29900, quarterly: 26900, semiannual: 25400, annual: 23900 },
  pro:      { monthly: 79900, quarterly: 71900, semiannual: 67900, annual: 63900 },
  business: { monthly: 149900, quarterly: 134900, semiannual: 127400, annual: 119900 },
};

// Total cobrado de uma só vez por plano+período
const DIST_TOTAL: Record<string, Record<PeriodKey, number>> = {
  starter:  { monthly: 29900, quarterly: 80700,  semiannual: 152400,  annual: 286800  },
  pro:      { monthly: 79900, quarterly: 215700, semiannual: 407400,  annual: 766800  },
  business: { monthly: 149900, quarterly: 404700, semiannual: 764400, annual: 1438800 },
};

const BUYER_MONTHLY: Record<PeriodKey, number> = {
  monthly: 9900, quarterly: 8900, semiannual: 8400, annual: 7900,
};

const BUYER_TOTAL: Record<PeriodKey, number> = {
  monthly: 9900, quarterly: 26700, semiannual: 50400, annual: 94800,
};

function formatBRL(cents: number) {
  return new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL", minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(cents / 100);
}

// ─── Dados ───────────────────────────────────────────────────────────────────

const clientTypes = [
  "Bar",
  "Restaurante",
  "Adega",
  "Hotel",
  "Mercado",
  "Casa Noturna",
  "Conveniência",
  "Evento",
];

const testimonials = [
  {
    name: "Carlos M.",
    role: "Gerente de Compras",
    company: "Bar & Grill SP",
    text: "Antes eu gastava meia manhã no telefone pedindo cotação. Agora mando uma vez e recebo tudo comparado automaticamente. Economizei mais de R$ 800 no primeiro mês.",
    stars: 5,
  },
  {
    name: "Ana Paula R.",
    role: "Proprietária",
    company: "Adega do Centro",
    text: "Consegui fechar com uma distribuidora que nem conhecia. O ranking mostrou um preço 18% menor no gin importado. Nunca mais volto ao modelo antigo.",
    stars: 5,
  },
  {
    name: "Roberto S.",
    role: "Sócio-Gerente",
    company: "Restaurante Mediterrâneo",
    text: "O processo de credenciamento foi rápido e transparente. Em menos de 48 horas eu já estava comprando de 3 distribuidoras novas com condições muito melhores.",
    stars: 5,
  },
];

const faqsCompradores = [
  {
    q: "Quanto custa para o comprador?",
    a: "O plano básico é gratuito para sempre. Você cota, compara preços e envia pedidos sem pagar nada. Se quiser expandir para outras regiões, ter múltiplos usuários ou acessar relatórios avançados, temos o plano Pro a partir de R$ 79/mês no plano anual.",
  },
  {
    q: "Preciso instalar algum aplicativo?",
    a: "Não — a plataforma funciona direto pelo navegador do celular ou computador. O app para iOS e Android está em desenvolvimento e chegará em breve.",
  },
  {
    q: "Como as distribuidoras sabem que sou confiável?",
    a: "Quando você aciona uma distribuidora pela primeira vez, o sistema faz uma análise de crédito automática pelo seu CNPJ via bureau de crédito (Serasa). O resultado vai para a distribuidora, que decide se aprova ou não. Você só precisa enviar seus documentos uma vez.",
  },
  {
    q: "Quanto tempo leva para receber as cotações?",
    a: "O ranking de preços aparece instantaneamente — as distribuidoras já cadastram seus preços na plataforma. Você não precisa esperar ninguém responder para ver os valores.",
  },
  {
    q: "A Hubby cobra comissão por venda?",
    a: "Nunca. A Hubby cobra mensalidade apenas das distribuidoras. Para o comprador, o plano básico é gratuito para sempre e não há comissão sobre nenhuma venda.",
  },
  {
    q: "Como funciona o pagamento e a nota fiscal?",
    a: "O pagamento e a nota fiscal são negociados diretamente entre você e a distribuidora escolhida. A Hubby faz a ponte — conecta você com as distribuidoras — mas não intermedia o pagamento nem emite notas fiscais.",
  },
  {
    q: "Posso cotar com distribuidoras de outras cidades?",
    a: "No plano gratuito, você cota com distribuidoras que atendem sua região cadastrada. No plano Pro, você pode expandir para qualquer região do Brasil.",
  },
];

const faqsDistribuidoras = [
  {
    q: "Como recebo as cotações dos clientes?",
    a: "De três formas simultâneas: notificação no painel da plataforma, mensagem no WhatsApp comercial cadastrado e e-mail comercial. Você escolhe como prefere ser notificado.",
  },
  {
    q: "Preciso atualizar meus preços toda hora?",
    a: "Não. Você atualiza quando quiser — pode ser diário, semanal ou quando houver mudança. O sistema exibe para o comprador a data e hora da última atualização, garantindo transparência.",
  },
  {
    q: "O que acontece se eu não tiver um produto em estoque?",
    a: "Você desativa o produto com um clique e ele some do ranking instantaneamente. No plano Enterprise, você pode integrar seu ERP para sincronizar o estoque automaticamente.",
  },
  {
    q: "Como funciona a análise de crédito dos clientes?",
    a: "Quando um cliente novo te aciona pela primeira vez, o sistema consulta automaticamente o bureau de crédito pelo CNPJ dele. Você vê o score e as informações e decide se aprova ou não. Você também pode configurar critérios próprios de aprovação automática.",
  },
  {
    q: "Posso escolher quais regiões atendo?",
    a: "Sim. Você configura exatamente as cidades e estados que atende, os dias de rota e o horário de corte para cada região. O sistema filtra automaticamente — seu perfil só aparece para compradores da sua área de entrega.",
  },
  {
    q: "Existe fidelidade ou contrato mínimo?",
    a: "Não há fidelidade obrigatória. Você pode assinar mensalmente e cancelar quando quiser. Oferecemos planos trimestrais, semestrais e anuais com desconto de até 20% para quem prefere um compromisso maior.",
  },
  {
    q: "A Hubby cobra comissão por venda fechada?",
    a: "Nunca. Você paga apenas a mensalidade do plano escolhido. Não importa quantos pedidos você fechar pela plataforma — nenhuma comissão é cobrada.",
  },
  {
    q: "Posso integrar com meu sistema de gestão (ERP)?",
    a: "Sim, no plano Enterprise. A integração é feita via webhook e API própria — quando um pedido chega, seu ERP é notificado automaticamente. Você também pode sincronizar o estoque em tempo real.",
  },
];

// ─── Componentes interativos ──────────────────────────────────────────────────

function AnimatedNumber({ target, suffix = "" }: { target: number; suffix?: string }) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const started = useRef(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !started.current) {
          started.current = true;
          const duration = 1800;
          const startTime = performance.now();
          const tick = (now: number) => {
            const progress = Math.min((now - startTime) / duration, 1);
            const eased = 1 - Math.pow(1 - progress, 3);
            setCount(Math.floor(eased * target));
            if (progress < 1) requestAnimationFrame(tick);
          };
          requestAnimationFrame(tick);
        }
      },
      { threshold: 0.4 }
    );
    const el = ref.current;
    if (el) observer.observe(el);
    return () => observer.disconnect();
  }, [target]);

  return (
    <span ref={ref}>
      {count}
      {suffix}
    </span>
  );
}

function FaqItem({ q, a, index }: { q: string; a: string; index: number }) {
  const [open, setOpen] = useState(false);
  const bodyRef = useRef<HTMLDivElement>(null);

  return (
    <div className={`border-b border-[#DBEAFE] ${index === 0 ? "border-t" : ""}`}>
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-start justify-between gap-4 py-5 text-left transition-colors"
      >
        <span className={`text-[15px] font-semibold leading-snug transition-colors ${open ? "text-[#2563EB]" : "text-[#0F172A] hover:text-[#2563EB]"}`}>
          {q}
        </span>
        <span
          className={`mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full border transition-all duration-300 ${
            open
              ? "border-[#2563EB] bg-[#2563EB] text-white rotate-45"
              : "border-[#DBEAFE] bg-white text-[#0F172A]"
          }`}
          style={{ fontSize: "18px", lineHeight: 1 }}
        >
          +
        </span>
      </button>
      <div
        ref={bodyRef}
        className="overflow-hidden transition-all duration-300 ease-in-out"
        style={{ maxHeight: open ? (bodyRef.current?.scrollHeight ?? 500) + "px" : "0px" }}
      >
        <p className="pb-5 text-[15px] leading-relaxed text-slate-600">{a}</p>
      </div>
    </div>
  );
}

function FaqSection() {
  const [tab, setTab] = useState<"compradores" | "distribuidoras">("compradores");
  const items = tab === "compradores" ? faqsCompradores : faqsDistribuidoras;

  return (
    <section id="faq" className="bg-white py-9">
      <div className="mx-auto max-w-2xl px-4 lg:px-5">

        {/* Cabeçalho */}
        <div className="mb-6 text-center">
          <span className="text-sm font-bold uppercase tracking-[0.18em] text-[#22C55E]">
            Dúvidas frequentes
          </span>
          <h2 className="mt-3 text-3xl font-black text-[#0F172A] md:text-4xl">
            Perguntas frequentes
          </h2>
        </div>

        {/* Abas */}
        <div className="mb-5 flex rounded-2xl border border-[#DBEAFE] bg-[#F5F7FB] p-1">
          {(["compradores", "distribuidoras"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={[
                "flex-1 rounded-xl py-2.5 text-sm font-semibold transition-all duration-200",
                tab === t
                  ? "bg-white text-[#0F172A] shadow-sm"
                  : "text-slate-500 hover:text-[#0F172A]",
              ].join(" ")}
            >
              {t === "compradores" ? "Para compradores" : "Para distribuidoras"}
            </button>
          ))}
        </div>

        {/* Lista de perguntas */}
        <div key={tab}>
          {items.map((item, i) => (
            <FaqItem key={item.q} q={item.q} a={item.a} index={i} />
          ))}
        </div>

        {/* CTA final */}
        <div className="mt-6 flex items-center justify-center gap-3 rounded-2xl border border-[#DBEAFE] bg-[#F5F7FB] px-6 py-5">
          <span className="text-sm text-slate-600">Não encontrou sua resposta?</span>
          <a
            href="https://wa.me/5511999999999"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 rounded-xl bg-[#25D366] px-4 py-2 text-sm font-bold text-white transition hover:opacity-90"
          >
            <svg className="h-4 w-4" viewBox="0 0 24 24" fill="currentColor">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z" />
            </svg>
            Falar pelo WhatsApp
          </a>
        </div>

      </div>
    </section>
  );
}

// ─── Página principal ─────────────────────────────────────────────────────────

export default function Home() {
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [period, setPeriod] = useState<PeriodKey>("monthly");

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <>
      <style>{`
        @keyframes marquee {
          from { transform: translateX(0); }
          to   { transform: translateX(-50%); }
        }
        .marquee-track {
          display: flex;
          width: max-content;
          animation: marquee 26s linear infinite;
          will-change: transform;
        }
        .marquee-track:hover { animation-play-state: paused; }

        @keyframes hero-orb {
          0%, 100% { opacity: 0.14; transform: scale(1); }
          50%       { opacity: 0.22; transform: scale(1.06); }
        }
        .hero-orb-green { animation: hero-orb 7s ease-in-out infinite; }
        .hero-orb-blue  { animation: hero-orb 9s ease-in-out infinite 2.5s; }
      `}</style>

      {/* ══ NAVBAR FIXA ════════════════════════════════════════════════════════ */}
      <div className="fixed top-4 left-0 right-0 z-50 px-5 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <nav className="flex items-center justify-between rounded-2xl border border-white/[0.07] bg-[#0B1220]/85 px-4 py-2.5 backdrop-blur-2xl shadow-[0_1px_0_0_rgba(255,255,255,0.04),0_8px_32px_0_rgba(0,0,0,0.32)]">

            {/* Logo */}
            <a href="/" className="group flex items-center gap-2.5">
              <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-[#22C55E] shadow-lg shadow-green-500/30 transition group-hover:shadow-green-500/50">
                <svg className="h-3.5 w-3.5 text-white" viewBox="0 0 14 14" fill="none">
                  <rect x="1" y="1" width="5" height="8" rx="1" fill="currentColor" opacity="0.9"/>
                  <rect x="8" y="1" width="5" height="4" rx="1" fill="currentColor"/>
                  <rect x="8" y="7" width="5" height="6" rx="1" fill="currentColor" opacity="0.7"/>
                </svg>
              </span>
              <span className="text-sm font-black uppercase tracking-[0.22em] text-white">
                HUBBY
              </span>
            </a>

            {/* Nav links */}
            <div className="hidden items-center gap-1 sm:flex">
              {[
                { label: "Como funciona", id: "como-funciona" },
                { label: "Benefícios",    id: "beneficios"    },
                { label: "Planos",        id: "planos"        },
                { label: "FAQ",           id: "faq"           },
              ].map(({ label, id }) => (
                <a
                  key={id}
                  href={`/#${id}`}
                  className="rounded-lg px-4 py-2 text-[13px] font-medium text-white/75 transition-all duration-200 hover:bg-white/10 hover:text-white"
                >
                  {label}
                </a>
              ))}
              <a
                href="/sobre"
                className="rounded-lg px-4 py-2 text-[13px] font-medium text-white/75 transition-all duration-200 hover:bg-white/10 hover:text-white"
              >
                Sobre nós
              </a>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-2">
              <a
                href="/auth/login"
                className="rounded-xl px-4 py-2 text-[13px] font-medium text-white/80 transition-all duration-200 hover:text-white"
              >
                Entrar
              </a>
              <a
                href="/auth/register"
                className="rounded-xl bg-white px-4 py-2 text-[13px] font-bold text-[#0B1220] shadow-[0_1px_2px_0_rgba(0,0,0,0.15)] transition-all duration-200 hover:bg-white/90 hover:shadow-md"
              >
                Começar grátis
              </a>
            </div>
          </nav>
        </div>
      </div>

      <div className="min-h-screen bg-[#F5F7FB] text-[#0F172A]">

        {/* ══ HERO ══════════════════════════════════════════════════════════════ */}
        <section className="relative overflow-hidden bg-[#0B1220] pb-12 text-white">

          {/* Fundo animado */}
          <div className="pointer-events-none absolute inset-0">
            <div
              className="hero-orb-green absolute -top-40 right-[-10%] h-[640px] w-[640px] rounded-full bg-[#22C55E]"
              style={{ filter: "blur(130px)" }}
            />
            <div
              className="hero-orb-blue absolute -bottom-20 left-[-8%] h-[520px] w-[520px] rounded-full bg-[#3B82F6]"
              style={{ filter: "blur(110px)" }}
            />
            <div className="absolute inset-0 opacity-[0.06] [background-image:linear-gradient(rgba(255,255,255,0.12)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.12)_1px,transparent_1px)] [background-size:48px_48px]" />
          </div>

          {/* Conteúdo hero — pt-14 compensa a navbar fixa */}
          <div className="relative mx-auto grid max-w-7xl items-center gap-6 px-4 pt-9 pb-10 lg:grid-cols-[1.1fr_0.9fr] lg:px-5 lg:pt-20 lg:pb-16">

            {/* Texto */}
            <div>
              <span className="inline-flex items-center gap-2 rounded-full border border-[#22C55E]/40 bg-[#22C55E]/10 px-4 py-1.5 text-sm font-semibold text-[#4ADE80]">
                <span className="h-2 w-2 animate-pulse rounded-full bg-[#22C55E]" />
                Plataforma B2B de Cotação de Bebidas
              </span>

              <h1 className="mt-4 text-5xl font-black leading-[0.93] tracking-tight md:text-[4.25rem]">
                Cotação de bebidas{" "}
                <span className="text-[#22C55E]">inteligente.</span>
                <br />
                Do pedido ao ranking{" "}
                <span className="text-white/50">em segundos.</span>
              </h1>

              <p className="mt-4 max-w-xl text-lg leading-relaxed text-white/60">
                Distribuidoras cadastram preços uma vez. Compradores enviam cotação para múltiplas distribuidoras simultaneamente e veem o ranking automático com prazo real de entrega calculado pela rota.
              </p>

              <div className="mt-6 flex flex-wrap gap-4">
                <a
                  href="/auth/register"
                  className="rounded-2xl bg-[#22C55E] px-7 py-3.5 text-base font-bold text-white shadow-lg shadow-green-500/30 transition hover:-translate-y-0.5 hover:shadow-green-500/50"
                >
                  Criar conta grátis
                </a>
                <a
                  href="#como-funciona"
                  className="flex items-center gap-2 rounded-2xl border border-white/20 bg-white/5 px-7 py-3.5 text-base font-medium text-white/80 transition hover:bg-white/10"
                >
                  <span className="flex h-6 w-6 items-center justify-center rounded-full bg-white/20 text-xs">▶</span>
                  Ver como funciona
                </a>
              </div>

              <div className="mt-5 flex flex-wrap gap-5 text-sm text-white/45">
                <span className="flex items-center gap-1.5">
                  <span className="text-[#22C55E]">✓</span> Grátis para cotar na sua região
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="text-[#22C55E]">✓</span> Trial 14 dias para distribuidoras
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="text-[#22C55E]">✓</span> Sem comissão por venda
                </span>
              </div>
            </div>

            {/* Mock UI */}
            <div className="hidden lg:flex lg:justify-end">
              <div className="relative w-full max-w-[440px]">

                {/* Card cotação */}
                <div className="rounded-[2rem] border border-white/10 bg-[#111827] p-4 shadow-2xl shadow-black/60">
                  <div className="rounded-[1.5rem] bg-[#F5F7FB] p-5 text-[#0F172A]">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold uppercase tracking-widest text-[#22C55E]">Nova Cotação</span>
                      <span className="rounded-full bg-[#22C55E]/10 px-2 py-0.5 text-xs font-bold text-[#22C55E]">4 itens</span>
                    </div>
                    <div className="mt-3 space-y-2">
                      {[
                        "Heineken Long Neck 330ml × 24",
                        "Jack Daniel's Tennessee 1L × 2",
                        "Absolut Original 1L × 4",
                        "Tanqueray London Dry 1L × 3",
                      ].map((item) => (
                        <div key={item} className="flex items-center gap-2 rounded-xl bg-white px-3 py-2 shadow-sm">
                          <span className="h-2 w-2 shrink-0 rounded-full bg-[#22C55E]" />
                          <span className="text-xs font-medium">{item}</span>
                        </div>
                      ))}
                    </div>
                    <button className="mt-4 w-full rounded-xl bg-[#0B1220] py-2.5 text-sm font-bold text-white">
                      Enviar para 8 distribuidoras →
                    </button>
                  </div>
                </div>

                {/* Card ranking sobreposto */}
                <div className="absolute -bottom-16 -right-6 w-[280px] rounded-[1.5rem] border border-white/10 bg-[#111827] p-3 shadow-2xl shadow-black/60">
                  <div className="rounded-xl bg-[#F5F7FB] p-3 text-[#0F172A]">
                    <div className="text-[10px] font-bold uppercase tracking-widest text-[#5EEAD4]">
                      Ranking de Preços
                    </div>
                    <div className="mt-2 space-y-1.5">
                      {[
                        { name: "Dist. Silva & Cia", price: "R$ 1.240", tag: "Mais barato", best: true },
                        { name: "Bebidas Norte",     price: "R$ 1.295", tag: "",            best: false },
                        { name: "Atacadão Drink",    price: "R$ 1.380", tag: "Mais rápido", best: false },
                      ].map((d, i) => (
                        <div
                          key={d.name}
                          className={`flex items-center justify-between rounded-lg px-2.5 py-1.5 ${
                            d.best ? "border border-[#22C55E]/30 bg-[#22C55E]/10" : "bg-white"
                          }`}
                        >
                          <div className="flex items-center gap-1.5">
                            <span className="text-[10px] font-bold text-slate-400">{i + 1}°</span>
                            <span className="text-xs font-bold">{d.name}</span>
                          </div>
                          <div className="text-right">
                            <div className={`text-xs font-black ${d.best ? "text-[#22C55E]" : "text-slate-700"}`}>
                              {d.price}
                            </div>
                            {d.tag && (
                              <span className="text-[9px] font-bold text-[#22C55E]">{d.tag}</span>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

              </div>
            </div>
          </div>
        </section>

        {/* ══ MARQUEE de tipos de clientes ══════════════════════════════════════ */}
        <section className="overflow-hidden border-y border-[#DBEAFE] bg-white py-8">
          <p className="mb-5 text-center text-[11px] font-bold uppercase tracking-[0.22em] text-slate-400">
            Para bares, restaurantes, adegas e muito mais
          </p>
          <div className="relative">
            <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-24 bg-gradient-to-r from-white to-transparent" />
            <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-24 bg-gradient-to-l from-white to-transparent" />
            <div className="overflow-hidden">
              <div className="marquee-track gap-5">
                {[...clientTypes, ...clientTypes].map((label, i) => (
                  <div
                    key={i}
                    className="flex shrink-0 items-center rounded-2xl border border-[#DBEAFE] bg-[#F5F7FB] px-6 py-3"
                  >
                    <span className="text-sm font-bold uppercase tracking-wider text-slate-700">{label}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* ══ COMO FUNCIONA — intro ════════════════════════════════════════════ */}
        <section id="como-funciona" className="mx-auto max-w-3xl px-4 pt-9 pb-4 text-center lg:px-5">
          <span className="text-sm font-bold uppercase tracking-[0.18em] text-[#22C55E]">
            Como funciona
          </span>
          <h2 className="mt-4 text-4xl font-black leading-tight md:text-5xl">
            Do produto ao pedido em três passos.
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-lg text-slate-600">
            Você monta a cotação, a plataforma encontra os melhores preços e você escolhe para quem enviar. Tudo em minutos.
          </p>
        </section>

        {/* ══ SEÇÕES ALTERNADAS ═════════════════════════════════════════════════ */}

        {/* 01 — Monte e cote */}
        <section className="mx-auto max-w-7xl px-6 py-10 lg:px-8">
          <div className="grid items-center gap-9 lg:grid-cols-[1fr_1.1fr]">

            {/* Texto */}
            <div>
              <span className="text-sm font-bold uppercase tracking-[0.18em] text-[#22C55E]">
                01. Monte e cote
              </span>
              <h2 className="mt-4 text-4xl font-black leading-tight md:text-5xl">
                Produtos, prazos e preços de{" "}
                <span className="text-[#22C55E]">todas as distribuidoras lado a lado.</span>
              </h2>
              <p className="mt-5 text-lg leading-relaxed text-slate-600">
                Você adiciona os produtos e o prazo desejado. A plataforma busca todas as distribuidoras da sua região que têm os itens disponíveis e monta a comparação automaticamente — preço por produto e data real de entrega calculada pela rota de cada distribuidora.
              </p>
              <ul className="mt-7 space-y-3 text-slate-700">
                {[
                  "Busque por produto: Heineken, Jack Daniel's, Absolut…",
                  "Veja o menor preço de cada produto por distribuidora",
                  "Monte o pedido ideal combinando distribuidoras",
                  "Amplie para outras regiões de SP com o plano Pro",
                ].map((item) => (
                  <li key={item} className="flex items-start gap-3">
                    <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-[#22C55E]/15 text-xs font-bold text-[#22C55E]">
                      ✓
                    </span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Mockup — ranking por produto (ilustrativo estático) */}
            <div className="overflow-hidden rounded-[2rem] border border-[#DBEAFE] bg-[#F5F7FB] shadow-xl shadow-slate-200/80">

              {/* Header */}
              <div className="border-b border-[#DBEAFE] bg-white px-5 py-3.5 flex items-center justify-between">
                <div>
                  <p className="text-xs font-black uppercase tracking-widest text-[#0F172A]">Ranking de preços</p>
                  <p className="text-[10px] text-slate-400">2 produtos · 3 distribuidoras</p>
                </div>
                <div className="flex gap-1.5">
                  {["Mais barato", "Mais rápido"].map((f) => (
                    <span key={f} className={`rounded-full px-2.5 py-1 text-[10px] font-bold ${f === "Mais barato" ? "bg-[#2563EB] text-white" : "border border-[#DBEAFE] bg-white text-slate-500"}`}>
                      {f}
                    </span>
                  ))}
                </div>
              </div>

              <div className="space-y-2.5 p-3">

                {/* ── Card produto 1 ── */}
                {[
                  {
                    name: "Heineken Long Neck 330ml",
                    qty: 24,
                    from: "R$ 4,00/un",
                    offers: [
                      { dist: "Dist. Beta Drinks",     price: "R$ 4,00/un",  total: "R$ 96,00",  date: "quinta 17/04", checked: true,  cheapest: true  },
                      { dist: "Dist. Alpha Bebidas",   price: "R$ 4,20/un",  total: "R$ 100,80", date: "quinta 17/04", checked: false, cheapest: false },
                      { dist: "Dist. Gamma Comercial", price: "R$ 4,50/un",  total: "R$ 108,00", date: "quarta 16/04", checked: false, cheapest: false },
                    ],
                  },
                  {
                    name: "Jack Daniel's Tennessee 1L",
                    qty: 2,
                    from: "R$ 69,90/un",
                    offers: [
                      { dist: "Dist. Beta Drinks",     price: "R$ 69,90/un", total: "R$ 139,80", date: "quinta 17/04", checked: true,  cheapest: true  },
                      { dist: "Dist. Alpha Bebidas",   price: "R$ 72,00/un", total: "R$ 144,00", date: "quinta 17/04", checked: false, cheapest: false },
                      { dist: "Dist. Gamma Comercial", price: "R$ 74,00/un", total: "R$ 148,00", date: "quinta 17/04", checked: false, cheapest: false },
                    ],
                  },
                ].map((product) => (
                  <div
                    key={product.name}
                    className="overflow-hidden rounded-2xl border border-[#DBEAFE] bg-white shadow-sm"
                  >
                    {/* Cabeçalho do produto */}
                    <div className="flex items-center justify-between border-b border-[#DBEAFE] px-4 py-3">
                      <div>
                        <p className="text-xs font-bold text-[#0F172A]">{product.name}</p>
                        <p className="text-[10px] text-slate-400">
                          Quantidade: {product.qty} un · {product.offers.length} ofertas
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-[10px] text-slate-400">A partir de</p>
                        <p className="text-xs font-black text-[#2563EB]">{product.from}</p>
                      </div>
                    </div>

                    {/* Ofertas */}
                    <ul className="divide-y divide-[#DBEAFE]">
                      {product.offers.map((offer) => (
                        <li
                          key={offer.dist}
                          className={`flex items-center gap-2.5 px-4 py-2.5 ${offer.checked ? "bg-[#EFF6FF]" : ""}`}
                        >
                          {/* Checkbox */}
                          <div className={`flex h-3.5 w-3.5 shrink-0 items-center justify-center rounded border ${offer.checked ? "border-[#2563EB] bg-[#2563EB]" : "border-slate-300 bg-white"}`}>
                            {offer.checked && (
                              <svg className="h-2 w-2 text-white" viewBox="0 0 10 8" fill="none">
                                <path d="M1 4l3 3 5-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                              </svg>
                            )}
                          </div>

                          {/* Distribuidora + badge */}
                          <div className="flex flex-1 min-w-0 items-center gap-1.5">
                            <span className={`truncate text-[11px] font-medium ${offer.checked ? "text-[#2563EB]" : "text-[#0F172A]"}`}>
                              {offer.dist}
                            </span>
                            {offer.cheapest && (
                              <span className="shrink-0 rounded-full bg-green-100 px-1.5 py-0.5 text-[8px] font-bold uppercase text-green-700">
                                Mais barato
                              </span>
                            )}
                          </div>

                          {/* Preço + data */}
                          <div className="shrink-0 text-right">
                            <p className={`text-[11px] font-black ${offer.checked ? "text-[#2563EB]" : "text-[#0F172A]"}`}>
                              {offer.price}
                            </p>
                            <p className="text-[9px] text-slate-400">{offer.date}</p>
                          </div>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}

              </div>

              {/* Rodapé fixo */}
              <div className="border-t border-[#DBEAFE] bg-white px-4 py-3.5 flex items-center justify-between gap-3">
                <div>
                  <p className="text-[11px] font-bold text-[#0F172A]">2 itens selecionados · 1 distribuidora</p>
                  <p className="text-[10px] text-slate-400">
                    Total: <span className="font-black text-[#2563EB]">R$ 235,80</span>
                  </p>
                </div>
                <button className="shrink-0 rounded-xl bg-[#0B1220] px-4 py-2 text-[11px] font-bold text-white">
                  Confirmar cotação →
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* 02 — Ranking automático */}
        <section className="bg-[#0B1220] py-10 text-white">
          <div className="mx-auto max-w-7xl px-4 lg:px-5">
            <div className="grid items-center gap-9 lg:grid-cols-2">

              {/* Mockup — Sugestão Inteligente (ilustrativo estático) */}
              <div className="order-2 overflow-hidden rounded-[2rem] bg-[#2563EB] shadow-2xl shadow-blue-900/50 lg:order-1">

                {/* Header do card */}
                <div className="px-6 pb-4 pt-6">
                  <span className="rounded-full bg-white/20 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-white">
                    Sugestão inteligente
                  </span>
                  <h3 className="mt-3 text-xl font-semibold text-white">
                    Melhor combinação de preços
                  </h3>
                  <p className="mt-1 text-sm text-white/65">
                    O menor preço disponível para cada produto da sua cotação.
                  </p>
                </div>

                {/* Lista de produtos + distribuidoras */}
                <div className="mx-5 mb-5 overflow-hidden rounded-2xl bg-white/10">
                  {[
                    { product: "Heineken LN 330ml × 24",  dist: "Dist. Beta Drinks",     total: "R$ 96,00",  date: "quarta, 16/04" },
                    { product: "Jack Daniel's 1L × 2",    dist: "Dist. Beta Drinks",     total: "R$ 139,80", date: "quarta, 16/04" },
                    { product: "Absolut Vodka 1L × 4",    dist: "Dist. Alpha Bebidas",   total: "R$ 208,00", date: "quinta, 17/04" },
                    { product: "Tanqueray 1L × 3",         dist: "Dist. Gamma Comercial", total: "R$ 231,00", date: "terça, 15/04"  },
                  ].map((row, i, arr) => (
                    <div
                      key={row.product}
                      className={[
                        "flex items-start gap-3 px-4 py-3 text-sm",
                        i < arr.length - 1 ? "border-b border-white/10" : "",
                      ].join(" ")}
                    >
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-white truncate">{row.product}</p>
                        <p className="text-xs text-white/55">{row.dist} · 📅 {row.date}</p>
                      </div>
                      <p className="shrink-0 font-bold text-white">{row.total}</p>
                    </div>
                  ))}
                </div>

                {/* Rodapé: total + botão */}
                <div className="flex items-center justify-between border-t border-white/20 px-6 py-5">
                  <div>
                    <p className="text-[10px] font-bold uppercase tracking-wide text-white/55">
                      Total combinado
                    </p>
                    <p className="text-2xl font-semibold text-white">R$ 674,80</p>
                    <p className="mt-0.5 text-xs text-white/55">
                      3 distribuidoras · entregas entre 15/04 e 17/04
                    </p>
                  </div>
                  <button className="rounded-xl bg-white px-5 py-2.5 text-sm font-bold text-[#2563EB] transition hover:opacity-90">
                    Usar esta sugestão →
                  </button>
                </div>
              </div>

              {/* Texto */}
              <div className="order-1 lg:order-2">
                <span className="text-sm font-bold uppercase tracking-[0.18em] text-[#5EEAD4]">
                  02. Ranking automático
                </span>
                <h2 className="mt-4 text-4xl font-black leading-tight md:text-5xl">
                  Compare preços e prazos{" "}
                  <span className="text-[#22C55E]">lado a lado.</span>
                </h2>
                <p className="mt-5 text-lg leading-relaxed text-white/60">
                  O ranking é gerado automaticamente com as distribuidoras que atendem sua região, têm o produto disponível e entregam no prazo desejado. Ordenado por menor preço total — com data real calculada pela rota de entrega.
                </p>
                <ul className="mt-7 space-y-3 text-white/70">
                  {[
                    { text: "Filtragem automática por região e disponibilidade" },
                    { text: "Data de entrega calculada pela rota e horário de corte" },
                    { text: "Distribuidoras fora do prazo aparecem com aviso claro" },
                  ].map((item) => (
                    <li key={item.text} className="flex items-start gap-3">
                      <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-[#22C55E]/20 text-xs font-bold text-[#22C55E]">
                        ✓
                      </span>
                      <span>{item.text}</span>
                    </li>
                  ))}
                </ul>

                {/* Sugestão inteligente — destaque */}
                <div className="mt-5 rounded-2xl border border-[#2563EB]/40 bg-[#2563EB]/10 p-5">
                  <div className="flex items-start gap-3">
                    <span className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-[#2563EB]/30 text-sm">
                      ✦
                    </span>
                    <div>
                      <p className="text-sm font-bold text-white">Sugestão inteligente</p>
                      <p className="mt-1 text-sm text-white/60">
                        A plataforma monta automaticamente a combinação de menor custo total — escolhendo o melhor preço de cada produto entre todas as distribuidoras disponíveis. Você confirma com um clique.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 03 — Envie por email e WhatsApp */}
        <section className="mx-auto max-w-7xl px-6 py-10 lg:px-8">
          <div className="grid items-center gap-9 lg:grid-cols-2">

            {/* Texto */}
            <div>
              <span className="text-sm font-bold uppercase tracking-[0.18em] text-[#22C55E]">
                03. Envie a cotação
              </span>
              <h2 className="mt-4 text-4xl font-black leading-tight md:text-5xl">
                Um clique.{" "}
                <span className="text-[#22C55E]">Distribuidora notificada</span>{" "}
                por WhatsApp e E-mail.
              </h2>
              <p className="mt-5 text-lg leading-relaxed text-slate-600">
                Ao confirmar, você escolhe enviar por WhatsApp, por e-mail ou pelos dois ao mesmo tempo. Cada distribuidora recebe os itens, quantidades e prazo na hora. A negociação e o fechamento acontecem diretamente com a distribuidora. A HUBBY faz a ponte.
              </p>
              <ul className="mt-7 space-y-3 text-slate-700">
                {[
                  "Envio por WhatsApp e/ou E-mail, você escolhe",
                  "Cada distribuidora recebe a cotação completa",
                  "A negociação acontece diretamente com a distribuidora",
                  "Sem comissão da plataforma por venda",
                ].map((item) => (
                  <li key={item} className="flex items-start gap-3">
                    <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-[#22C55E]/15 text-xs font-bold text-[#22C55E]">
                      ✓
                    </span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Mockup — tela de envio */}
            <div className="rounded-[2rem] border border-[#DBEAFE] bg-white shadow-xl shadow-slate-200/80 overflow-hidden">

              {/* Header */}
              <div className="border-b border-[#DBEAFE] bg-[#F5F7FB] px-5 py-3">
                <div className="text-xs font-black uppercase tracking-widest text-[#0F172A]">Enviar cotação</div>
                <div className="text-[10px] text-slate-500 mt-0.5">2 distribuidoras selecionadas · 4 produtos</div>
              </div>

              <div className="p-5 space-y-3">

                {/* Distribuidoras que vão receber */}
                {[
                  { initials: "DS", name: "Dist. Silva & Cia",  email: "comercial@silva.com.br",    phone: "(11) 98xxx-xxxx", suggested: true  },
                  { initials: "BN", name: "Bebidas Norte Atacado", email: "pedidos@bebidasnorte.com", phone: "(11) 97xxx-xxxx", suggested: false },
                ].map((d) => (
                  <div key={d.name} className={`rounded-2xl border p-3.5 ${d.suggested ? "border-amber-200 bg-amber-50" : "border-[#DBEAFE] bg-[#F5F7FB]"}`}>
                    <div className="flex items-center gap-2.5">
                      <div className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-xs font-black text-white ${d.suggested ? "bg-amber-500" : "bg-slate-700"}`}>
                        {d.initials}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs font-bold text-[#0F172A]">{d.name}</span>
                          {d.suggested && <span className="text-[9px] font-bold text-amber-600">Sugerida</span>}
                        </div>
                      </div>
                    </div>
                    {/* Canais */}
                    <div className="mt-2.5 flex gap-2">
                      <div className="flex flex-1 items-center gap-1.5 rounded-xl border border-[#DBEAFE] bg-white px-2.5 py-1.5">
                        {/* Email icon */}
                        <svg className="h-3 w-3 shrink-0 text-[#3B82F6]" viewBox="0 0 16 12" fill="none">
                          <rect x="1" y="1" width="14" height="10" rx="1.5" stroke="currentColor" strokeWidth="1.3"/>
                          <path d="M1.5 2L8 7.5 14.5 2" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round"/>
                        </svg>
                        <span className="text-[10px] font-medium text-slate-600 truncate">{d.email}</span>
                      </div>
                      <div className="flex flex-1 items-center gap-1.5 rounded-xl border border-[#DBEAFE] bg-white px-2.5 py-1.5">
                        {/* WhatsApp icon */}
                        <svg className="h-3 w-3 shrink-0 text-[#22C55E]" viewBox="0 0 16 16" fill="currentColor">
                          <path d="M8 1a7 7 0 00-6.07 10.47L1 15l3.67-.9A7 7 0 108 1zm0 1.4a5.6 5.6 0 110 11.2 5.6 5.6 0 010-11.2zm-2.1 2.8c-.15 0-.38.06-.58.28-.2.23-.76.75-.76 1.82s.78 2.11.89 2.26c.11.14 1.53 2.34 3.7 3.19.52.2.92.32 1.23.41.52.15.99.13 1.36.08.42-.06 1.28-.52 1.46-1.03.18-.5.18-.93.13-1.02-.05-.09-.19-.14-.4-.24-.2-.1-1.2-.59-1.39-.66-.18-.07-.32-.1-.45.1-.14.2-.52.66-.64.8-.12.14-.24.16-.44.05-.2-.1-.86-.32-1.63-1-.6-.54-1.01-1.2-1.13-1.4-.12-.21-.01-.32.09-.42.09-.09.2-.24.3-.36.1-.12.13-.2.2-.34.06-.14.03-.26-.02-.36-.05-.1-.45-1.09-.62-1.49-.16-.38-.33-.33-.45-.33h-.39z"/>
                        </svg>
                        <span className="text-[10px] font-medium text-slate-600">{d.phone}</span>
                      </div>
                    </div>
                  </div>
                ))}

                {/* Botões de envio */}
                <div className="pt-1 space-y-2">
                  <button className="flex w-full items-center justify-center gap-2 rounded-2xl bg-[#0B1220] py-3 text-sm font-bold text-white">
                    <svg className="h-4 w-4" viewBox="0 0 16 16" fill="currentColor">
                      <path d="M8 1a7 7 0 00-6.07 10.47L1 15l3.67-.9A7 7 0 108 1zm0 1.4a5.6 5.6 0 110 11.2 5.6 5.6 0 010-11.2zm-2.1 2.8c-.15 0-.38.06-.58.28-.2.23-.76.75-.76 1.82s.78 2.11.89 2.26c.11.14 1.53 2.34 3.7 3.19.52.2.92.32 1.23.41.52.15.99.13 1.36.08.42-.06 1.28-.52 1.46-1.03.18-.5.18-.93.13-1.02-.05-.09-.19-.14-.4-.24-.2-.1-1.2-.59-1.39-.66-.18-.07-.32-.1-.45.1-.14.2-.52.66-.64.8-.12.14-.24.16-.44.05-.2-.1-.86-.32-1.63-1-.6-.54-1.01-1.2-1.13-1.4-.12-.21-.01-.32.09-.42.09-.09.2-.24.3-.36.1-.12.13-.2.2-.34.06-.14.03-.26-.02-.36-.05-.1-.45-1.09-.62-1.49-.16-.38-.33-.33-.45-.33h-.39z"/>
                    </svg>
                    Enviar por WhatsApp e E-mail
                  </button>
                  <div className="grid grid-cols-2 gap-2">
                    <button className="flex items-center justify-center gap-1.5 rounded-xl border border-[#DBEAFE] bg-[#F5F7FB] py-2 text-xs font-bold text-slate-600">
                      <svg className="h-3.5 w-3.5 text-[#25D366]" viewBox="0 0 16 16" fill="currentColor">
                        <path d="M8 1a7 7 0 00-6.07 10.47L1 15l3.67-.9A7 7 0 108 1zm0 1.4a5.6 5.6 0 110 11.2 5.6 5.6 0 010-11.2zm-2.1 2.8c-.15 0-.38.06-.58.28-.2.23-.76.75-.76 1.82s.78 2.11.89 2.26c.11.14 1.53 2.34 3.7 3.19.52.2.92.32 1.23.41.52.15.99.13 1.36.08.42-.06 1.28-.52 1.46-1.03.18-.5.18-.93.13-1.02-.05-.09-.19-.14-.4-.24-.2-.1-1.2-.59-1.39-.66-.18-.07-.32-.1-.45.1-.14.2-.52.66-.64.8-.12.14-.24.16-.44.05-.2-.1-.86-.32-1.63-1-.6-.54-1.01-1.2-1.13-1.4-.12-.21-.01-.32.09-.42.09-.09.2-.24.3-.36.1-.12.13-.2.2-.34.06-.14.03-.26-.02-.36-.05-.1-.45-1.09-.62-1.49-.16-.38-.33-.33-.45-.33h-.39z"/>
                      </svg>
                      Só WhatsApp
                    </button>
                    <button className="flex items-center justify-center gap-1.5 rounded-xl border border-[#DBEAFE] bg-[#F5F7FB] py-2 text-xs font-bold text-slate-600">
                      <svg className="h-3.5 w-3.5 text-[#3B82F6]" viewBox="0 0 16 12" fill="none">
                        <rect x="1" y="1" width="14" height="10" rx="1.5" stroke="currentColor" strokeWidth="1.3"/>
                        <path d="M1.5 2L8 7.5 14.5 2" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round"/>
                      </svg>
                      Só E-mail
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ══ NÚMEROS ANIMADOS ══════════════════════════════════════════════════ */}
        <section className="bg-[#22C55E] py-8 text-white">
          <div className="mx-auto max-w-7xl px-4 lg:px-5">
            <p className="text-center text-xs font-bold uppercase tracking-[0.22em] text-white/65">
              A plataforma em números
            </p>
            <div className="mt-8 grid gap-6 md:grid-cols-3">
              {[
                {
                  value: 50,
                  suffix: "+",
                  label: "Distribuidoras cadastradas",
                  sub: "e crescendo toda semana",
                },
                {
                  value: 120,
                  suffix: "",
                  label: "Municípios atendidos",
                  sub: "em São Paulo e região",
                },
                {
                  value: 23,
                  suffix: "%",
                  label: "Economia média por cotação",
                  sub: "vs. compra por um único fornecedor",
                },
              ].map((stat) => (
                <div key={stat.label} className="text-center">
                  <div className="text-6xl font-black tracking-tight md:text-7xl">
                    <AnimatedNumber target={stat.value} suffix={stat.suffix} />
                  </div>
                  <div className="mt-2 text-lg font-bold">{stat.label}</div>
                  <div className="mt-1 text-sm text-white/60">{stat.sub}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ══ BENEFÍCIOS POR PERFIL ════════════════════════════════════════════ */}
        <section id="beneficios" className="bg-[#F5F7FB] py-9">
          <div className="mx-auto max-w-7xl px-4 lg:px-5">
            <div className="mb-8 text-center">
              <span className="text-sm font-bold uppercase tracking-[0.18em] text-[#22C55E]">
                Para quem é a HUBBY
              </span>
              <h2 className="mt-4 text-3xl font-black md:text-4xl">
                Benefícios para cada lado.
              </h2>
            </div>

            <div className="grid gap-4 lg:grid-cols-2">

              {/* Compradores */}
              <div className="rounded-[2rem] border border-[#DBEAFE] bg-white p-8 shadow-sm">
                <div className="mb-5 inline-flex rounded-2xl border border-[#DBEAFE] bg-[#F5F7FB] px-4 py-2 text-xs font-black uppercase tracking-widest text-slate-500">
                  Para compradores
                </div>
                <h3 className="text-2xl font-black text-[#0F172A]">
                  Compre melhor sem sair do lugar.
                </h3>
                <p className="mt-3 text-slate-600">
                  Bares, restaurantes, adegas, hotéis e mercados que querem economizar no estoque de bebidas sem gastar horas no telefone.
                </p>
                <ul className="mt-4 space-y-3">
                  {[
                    { title: "Compare várias distribuidoras de uma vez", desc: "Uma cotação, múltiplas respostas. Sem ligar para cada um." },
                    { title: "Veja o menor preço por produto", desc: "O ranking mostra quem tem o melhor preço para cada item." },
                    { title: "Economia real no estoque", desc: "Clientes economizam em média 23% em relação ao fornecedor único." },
                    { title: "Histórico e recompra com 1 clique", desc: "Repita pedidos anteriores sem montar tudo do zero." },
                  ].map((b) => (
                    <li key={b.title} className="flex items-start gap-3">
                      <span className="mt-1 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-[#22C55E]/15 text-xs font-bold text-[#22C55E]">✓</span>
                      <div>
                        <p className="text-sm font-bold text-[#0F172A]">{b.title}</p>
                        <p className="text-xs text-slate-500">{b.desc}</p>
                      </div>
                    </li>
                  ))}
                </ul>
                <div className="mt-7 flex items-center justify-between border-t border-[#DBEAFE] pt-5">
                  <span className="text-sm font-bold text-[#22C55E]">Acesso 100% gratuito</span>
                  <a href="/auth/register" className="rounded-xl bg-[#22C55E] px-5 py-2.5 text-sm font-bold text-white transition hover:bg-green-500">
                    Criar conta
                  </a>
                </div>
              </div>

              {/* Distribuidoras */}
              <div className="rounded-[2rem] border border-[#DBEAFE] bg-[#0B1220] p-8 shadow-sm text-white">
                <div className="mb-5 inline-flex rounded-2xl border border-white/10 bg-white/10 px-4 py-2 text-xs font-black uppercase tracking-widest text-slate-300">
                  Para distribuidoras
                </div>
                <h3 className="text-2xl font-black text-white">
                  Novos clientes todo dia, sem depender de indicação.
                </h3>
                <p className="mt-3 text-slate-400">
                  Distribuidoras que querem crescer a carteira de clientes, organizar a equipe comercial e responder cotações com mais agilidade.
                </p>
                <ul className="mt-4 space-y-3">
                  {[
                    { title: "Apareça nas cotações de quem compra na sua região", desc: "Clientes da sua área já recebem seu preço no ranking automaticamente." },
                    { title: "Receba leads pelo painel e WhatsApp", desc: "Notificação em tempo real para o time comercial não perder nenhuma oportunidade." },
                    { title: "Sem comissão por venda", desc: "A mensalidade é fixa. Cada venda fechada é 100% sua." },
                    { title: "Estoque e preços sempre atualizados", desc: "Integração ERP no plano Avançado sincroniza tudo automaticamente." },
                  ].map((b) => (
                    <li key={b.title} className="flex items-start gap-3">
                      <span className="mt-1 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-[#22C55E]/20 text-xs font-bold text-[#22C55E]">✓</span>
                      <div>
                        <p className="text-sm font-bold text-white">{b.title}</p>
                        <p className="text-xs text-slate-400">{b.desc}</p>
                      </div>
                    </li>
                  ))}
                </ul>
                <div className="mt-7 flex items-center justify-between border-t border-white/10 pt-5">
                  <span className="text-sm font-bold text-[#5EEAD4]">Trial 14 dias grátis</span>
                  <a href="/auth/register" className="rounded-xl bg-[#22C55E] px-5 py-2.5 text-sm font-bold text-white transition hover:bg-green-500">
                    Começar trial
                  </a>
                </div>
              </div>

            </div>
          </div>
        </section>

        {/* ══ APP MOBILE ════════════════════════════════════════════════════════ */}
        <section className="border-y border-[#DBEAFE] bg-white">
          <div className="mx-auto max-w-7xl px-6 py-10 lg:px-8">
            <div className="grid items-center gap-6 lg:grid-cols-[1fr_auto]">

              {/* Texto */}
              <div>
                <span className="inline-flex items-center gap-2 rounded-full border border-[#22C55E]/30 bg-[#22C55E]/8 px-3 py-1 text-xs font-bold uppercase tracking-widest text-[#22C55E]">
                  <span className="h-1.5 w-1.5 rounded-full bg-[#22C55E]" />
                  Disponível para iOS e Android
                </span>
                <h2 className="mt-4 text-3xl font-black leading-tight md:text-4xl">
                  Prefere cotar pelo celular?{" "}
                  <span className="text-[#22C55E]">Tem app para isso.</span>
                </h2>
                <p className="mt-3 max-w-lg text-lg text-slate-600">
                  Acesse o ranking de preços, monte pedidos e acompanhe o histórico direto do seu celular. Rápido, sem precisar abrir o computador.
                </p>

                <ul className="mt-5 space-y-2.5 text-slate-700">
                  {[
                    "Cote de qualquer lugar: fila do fornecedor, estoque, em trânsito",
                    "Notificações em tempo real quando distribuidora responder",
                    "Recompra com 1 toque a partir do histórico",
                  ].map((item) => (
                    <li key={item} className="flex items-start gap-2.5 text-sm">
                      <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-[#22C55E]/15 text-xs font-bold text-[#22C55E]">
                        ✓
                      </span>
                      {item}
                    </li>
                  ))}
                </ul>

                {/* Badges das lojas */}
                <div className="mt-7 flex flex-wrap gap-3">
                  <a
                    href="#"
                    className="flex items-center gap-3 rounded-2xl border border-[#0F172A] bg-[#0F172A] px-5 py-3 transition hover:opacity-85"
                  >
                    <svg className="h-6 w-6 text-white" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.8-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/>
                    </svg>
                    <div className="text-left">
                      <p className="text-[10px] font-medium text-white/60">Baixar na</p>
                      <p className="text-sm font-bold text-white">App Store</p>
                    </div>
                  </a>
                  <a
                    href="#"
                    className="flex items-center gap-3 rounded-2xl border border-[#0F172A] bg-[#0F172A] px-5 py-3 transition hover:opacity-85"
                  >
                    <svg className="h-6 w-6 text-white" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M3.18 23.76c.37.2.8.22 1.2.06l12.11-6.99-2.63-2.63-10.68 9.56zm-1.13-19.9a1.95 1.95 0 00-.05.47v19.34c0 .16.02.32.05.47l10.78-10.14L2.05 3.86zm18.8 8.47l-2.6-1.5L14.7 12l3.43 3.17 2.63-1.52c.75-.43.75-1.57 0-2zM4.38.22C3.98.06 3.55.08 3.18.28L13.93 11.1l2.63-2.63L4.38.22z"/>
                    </svg>
                    <div className="text-left">
                      <p className="text-[10px] font-medium text-white/60">Disponível no</p>
                      <p className="text-sm font-bold text-white">Google Play</p>
                    </div>
                  </a>
                </div>
              </div>

              {/* Mini mockup de celular */}
              <div className="hidden lg:block">
                <div className="relative mx-auto w-[200px]">
                  {/* Contorno do celular */}
                  <div className="overflow-hidden rounded-[2.5rem] border-[6px] border-[#0B1220] bg-[#0B1220] shadow-2xl shadow-slate-400/30">
                    {/* Notch */}
                    <div className="flex justify-center pt-2 pb-1">
                      <div className="h-1.5 w-14 rounded-full bg-[#1E293B]" />
                    </div>
                    {/* Tela */}
                    <div className="bg-[#F5F7FB] px-3 pb-4 pt-2">
                      {/* Status bar */}
                      <div className="mb-2 flex items-center justify-between">
                        <span className="text-[8px] font-bold text-slate-400">9:41</span>
                        <div className="flex gap-1">
                          <div className="h-1.5 w-3 rounded-sm bg-slate-300" />
                          <div className="h-1.5 w-1.5 rounded-full bg-slate-300" />
                        </div>
                      </div>
                      {/* Header */}
                      <div className="mb-2 flex items-center justify-between">
                        <span className="text-[9px] font-black uppercase tracking-wider text-[#0F172A]">HUBBY</span>
                        <span className="rounded-full bg-[#22C55E]/15 px-1.5 py-0.5 text-[7px] font-bold text-[#22C55E]">3 novas</span>
                      </div>
                      {/* Cards de cotação */}
                      {[
                        { name: "Heineken LN 330ml", price: "R$ 4,00/un", dist: "Beta Drinks", color: "bg-[#22C55E]" },
                        { name: "Jack Daniel's 1L",  price: "R$ 69,90/un", dist: "Beta Drinks", color: "bg-[#2563EB]" },
                        { name: "Absolut 1L",        price: "R$ 52,00/un", dist: "Alpha Beb.", color: "bg-[#8B5CF6]" },
                      ].map((item) => (
                        <div key={item.name} className="mb-1.5 flex items-center gap-1.5 rounded-xl bg-white px-2 py-1.5 shadow-sm">
                          <div className={`h-5 w-1 shrink-0 rounded-full ${item.color}`} />
                          <div className="flex-1 min-w-0">
                            <p className="truncate text-[8px] font-bold text-[#0F172A]">{item.name}</p>
                            <p className="text-[7px] text-slate-400">{item.dist}</p>
                          </div>
                          <span className="text-[8px] font-black text-[#0F172A]">{item.price}</span>
                        </div>
                      ))}
                      {/* Botão */}
                      <div className="mt-2 rounded-xl bg-[#0B1220] py-1.5 text-center text-[9px] font-bold text-white">
                        Confirmar cotação →
                      </div>
                    </div>
                  </div>
                  {/* Sombra decorativa */}
                  <div className="absolute -bottom-3 left-1/2 h-6 w-32 -translate-x-1/2 rounded-full bg-slate-400/20 blur-xl" />
                </div>
              </div>

            </div>
          </div>
        </section>

        {/* ══ DEPOIMENTOS ═══════════════════════════════════════════════════════ */}
        <section className="bg-[#F5F7FB] py-10">
          <div className="mx-auto max-w-3xl px-4 lg:px-5">
            <div className="text-center">
              <span className="text-sm font-bold uppercase tracking-[0.18em] text-[#22C55E]">
                Depoimentos
              </span>
              <h2 className="mt-4 text-3xl font-black md:text-4xl">
                Quem já usa, não volta atrás.
              </h2>
            </div>

            <div className="mt-12">
              <div className="rounded-[2rem] border border-[#DBEAFE] bg-white p-8 shadow-lg md:p-12">
                <div className="mb-4 flex gap-1">
                  {Array.from({ length: testimonials[activeTestimonial].stars }).map((_, i) => (
                    <span key={i} className="text-xl text-[#22C55E]">★</span>
                  ))}
                </div>
                <blockquote className="text-xl font-medium leading-relaxed text-[#0F172A] md:text-2xl">
                  &ldquo;{testimonials[activeTestimonial].text}&rdquo;
                </blockquote>
                <div className="mt-4 flex items-center gap-4">
                  <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-[#22C55E]/10 text-base font-black text-[#22C55E]">
                    {testimonials[activeTestimonial].name.charAt(0)}
                  </div>
                  <div>
                    <div className="font-bold">{testimonials[activeTestimonial].name}</div>
                    <div className="text-sm text-slate-500">
                      {testimonials[activeTestimonial].role} · {testimonials[activeTestimonial].company}
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-4 flex justify-center gap-2">
                {testimonials.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveTestimonial(i)}
                    className={`h-2 rounded-full transition-all duration-300 ${
                      i === activeTestimonial ? "w-8 bg-[#22C55E]" : "w-2 bg-slate-300"
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* ══ PLANOS ════════════════════════════════════════════════════════════ */}
        <section id="planos" className="bg-[#050D1A] py-9">
          <div className="mx-auto max-w-5xl px-4 lg:px-5">

            {/* ── Cabeçalho ── */}
            <div className="mb-8 text-center">
              <span className="inline-block rounded-full border border-white/10 bg-white/5 px-4 py-1.5 text-xs font-bold uppercase tracking-[0.2em] text-slate-400">
                Planos e preços
              </span>
              <h2 className="mt-4 text-4xl font-black text-white md:text-[2.75rem]">
                Para distribuidoras que querem crescer.
              </h2>
              <p className="mt-4 text-base text-slate-400">
                Compradores entram grátis. Distribuidoras pagam por performance e visibilidade.
              </p>
            </div>

            {/* ── Toggle de período ── */}
            <div className="mb-8 flex justify-center">
              <div className="flex rounded-2xl border border-white/10 bg-white/5 p-1 gap-1">
                {(["monthly", "quarterly", "semiannual", "annual"] as PeriodKey[]).map((p) => (
                  <button
                    key={p}
                    onClick={() => setPeriod(p)}
                    className={[
                      "relative rounded-xl px-4 py-2 text-[13px] font-semibold transition-all duration-200",
                      period === p
                        ? "bg-white text-[#0B1220] shadow-sm"
                        : "text-slate-400 hover:text-white",
                    ].join(" ")}
                  >
                    {PERIOD_LABELS[p]}
                    {p === "annual" && (
                      <span className="absolute -top-2.5 -right-1 rounded-full bg-[#22C55E] px-1.5 py-0.5 text-[9px] font-black uppercase tracking-wide text-white leading-none">
                        -20%
                      </span>
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* ── Cards das distribuidoras ── */}
            <div>
              <div className="mb-5 flex items-end justify-between gap-4 border-b border-white/10 pb-5">
                <div>
                  <p className="text-[11px] font-bold uppercase tracking-[0.2em] text-slate-500">Para</p>
                  <h3 className="text-2xl font-black text-white">Distribuidoras</h3>
                </div>
                <p className="text-right text-[11px] text-slate-400">
                  {period === "monthly" ? "14 dias grátis · " : ""}cancele quando quiser · sem comissão
                </p>
              </div>

              <div className="grid items-stretch gap-3 md:grid-cols-3">

                {/* Starter */}
                {(["starter", "pro", "business"] as const).map((planKey) => {
                  const isPro = planKey === "pro";
                  const names = { starter: "Starter", pro: "Pro", business: "Business" };
                  const descs = {
                    starter: "Presença garantida onde os compradores estão.",
                    pro: "Para equipes que querem vender mais e perder menos.",
                    business: "Para distribuidoras que querem escalar com controle total.",
                  };
                  const features: Record<string, string[]> = {
                    starter: ["Perfil e portfólio na plataforma", "Cotações via painel e WhatsApp", "Painel com métricas básicas", "1 contato comercial"],
                    pro: ["Tudo do Starter", "Mais usuários com permissões", "Destaque comercial no ranking", "Prioridade em empate técnico", "Histórico completo de cotações", "Selo de distribuidora verificada"],
                    business: ["Tudo do Pro", "Usuários ilimitados", "Hierarquia de equipes", "Integração ERP via webhook", "Relatórios avançados", "Onboarding e suporte dedicados"],
                  };
                  const monthly = DIST_MONTHLY[planKey][period];
                  const total   = DIST_TOTAL[planKey][period];
                  const months  = PERIOD_MONTHS[period];

                  return (
                    <div
                      key={planKey}
                      className={[
                        "relative flex flex-col rounded-2xl px-6 py-6",
                        isPro
                          ? "bg-[#0B1220] shadow-xl ring-2 ring-[#22C55E]/40"
                          : "border border-white/10 bg-white/5",
                      ].join(" ")}
                    >
                      {isPro && (
                        <div className="absolute -top-3 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-full bg-[#22C55E] px-4 py-0.5 text-[10px] font-black uppercase tracking-widest text-white">
                          Mais popular
                        </div>
                      )}

                      <p className={`text-[10px] font-bold uppercase tracking-[0.18em] ${isPro ? "text-[#4ADE80]" : "text-slate-500"}`}>
                        HUBBY {names[planKey]}
                      </p>

                      {/* Preço */}
                      <div className="mt-3 leading-none">
                        <div className="flex items-end gap-1">
                          <span className="text-[2rem] font-black text-white">
                            {formatBRL(monthly)}
                          </span>
                          <span className="mb-0.5 text-xs text-slate-500">/mês</span>
                        </div>
                        {period !== "monthly" && (
                          <p className="mt-1 text-[11px] text-slate-500">
                            {formatBRL(total)} cobrados {months === 3 ? "trimestralmente" : months === 6 ? "semestralmente" : "anualmente"}
                          </p>
                        )}
                        {period === "monthly" && (
                          <p className="mt-1 text-[11px] text-slate-600">cobrança mensal</p>
                        )}
                      </div>

                      <p className={`mt-3 text-[13px] ${isPro ? "text-slate-400" : "text-slate-400"}`}>
                        {descs[planKey]}
                      </p>

                      <div className="my-5 h-px bg-white/10" />

                      <ul className={`space-y-2.5 text-[13px] ${isPro ? "text-slate-300" : "text-slate-400"}`}>
                        {features[planKey].map((f) => (
                          <li key={f} className="flex items-start gap-2.5">
                            <span className={`mt-px shrink-0 text-[11px] ${isPro ? "font-bold text-[#22C55E]" : "text-slate-500"}`}>✓</span>
                            {f}
                          </li>
                        ))}
                      </ul>

                      <div className="mt-5 pt-6 border-t border-white/10">
                        <a
                          href={`/auth/register?plan=${planKey}&period=${period}`}
                          className={[
                            "flex w-full items-center justify-center rounded-xl py-3 text-[13px] font-bold transition",
                            isPro
                              ? "bg-[#22C55E] text-white hover:bg-green-500"
                              : "border border-white/15 text-slate-400 hover:border-white/30 hover:text-white",
                          ].join(" ")}
                        >
                          {period === "monthly" ? "Começar teste grátis" : "Começar agora"}
                        </a>
                      </div>
                    </div>
                  );
                })}

              </div>

              {/* Enterprise */}
              <div className="mt-4 flex items-center justify-between rounded-2xl border border-white/10 bg-white/5 px-6 py-4">
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-slate-500">HUBBY Enterprise</p>
                  <p className="mt-1 text-sm font-bold text-white">Sob consulta — para operações de grande escala</p>
                  <p className="mt-0.5 text-[13px] text-slate-400">Usuários ilimitados · SLA garantido · integração sob medida</p>
                </div>
                <a
                  href="mailto:comercial@hubby.com.br"
                  className="shrink-0 rounded-xl border border-white/20 px-5 py-2.5 text-[13px] font-bold text-slate-300 transition hover:border-white/40 hover:text-white"
                >
                  Falar com vendas →
                </a>
              </div>

              <p className="mt-5 text-center text-[11px] text-slate-500">
                Ranking calculado por preço, prazo e disponibilidade.
                Planos superiores ganham destaque comercial em empates técnicos.
              </p>
            </div>

            {/* ── Compradores — faixa compacta ── */}
            <div className="mt-10 rounded-2xl border border-white/10 bg-white/5 p-6">
              <div className="mb-4 flex items-end justify-between gap-4 border-b border-white/10 pb-4">
                <div>
                  <p className="text-[11px] font-bold uppercase tracking-[0.2em] text-slate-500">Para</p>
                  <h3 className="text-lg font-bold text-white">Compradores</h3>
                </div>
                <p className="text-right text-[11px] text-slate-500">
                  Acesso gratuito para sempre · upgrade quando precisar
                </p>
              </div>

              <div className="grid gap-3 md:grid-cols-2">

                {/* Grátis */}
                <div className="flex items-start justify-between gap-4 rounded-xl border border-white/10 bg-white/5 p-5">
                  <div>
                    <div className="flex items-baseline gap-2">
                      <span className="text-sm font-black text-white">Grátis</span>
                      <span className="text-[11px] text-slate-500">para sempre · sem cartão</span>
                    </div>
                    <div className="mt-3 flex flex-wrap gap-x-3 gap-y-1">
                      {["Distribuidoras da região", "Cotações ilimitadas", "Histórico básico"].map((f) => (
                        <span key={f} className="text-[11px] text-slate-400">{f}</span>
                      ))}
                    </div>
                  </div>
                  <a
                    href="/auth/register"
                    className="shrink-0 self-center rounded-lg border border-white/20 bg-white/10 px-4 py-2 text-[12px] font-bold text-slate-300 transition hover:bg-white/15 hover:text-white"
                  >
                    Criar conta grátis
                  </a>
                </div>

                {/* Pro comprador — preço dinâmico */}
                <div className="flex items-start justify-between gap-4 rounded-xl border border-[#22C55E]/30 bg-[#22C55E]/10 p-5">
                  <div>
                    <div className="flex items-baseline gap-2">
                      <span className="text-sm font-black text-white">HUBBY Pro</span>
                      <span className="text-sm font-bold text-[#22C55E]">
                        {formatBRL(BUYER_MONTHLY[period])}/mês
                      </span>
                      {period !== "monthly" && (
                        <span className="text-[10px] text-slate-500">
                          ({formatBRL(BUYER_TOTAL[period])} {PERIOD_MONTHS[period] === 3 ? "tri" : PERIOD_MONTHS[period] === 6 ? "sem" : "ano"})
                        </span>
                      )}
                    </div>
                    <div className="mt-3 flex flex-wrap gap-x-3 gap-y-1">
                      {["Múltiplas regiões de SP", "Até 10 usuários", "Histórico ilimitado", "Alertas de preço"].map((f) => (
                        <span key={f} className="text-[11px] text-slate-400">{f}</span>
                      ))}
                    </div>
                  </div>
                  <a
                    href={`/checkout/comprador?period=${period}`}
                    className="shrink-0 self-center rounded-lg bg-[#22C55E] px-4 py-2 text-[12px] font-bold text-white transition hover:bg-green-500"
                  >
                    Assinar Pro
                  </a>
                </div>

              </div>
            </div>

          </div>
        </section>

        {/* ══ FAQ ═══════════════════════════════════════════════════════════════ */}
        <FaqSection />

        {/* ══ FOOTER ════════════════════════════════════════════════════════════ */}
        <footer className="border-t border-[#DBEAFE] bg-white">
          <div className="mx-auto max-w-7xl px-6 py-10 lg:px-8">
            <div className="grid gap-6 sm:grid-cols-2 md:grid-cols-4">

              {/* Marca */}
              <div>
                <div className="text-base font-black uppercase tracking-[0.22em] text-[#0F172A]">HUBBY</div>
                <p className="mt-3 text-sm leading-relaxed text-slate-500">
                  Plataforma B2B de cotação de bebidas para bares, restaurantes, adegas e distribuidoras.
                </p>
                <div className="mt-5 flex gap-2">
                  {[
                    { label: "LI", title: "LinkedIn" },
                    { label: "IG", title: "Instagram" },
                    { label: "WA", title: "WhatsApp" },
                  ].map((s) => (
                    <a
                      key={s.label}
                      href="#"
                      title={s.title}
                      className="flex h-9 w-9 items-center justify-center rounded-xl border border-[#DBEAFE] bg-[#F5F7FB] text-xs font-bold text-slate-600 transition hover:border-[#22C55E] hover:text-[#22C55E]"
                    >
                      {s.label}
                    </a>
                  ))}
                </div>
              </div>

              {/* Produto */}
              <div>
                <div className="text-xs font-bold uppercase tracking-[0.18em] text-slate-400">Produto</div>
                <ul className="mt-4 space-y-2.5 text-sm text-slate-600">
                  {["Como funciona", "Planos e preços", "Para distribuidoras", "Para compradores"].map(
                    (link) => (
                      <li key={link}>
                        <a href="#" className="transition hover:text-[#22C55E]">{link}</a>
                      </li>
                    )
                  )}
                </ul>
              </div>

              {/* Empresa */}
              <div>
                <div className="text-xs font-bold uppercase tracking-[0.18em] text-slate-400">Empresa</div>
                <ul className="mt-4 space-y-2.5 text-sm text-slate-600">
                  {["Sobre nós", "Blog", "Carreiras", "Contato"].map((link) => (
                    <li key={link}>
                      <a href="#" className="transition hover:text-[#22C55E]">{link}</a>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Contato */}
              <div>
                <div className="text-xs font-bold uppercase tracking-[0.18em] text-slate-400">Contato</div>
                <ul className="mt-4 space-y-2.5 text-sm text-slate-600">
                  <li>
                    <a href="mailto:contato@hubby.com.br" className="transition hover:text-[#22C55E]">
                      contato@hubby.com.br
                    </a>
                  </li>
                  <li>
                    <a
                      href="https://wa.me/5511999999999"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="transition hover:text-[#22C55E]"
                    >
                      WhatsApp comercial
                    </a>
                  </li>
                  <li className="text-slate-400">São Paulo, SP — Brasil</li>
                </ul>
              </div>
            </div>

            <div className="mt-8 flex flex-col items-center justify-between gap-4 border-t border-[#DBEAFE] pt-8 text-xs text-slate-400 md:flex-row">
              <span>© 2026 HUBBY. Todos os direitos reservados.</span>
              <div className="flex gap-5">
                <a href="#" className="transition hover:text-slate-600">Termos de Uso</a>
                <a href="#" className="transition hover:text-slate-600">Privacidade</a>
                <a href="#" className="transition hover:text-slate-600">LGPD</a>
              </div>
            </div>
          </div>
        </footer>

        {/* ══ BOTÃO WHATSAPP FLUTUANTE ══════════════════════════════════════════ */}
        <a
          href="https://wa.me/5511999999999?text=Ol%C3%A1%2C%20gostaria%20de%20saber%20mais%20sobre%20a%20HUBBY"
          target="_blank"
          rel="noopener noreferrer"
          title="Falar no WhatsApp"
          className="fixed bottom-6 right-6 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-[#25D366] text-white shadow-lg shadow-green-500/30 transition hover:-translate-y-1 hover:shadow-xl hover:shadow-green-500/40"
        >
          <svg viewBox="0 0 24 24" className="h-7 w-7 fill-current" aria-hidden="true">
            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z" />
          </svg>
        </a>

      </div>
    </>
  );
}
