"use client";

import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { Navbar } from "@/components/Navbar";
import { Button } from "@/components/ui/Button";
import { useApiToken, apiFetch } from "@/hooks/useApiToken";

// ─── Tipos ────────────────────────────────────────────────────────────────────

type TopDistributor = { name: string; order_count: number; value_cents: number };
type TopProduct     = { product_name: string; brand: string; quote_count: number };

type MonthlyReport = {
  id: string;
  month: number;
  year: number;
  total_quotations: number;
  total_orders: number;
  total_value_cents: number;
  estimated_savings_cents: number;
  avg_distributors_per_quotation: number;
  top_distributors: TopDistributor[];
  top_products: TopProduct[];
  created_at: string;
};

// ─── Helpers ──────────────────────────────────────────────────────────────────

function formatBRL(cents: number): string {
  return new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(cents / 100);
}

function monthLabel(month: number, year: number): string {
  return new Intl.DateTimeFormat("pt-BR", { month: "long", year: "numeric" })
    .format(new Date(year, month - 1, 1));
}

function capitalize(s: string): string {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

// ─── Gráfico de barras inline (SVG) ──────────────────────────────────────────

function SavingsChart({ reports }: { reports: MonthlyReport[] }) {
  const sorted   = [...reports].sort((a, b) => a.year !== b.year ? a.year - b.year : a.month - b.month);
  const maxVal   = Math.max(...sorted.map((r) => r.estimated_savings_cents), 1);
  const barWidth = Math.min(48, Math.floor(520 / Math.max(sorted.length, 1)) - 8);

  return (
    <div className="overflow-x-auto">
      <svg width={Math.max(sorted.length * (barWidth + 8), 300)} height={140} className="block">
        {sorted.map((r, i) => {
          const pct    = r.estimated_savings_cents / maxVal;
          const barH   = Math.max(4, Math.round(pct * 100));
          const x      = i * (barWidth + 8);
          const y      = 100 - barH;
          return (
            <g key={r.id}>
              <rect x={x} y={y} width={barWidth} height={barH} rx={4}
                fill="#22C55E" opacity={0.85} />
              <title>{capitalize(monthLabel(r.month, r.year))}: {formatBRL(r.estimated_savings_cents)}</title>
              <text x={x + barWidth / 2} y={120} textAnchor="middle"
                fontSize={9} fill="#94a3b8">
                {new Intl.DateTimeFormat("pt-BR", { month: "short" }).format(new Date(r.year, r.month - 1))}
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
}

// ─── Exportar CSV ─────────────────────────────────────────────────────────────

function exportCSV(reports: MonthlyReport[]) {
  const rows = [
    ["Mês", "Ano", "Cotações", "Pedidos", "Valor Total (R$)", "Economia Estimada (R$)", "Média Distribuidoras/Cotação"],
    ...reports.map((r) => [
      r.month,
      r.year,
      r.total_quotations,
      r.total_orders,
      (r.total_value_cents / 100).toFixed(2),
      (r.estimated_savings_cents / 100).toFixed(2),
      r.avg_distributors_per_quotation.toFixed(1),
    ]),
  ];

  const csv  = rows.map((r) => r.join(";")).join("\n");
  const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement("a");
  a.href     = url;
  a.download = `hubby-relatorios.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

// ─── Componente principal ─────────────────────────────────────────────────────

export default function RelatoriosPage() {
  const { data: session, status } = useSession({ required: true });
  const router = useRouter();
  const token  = useApiToken();

  const role = (session?.user as { role?: string })?.role ?? "";

  const [reports, setReports]     = useState<MonthlyReport[]>([]);
  const [loading, setLoading]     = useState(true);
  const [generating, setGenerating] = useState(false);
  const [selected, setSelected]   = useState<MonthlyReport | null>(null);

  useEffect(() => {
    if (status === "authenticated" && role && role !== "client") {
      router.replace("/");
    }
  }, [status, role, router]);

  useEffect(() => {
    if (!token) return;
    apiFetch("/api/reports", { method: "GET", token })
      .then(async (r) => {
        const data = await r.json() as { reports: MonthlyReport[] };
        setReports(data.reports ?? []);
        if (data.reports?.length > 0) setSelected(data.reports[0]);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [token]);

  async function generateReport() {
    if (!token) return;
    setGenerating(true);
    const res = await apiFetch("/api/reports", { method: "POST", token });
    const data = await res.json() as { report: MonthlyReport };
    setGenerating(false);
    if (data.report) {
      setReports((prev) => {
        const exists = prev.find((r) => r.id === data.report.id);
        return exists ? prev.map((r) => r.id === data.report.id ? data.report : r) : [data.report, ...prev];
      });
      setSelected(data.report);
    }
  }

  if (loading || status === "loading") {
    return (
      <div className="flex min-h-screen flex-col bg-[#F5F7FB]">
        <Navbar />
        <div className="flex flex-1 items-center justify-center">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-[#22C55E] border-t-transparent" />
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen flex-col bg-[#F5F7FB]">
      <Navbar />

      <main className="mx-auto w-full max-w-3xl px-4 py-10">

        {/* Header */}
        <div className="mb-8 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-[#0F172A]">Relatórios</h1>
            <p className="mt-1 text-sm text-slate-500">Economia e histórico mensal das suas cotações</p>
          </div>
          <div className="flex gap-2">
            {reports.length > 0 && (
              <Button variant="secondary" size="sm" onClick={() => exportCSV(reports)}>
                Exportar CSV
              </Button>
            )}
            <Button size="sm" loading={generating} onClick={generateReport}>
              Gerar relatório
            </Button>
          </div>
        </div>

        {reports.length === 0 ? (
          <div className="rounded-2xl border border-[#DBEAFE] bg-white px-6 py-16 text-center">
            <p className="text-3xl">📊</p>
            <p className="mt-3 font-semibold text-slate-700">Nenhum relatório gerado ainda</p>
            <p className="mt-1 text-sm text-slate-400">
              Relatórios são gerados automaticamente no dia 1 de cada mês.
            </p>
            <div className="mt-5">
              <Button loading={generating} onClick={generateReport} size="sm">
                Gerar agora
              </Button>
            </div>
          </div>
        ) : (
          <div className="grid gap-6 lg:grid-cols-[200px_1fr]">

            {/* Sidebar — lista de meses */}
            <div className="flex flex-col gap-1">
              {reports.map((r) => (
                <button
                  key={r.id}
                  onClick={() => setSelected(r)}
                  className={[
                    "rounded-xl px-4 py-3 text-left text-sm transition-all",
                    selected?.id === r.id
                      ? "bg-[#0F172A] font-semibold text-white"
                      : "font-medium text-slate-600 hover:bg-[#DBEAFE]/50 hover:text-[#0F172A]",
                  ].join(" ")}
                >
                  {capitalize(monthLabel(r.month, r.year))}
                </button>
              ))}
            </div>

            {/* Detalhe do mês selecionado */}
            {selected && (
              <div className="space-y-4">

                {/* Economia principal */}
                <div className="rounded-2xl border border-[#DBEAFE] bg-white p-6 text-center shadow-sm">
                  <p className="text-xs font-bold uppercase tracking-widest text-slate-400">Economia estimada</p>
                  <p className="mt-1 text-4xl font-black text-[#22C55E]">
                    {formatBRL(selected.estimated_savings_cents)}
                  </p>
                  <p className="mt-1 text-xs text-slate-400">em relação ao preço mais caro disponível</p>
                </div>

                {/* Métricas */}
                <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                  {[
                    { label: "Cotações", value: selected.total_quotations },
                    { label: "Pedidos",  value: selected.total_orders },
                    { label: "Valor total", value: formatBRL(selected.total_value_cents) },
                    { label: "Dist./cotação", value: selected.avg_distributors_per_quotation.toFixed(1) },
                  ].map((m) => (
                    <div key={m.label} className="rounded-xl border border-[#DBEAFE] bg-white p-4 text-center">
                      <p className="text-xl font-black text-[#0F172A]">{m.value}</p>
                      <p className="mt-0.5 text-[11px] text-slate-400">{m.label}</p>
                    </div>
                  ))}
                </div>

                {/* Top distribuidoras */}
                {selected.top_distributors.length > 0 && (
                  <div className="rounded-2xl border border-[#DBEAFE] bg-white p-5 shadow-sm">
                    <h3 className="mb-3 text-sm font-bold text-[#0F172A]">Top distribuidoras</h3>
                    <div className="space-y-2">
                      {selected.top_distributors.map((d, i) => (
                        <div key={d.name} className="flex items-center gap-3">
                          <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[#F5F7FB] text-xs font-bold text-slate-500">
                            {i + 1}
                          </span>
                          <span className="flex-1 text-sm text-[#0F172A]">{d.name}</span>
                          <span className="text-sm font-semibold text-[#2563EB]">{formatBRL(d.value_cents)}</span>
                          <span className="text-xs text-slate-400">{d.order_count} pedido{d.order_count !== 1 ? "s" : ""}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Produtos mais cotados */}
                {selected.top_products.length > 0 && (
                  <div className="rounded-2xl border border-[#DBEAFE] bg-white p-5 shadow-sm">
                    <h3 className="mb-3 text-sm font-bold text-[#0F172A]">Produtos mais cotados</h3>
                    <div className="space-y-2">
                      {selected.top_products.map((p) => (
                        <div key={`${p.brand}|${p.product_name}`} className="flex items-center justify-between">
                          <div>
                            <p className="text-sm font-medium text-[#0F172A]">{p.product_name}</p>
                            <p className="text-xs text-slate-400">{p.brand}</p>
                          </div>
                          <span className="rounded-full bg-[#DBEAFE] px-2.5 py-0.5 text-xs font-bold text-[#2563EB]">
                            {p.quote_count}x
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* Gráfico de economia acumulada */}
        {reports.length > 1 && (
          <div className="mt-6 rounded-2xl border border-[#DBEAFE] bg-white p-5 shadow-sm">
            <h3 className="mb-4 text-sm font-bold text-[#0F172A]">Economia mensal (últimos meses)</h3>
            <SavingsChart reports={reports} />
          </div>
        )}

      </main>
    </div>
  );
}
