"use client";

import React, { useState, FormEvent } from "react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";

type Role = "client" | "distributor_admin";

const ESTABLISHMENT_TYPES = [
  { value: "bar",         label: "Bar" },
  { value: "restaurant",  label: "Restaurante" },
  { value: "adega",       label: "Adega" },
  { value: "hotel",       label: "Hotel" },
  { value: "nightclub",   label: "Casa Noturna" },
  { value: "supermarket", label: "Supermercado" },
  { value: "convenience", label: "Conveniência" },
  { value: "other",       label: "Outro" },
];

function formatCnpj(v: string) {
  const d = v.replace(/\D/g, "").slice(0, 14);
  return d
    .replace(/^(\d{2})(\d)/, "$1.$2")
    .replace(/^(\d{2})\.(\d{3})(\d)/, "$1.$2.$3")
    .replace(/\.(\d{3})(\d)/, ".$1/$2")
    .replace(/(\d{4})(\d)/, "$1-$2");
}

function formatWhatsapp(v: string) {
  const d = v.replace(/\D/g, "").slice(0, 11);
  return d
    .replace(/^(\d{2})(\d)/, "($1) $2")
    .replace(/(\d{5})(\d)/, "$1-$2");
}

export default function RegisterPage() {
  const router = useRouter();

  const [step, setStep] = useState<"role" | "form">("role");
  const [role, setRole] = useState<Role>("client");
  const [roleSelected, setRoleSelected] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const [responsibleName, setResponsibleName] = useState("");
  const [companyName, setCompanyName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [cnpj, setCnpj] = useState("");
  const [whatsapp, setWhatsapp] = useState("");
  const [establishmentType, setEstablishmentType] = useState("bar");
  const [city, setCity] = useState("");
  const [state, setState] = useState("");

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);

    const payload =
      role === "client"
        ? {
            role,
            email,
            password,
            responsible_name: responsibleName,
            company_name: companyName,
            cnpj: cnpj.replace(/\D/g, ""),
            whatsapp: whatsapp.replace(/\D/g, ""),
            establishment_type: establishmentType,
            delivery_city: city,
            delivery_state: state.toUpperCase().slice(0, 2),
          }
        : {
            role,
            email,
            password,
            responsible_name: responsibleName,
            company_name: companyName,
            cnpj: cnpj.replace(/\D/g, ""),
            whatsapp_commercial: whatsapp.replace(/\D/g, ""),
          };

    const res = await fetch("/api/auth/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    const data = await res.json();

    if (!res.ok) {
      setLoading(false);
      setError(data.error ?? "Erro ao criar conta. Tente novamente.");
      return;
    }

    const login = await signIn("credentials", {
      email,
      password,
      redirect: false,
    });

    if (login?.error) {
      setLoading(false);
      setError("Conta criada, mas não foi possível fazer login. Tente entrar manualmente.");
      return;
    }

    router.push(role === "client" ? "/cotacao" : "/painel");
  }

  if (step === "role") {
    const cards: Array<{
      value: Role;
      title: string;
      subtitle: string;
      benefits: string[];
      badge?: string;
      icon: React.ReactNode;
    }> = [
      {
        value: "client",
        title: "Sou comprador",
        subtitle: "Bar, restaurante, adega ou mercado",
        benefits: [
          "Cotar com várias distribuidoras de uma vez",
          "Ver ranking de preços automático",
          "Grátis para sempre",
        ],
        icon: (
          <svg viewBox="0 0 48 48" fill="none" className="h-12 w-12" aria-hidden>
            <rect x="6" y="18" width="36" height="24" rx="3" fill="#1E3A5F" stroke="#2563EB" strokeWidth="1.5"/>
            <path d="M6 22h36" stroke="#2563EB" strokeWidth="1.5"/>
            <rect x="14" y="28" width="8" height="14" rx="1.5" fill="#2563EB" opacity=".5"/>
            <rect x="26" y="32" width="10" height="10" rx="1.5" fill="#2563EB" opacity=".5"/>
            <path d="M16 18v-4a8 8 0 0 1 16 0v4" stroke="#2563EB" strokeWidth="1.5" strokeLinecap="round"/>
            <circle cx="20" cy="10" r="2" fill="#2563EB"/>
            <circle cx="28" cy="10" r="2" fill="#2563EB"/>
          </svg>
        ),
      },
      {
        value: "distributor_admin",
        title: "Sou distribuidora",
        subtitle: "Empresa que vende e distribui bebidas",
        benefits: [
          "Receba cotações de compradores da sua região",
          "Gerencie pedidos no painel",
          "14 dias grátis para testar",
        ],
        icon: (
          <svg viewBox="0 0 48 48" fill="none" className="h-12 w-12" aria-hidden>
            <rect x="2" y="20" width="28" height="18" rx="2" fill="#1E3A5F" stroke="#2563EB" strokeWidth="1.5"/>
            <path d="M30 26h8l6 8v4H30V26Z" fill="#1E3A5F" stroke="#2563EB" strokeWidth="1.5" strokeLinejoin="round"/>
            <circle cx="10" cy="40" r="4" fill="#0B1220" stroke="#2563EB" strokeWidth="1.5"/>
            <circle cx="10" cy="40" r="1.5" fill="#2563EB"/>
            <circle cx="38" cy="40" r="4" fill="#0B1220" stroke="#2563EB" strokeWidth="1.5"/>
            <circle cx="38" cy="40" r="1.5" fill="#2563EB"/>
            <path d="M8 28h14M8 32h10" stroke="#2563EB" strokeWidth="1.5" strokeLinecap="round" opacity=".5"/>
          </svg>
        ),
      },
    ];

    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-[#0B1220] px-4 py-12">

        {/* Logo */}
        <Link href="/" className="mb-10 inline-block">
          <span className="text-sm font-black uppercase tracking-[0.22em] text-white/90">
            HUBBY
          </span>
        </Link>

        {/* Título */}
        <h1 className="mb-2 text-center text-2xl font-semibold text-white">
          Como você vai usar a plataforma?
        </h1>
        <p className="mb-10 text-center text-sm text-white/40">
          Escolha um perfil para continuar
        </p>

        {/* Cards */}
        <div className="grid w-full max-w-2xl gap-4 sm:grid-cols-2">
          {cards.map((card) => {
            const selected = roleSelected && role === card.value;
            return (
              <button
                key={card.value}
                type="button"
                onClick={() => { setRole(card.value); setRoleSelected(true); }}
                className={[
                  "relative flex flex-col items-start rounded-3xl border p-6 text-left transition-all duration-150",
                  selected
                    ? "border-[#2563EB] bg-[#0F1E38] shadow-[0_0_0_1px_#2563EB]"
                    : "border-[#1E3A5F] bg-[#131F35] hover:border-[#2563EB]/60 hover:bg-[#0F1E38]",
                ].join(" ")}
              >
                {/* Badge */}
                {card.badge && (
                  <span className="absolute right-4 top-4 rounded-full bg-[#2563EB] px-2.5 py-0.5 text-[10px] font-black uppercase tracking-widest text-white">
                    {card.badge}
                  </span>
                )}

                {/* Ícone */}
                <div className="mb-5">{card.icon}</div>

                {/* Título */}
                <p className="text-lg font-semibold text-white">{card.title}</p>

                {/* Subtítulo */}
                <p className="mt-1 text-sm text-white/40">{card.subtitle}</p>

                {/* Benefícios */}
                <ul className="mt-5 space-y-2.5">
                  {card.benefits.map((b) => (
                    <li key={b} className="flex items-start gap-2.5 text-sm">
                      <svg viewBox="0 0 16 16" fill="none" className="mt-0.5 h-4 w-4 shrink-0" aria-hidden>
                        <circle cx="8" cy="8" r="8" fill="#16a34a" opacity=".2"/>
                        <path d="M4.5 8l2.5 2.5 4.5-5" stroke="#22c55e" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                      <span className="text-white/70">{b}</span>
                    </li>
                  ))}
                </ul>

                {/* Indicador de seleção */}
                {selected && (
                  <div className="absolute right-5 top-5 flex h-5 w-5 items-center justify-center rounded-full bg-[#2563EB]">
                    <svg viewBox="0 0 12 12" fill="none" className="h-3 w-3" aria-hidden>
                      <path d="M2 6l3 3 5-5" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                )}
              </button>
            );
          })}
        </div>

        {/* Botão continuar */}
        <div className="mt-8 w-full max-w-2xl">
          <button
            type="button"
            disabled={!roleSelected}
            onClick={() => setStep("form")}
            className={[
              "w-full rounded-2xl py-3.5 text-base font-semibold transition-all duration-150",
              roleSelected
                ? "bg-[#2563EB] text-white hover:bg-[#1D4ED8]"
                : "cursor-not-allowed bg-[#1E3A5F] text-white/30",
            ].join(" ")}
          >
            Continuar
          </button>
        </div>

        <p className="mt-6 text-center text-sm text-white/30">
          Já tem conta?{" "}
          <Link href="/auth/login" className="font-semibold text-[#2563EB] hover:underline">
            Entrar
          </Link>
        </p>

      </div>
    );
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-[#F5F7FB] px-4 py-12">
      <div className="w-full max-w-md">

        {/* Logo */}
        <div className="mb-8 text-center">
          <Link href="/" className="inline-block">
            <span className="text-sm font-bold uppercase tracking-[0.16em] text-[#0F172A]">
              HUBBY
            </span>
          </Link>
          <p className="mt-2 text-xs font-bold uppercase tracking-[0.14em] text-[#2563EB]">
            {role === "client" ? "Cadastro de comprador" : "Cadastro de distribuidora"}
          </p>
        </div>

        <div className="rounded-3xl border border-[#DBEAFE] bg-white p-8 shadow-sm">
          <button
            onClick={() => setStep("role")}
            className="mb-4 text-sm text-slate-500 hover:text-[#0F172A]"
          >
            ← Voltar
          </button>

          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <Input
              label="Nome do responsável"
              value={responsibleName}
              onChange={(e) => setResponsibleName(e.target.value)}
              placeholder="Seu nome completo"
              required
            />

            <Input
              label={role === "client" ? "Nome do estabelecimento" : "Razão Social"}
              value={companyName}
              onChange={(e) => setCompanyName(e.target.value)}
              required
            />

            <Input
              label="E-mail"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoComplete="email"
              required
            />

            <Input
              label="Senha"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              hint="Mínimo 8 caracteres, 1 maiúscula e 1 número (ex: Senha123)"
              autoComplete="new-password"
              required
            />

            <Input
              label="CNPJ"
              value={cnpj}
              onChange={(e) => setCnpj(formatCnpj(e.target.value))}
              placeholder="00.000.000/0000-00"
              required
            />

            <Input
              label={role === "client" ? "WhatsApp" : "WhatsApp comercial"}
              value={whatsapp}
              onChange={(e) => setWhatsapp(formatWhatsapp(e.target.value))}
              placeholder="(11) 99999-9999"
              required
            />

            {role === "client" && (
              <>
                <div className="flex flex-col gap-1">
                  <label className="text-sm font-medium text-[#0F172A]">
                    Tipo de estabelecimento
                  </label>
                  <select
                    value={establishmentType}
                    onChange={(e) => setEstablishmentType(e.target.value)}
                    className="w-full rounded-xl border border-[#DBEAFE] bg-white px-3 py-2.5 text-sm text-[#0F172A] outline-none transition-colors focus:border-[#2563EB] focus:ring-2 focus:ring-[#DBEAFE]"
                  >
                    {ESTABLISHMENT_TYPES.map((t) => (
                      <option key={t.value} value={t.value}>{t.label}</option>
                    ))}
                  </select>
                </div>

                <div className="flex gap-3">
                  <Input
                    label="Cidade de entrega"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="flex-1"
                    required
                  />
                  <Input
                    label="UF"
                    value={state}
                    onChange={(e) => setState(e.target.value.toUpperCase())}
                    maxLength={2}
                    className="w-20"
                    placeholder="SP"
                    required
                  />
                </div>
              </>
            )}

            {error && (
              <div className="rounded-xl bg-red-50 px-4 py-3 text-sm text-red-700">
                {error}
              </div>
            )}

            <Button type="submit" fullWidth loading={loading} size="lg">
              Criar conta
            </Button>
          </form>
        </div>

        <p className="mt-6 text-center text-sm text-slate-500">
          Já tem conta?{" "}
          <Link href="/auth/login" className="font-bold text-[#2563EB] hover:underline">
            Entrar
          </Link>
        </p>
      </div>
    </div>
  );
}
