"use client";

import { useState, useRef, FormEvent } from "react";
import { useRouter } from "next/navigation";
import { useSession } from "next-auth/react";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { Navbar } from "@/components/Navbar";
import { useApiToken, apiFetch } from "@/hooks/useApiToken";
import { ProductAutocomplete, formatPackaging } from "@/components/ui/ProductAutocomplete";
import type { ProductSearchResult } from "@/app/api/products/search/route";

type Category =
  | "beer" | "whisky" | "vodka" | "gin" | "rum" | "cachaca"
  | "wine" | "sparkling" | "energy" | "soft_drink" | "water" | "juice" | "other";

type QuotationItem = {
  id: string;
  product_name: string;
  brand: string;
  category: Category;
  packaging: string;
  quantity: number;
};

let idCounter = 1;
function newId() { return `item-${idCounter++}`; }

export default function CotacaoPage() {
  useSession({ required: true });
  const router = useRouter();
  const token = useApiToken();
  const quantityRef = useRef<HTMLInputElement>(null);

  const [items, setItems] = useState<QuotationItem[]>([]);

  const [searchValue, setSearchValue] = useState("");
  const [selectedProduct, setSelectedProduct] = useState<ProductSearchResult | null>(null);
  const [quantity, setQuantity] = useState(1);

  const [maxDays, setMaxDays] = useState<number | "">("");

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  function handleProductSelect(result: ProductSearchResult) {
    setSelectedProduct(result);
    setSearchValue("");
    setTimeout(() => quantityRef.current?.focus(), 0);
  }

  function clearSelection() {
    setSelectedProduct(null);
    setSearchValue("");
    setQuantity(1);
  }

  function addItem(e: FormEvent) {
    e.preventDefault();
    if (!selectedProduct) return;

    setItems((prev) => [
      ...prev,
      {
        id: newId(),
        product_name: selectedProduct.name,
        brand: selectedProduct.brand,
        category: selectedProduct.category as Category,
        packaging: formatPackaging(selectedProduct.packaging_type, selectedProduct.packaging_volume_ml),
        quantity,
      },
    ]);

    clearSelection();
  }

  function removeItem(id: string) {
    setItems((prev) => prev.filter((i) => i.id !== id));
  }

  function updateQuantity(id: string, qty: number) {
    if (qty < 1) return;
    setItems((prev) => prev.map((i) => (i.id === id ? { ...i, quantity: qty } : i)));
  }

  async function submitQuotation() {
    if (items.length === 0) {
      setError("Adicione ao menos um produto.");
      return;
    }

    setError("");
    if (!token) { setError("Sessão expirada. Faça login novamente."); return; }
    setLoading(true);

    const res = await apiFetch("/api/quotations", {
      method: "POST",
      token,
      body: JSON.stringify({
        items: items.map(({ product_name, brand, category, packaging, quantity }) => ({
          product_name, brand, category, packaging, quantity,
        })),
        max_delivery_days: maxDays !== "" ? Number(maxDays) : null,
      }),
    });

    const data = await res.json();
    setLoading(false);

    if (!res.ok) {
      setError(data.error ?? "Erro ao criar cotação.");
      return;
    }

    router.push(`/cotacao/${data.quotation.id}/ranking`);
  }

  const packagingLabel = selectedProduct
    ? formatPackaging(selectedProduct.packaging_type, selectedProduct.packaging_volume_ml)
    : null;

  return (
    <div className="flex min-h-screen flex-col bg-[#F5F7FB]">
      <Navbar />

      <main className="mx-auto w-full max-w-2xl flex-1 px-4 py-8">
        <h1 className="mb-1 text-2xl font-semibold text-[#0F172A]">
          Nova Cotação
        </h1>
        <p className="mb-6 text-sm text-slate-500">
          Busque e adicione os produtos que deseja cotar. Depois clique em{" "}
          <strong>Ver ranking de preços</strong>.
        </p>

        {/* Formulário de adição */}
        <div className="mb-6 rounded-3xl border border-[#DBEAFE] bg-white p-6 shadow-sm">
          <h2 className="mb-4 text-xs font-semibold uppercase tracking-[0.14em] text-slate-500">
            Adicionar produto
          </h2>

          <form onSubmit={addItem} className="flex flex-col gap-4">
            {/* Produto selecionado — chip */}
            {selectedProduct ? (
              <div className="flex items-center justify-between rounded-xl border border-[#DBEAFE] bg-[#EFF6FF] px-4 py-3">
                <div>
                  <p className="font-bold text-[#0F172A]">{selectedProduct.name}</p>
                  <p className="text-xs text-[#2563EB]">
                    {selectedProduct.brand} · {packagingLabel}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={clearSelection}
                  className="ml-4 text-slate-400 hover:text-[#2563EB]"
                  aria-label="Remover seleção"
                >
                  <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
            ) : (
              <ProductAutocomplete
                token={token}
                value={searchValue}
                onChange={setSearchValue}
                onSelect={handleProductSelect}
                onClear={() => setSearchValue("")}
              />
            )}

            {/* Quantidade — aparece só depois de selecionar */}
            {selectedProduct && (
              <div className="flex items-end gap-4">
                <div className="flex-1">
                  <Input
                    label="Quantidade"
                    type="number"
                    min={1}
                    value={quantity}
                    onChange={(e) => setQuantity(Math.max(1, Number(e.target.value)))}
                    required
                    ref={quantityRef}
                  />
                </div>
                <Button type="submit" variant="secondary" size="sm" className="mb-0.5">
                  + Adicionar
                </Button>
              </div>
            )}

            {!selectedProduct && (
              <p className="text-xs text-slate-400">
                Digite ao menos 2 letras para buscar produtos disponíveis.
              </p>
            )}
          </form>
        </div>

        {/* Lista de itens adicionados */}
        {items.length > 0 && (
          <div className="mb-6 rounded-3xl border border-[#DBEAFE] bg-white shadow-sm">
            <div className="flex items-center justify-between border-b border-[#DBEAFE] px-6 py-3">
              <h2 className="text-sm font-semibold text-[#0F172A]">Produtos da cotação</h2>
              <span className="text-xs text-slate-400">{items.length} produto(s)</span>
            </div>

            <ul className="divide-y divide-[#DBEAFE]">
              {items.map((item) => (
                <li key={item.id} className="flex items-center gap-3 px-6 py-4">
                  <div className="flex-1 min-w-0">
                    <p className="truncate text-sm font-medium text-[#0F172A]">{item.product_name}</p>
                    <p className="text-xs text-slate-400">{item.brand} · {item.packaging}</p>
                  </div>

                  {/* Stepper de quantidade */}
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => updateQuantity(item.id, item.quantity - 1)}
                      className="flex h-7 w-7 items-center justify-center rounded-full border border-[#DBEAFE] text-slate-500 hover:bg-[#F5F7FB]"
                    >−</button>
                    <span className="w-10 text-center text-sm font-medium text-[#0F172A]">{item.quantity}</span>
                    <button
                      type="button"
                      onClick={() => updateQuantity(item.id, item.quantity + 1)}
                      className="flex h-7 w-7 items-center justify-center rounded-full border border-[#DBEAFE] text-slate-500 hover:bg-[#F5F7FB]"
                    >+</button>
                  </div>

                  <button
                    type="button"
                    onClick={() => removeItem(item.id)}
                    className="ml-2 text-slate-300 hover:text-red-500"
                    aria-label="Remover"
                  >
                    <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Prazo máximo + ação */}
        <div className="rounded-3xl border border-[#DBEAFE] bg-white p-6 shadow-sm">
          <Input
            label="Prazo máximo de entrega (dias úteis)"
            type="number"
            min={1}
            max={90}
            value={maxDays}
            onChange={(e) => setMaxDays(e.target.value === "" ? "" : Number(e.target.value))}
            hint="Opcional — distribuidoras fora do prazo aparecem esmaecidas no ranking"
            placeholder="ex: 5"
          />

          {error && (
            <div className="mt-4 rounded-xl bg-red-50 px-4 py-3 text-sm text-red-700">
              {error}
            </div>
          )}

          <Button
            fullWidth
            size="lg"
            onClick={submitQuotation}
            loading={loading}
            disabled={items.length === 0}
            className="mt-4"
          >
            Ver ranking de preços{items.length > 0 ? ` — ${items.length} produto(s)` : ""}
          </Button>
        </div>
      </main>
    </div>
  );
}
