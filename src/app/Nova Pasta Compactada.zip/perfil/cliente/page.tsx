"use client";

import { useEffect, useState, FormEvent } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { Navbar } from "@/components/Navbar";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { useApiToken, apiFetch } from "@/hooks/useApiToken";

type ClientProfile = {
  id: string;
  company_name: string;
  cnpj: string;
  establishment_type: string;
  responsible_name: string;
  whatsapp: string;
  delivery_city: string;
  delivery_state: string;
  delivery_address_full: string;
  max_delivery_days_default: number | null;
};

const ESTABLISHMENT_TYPES = [
  { value: "bar",         label: "Bar" },
  { value: "restaurant",  label: "Restaurante" },
  { value: "adega",       label: "Adega" },
  { value: "hotel",       label: "Hotel" },
  { value: "nightclub",   label: "Casa Noturna" },
  { value: "supermarket", label: "Supermercado" },
  { value: "convenience", label: "Conveniência" },
  { value: "other",       label: "Outro" },
];

function formatCnpj(v: string): string {
  const d = v.replace(/\D/g, "").slice(0, 14);
  return d
    .replace(/^(\d{2})(\d)/, "$1.$2")
    .replace(/^(\d{2})\.(\d{3})(\d)/, "$1.$2.$3")
    .replace(/\.(\d{3})(\d)/, ".$1/$2")
    .replace(/(\d{4})(\d)/, "$1-$2");
}

function formatWhatsapp(v: string): string {
  const d = v.replace(/\D/g, "").slice(0, 11);
  return d
    .replace(/^(\d{2})(\d)/, "($1) $2")
    .replace(/(\d{5})(\d)/, "$1-$2");
}

export default function PerfilClientePage() {
  const { data: session, status, update: updateSession } = useSession({ required: true });
  const router = useRouter();
  const token = useApiToken();

  const role = (session?.user as { role?: string })?.role ?? "";

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [successMsg, setSuccessMsg] = useState("");
  const [errorMsg, setErrorMsg] = useState("");

  const [form, setForm] = useState({
    company_name: "",
    cnpj: "",
    establishment_type: "bar",
    responsible_name: "",
    whatsapp: "",
    delivery_city: "",
    delivery_state: "",
    delivery_address_full: "",
    max_delivery_days_default: "" as string | number,
    pref_email_monthly_report: true,
    pref_email_price_alerts:   true,
  });

  useEffect(() => {
    if (status === "authenticated" && role && role !== "client") {
      router.replace("/perfil");
    }
  }, [status, role, router]);

  useEffect(() => {
    if (!token) return;
    apiFetch("/api/profile", { method: "GET", token })
      .then(async (res) => {
        const data = await res.json();
        if (!res.ok || !data.profile) return;
        const p: ClientProfile = data.profile;
        setForm({
          company_name: p.company_name,
          cnpj: formatCnpj(p.cnpj),
          establishment_type: p.establishment_type,
          responsible_name: p.responsible_name,
          whatsapp: formatWhatsapp(p.whatsapp),
          delivery_city: p.delivery_city,
          delivery_state: p.delivery_state,
          delivery_address_full: p.delivery_address_full,
          max_delivery_days_default: p.max_delivery_days_default ?? "",
          pref_email_monthly_report: (p as { pref_email_monthly_report?: boolean }).pref_email_monthly_report ?? true,
          pref_email_price_alerts:   (p as { pref_email_price_alerts?: boolean }).pref_email_price_alerts   ?? true,
        });
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [token]);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (!token) return;
    setSaving(true);
    setSuccessMsg("");
    setErrorMsg("");

    const body: Record<string, unknown> = {
      // company_name e cnpj são somente leitura — não enviados
      establishment_type: form.establishment_type,
      responsible_name: form.responsible_name,
      whatsapp: form.whatsapp.replace(/\D/g, ""),
      delivery_city: form.delivery_city,
      delivery_state: form.delivery_state.toUpperCase().slice(0, 2),
      delivery_address_full: form.delivery_address_full,
      max_delivery_days_default: form.max_delivery_days_default === ""
        ? null
        : Number(form.max_delivery_days_default),
      pref_email_monthly_report: form.pref_email_monthly_report,
      pref_email_price_alerts:   form.pref_email_price_alerts,
    };

    try {
      const res = await apiFetch("/api/profile", { method: "PATCH", token, body: JSON.stringify(body) });
      const data = await res.json();
      if (res.ok) {
        // Atualiza a sessão NextAuth para refletir quaisquer mudanças
        await updateSession();
        setSuccessMsg("Dados atualizados com sucesso");
        setTimeout(() => setSuccessMsg(""), 4000);
      } else {
        setErrorMsg(data.error ?? "Erro ao salvar. Tente novamente.");
      }
    } catch {
      setErrorMsg("Erro de conexão. Tente novamente.");
    } finally {
      setSaving(false);
    }
  }

  if (loading || status === "loading") {
    return (
      <div className="flex min-h-screen flex-col bg-[#F5F7FB]">
        <Navbar />
        <div className="flex flex-1 items-center justify-center">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-[#22C55E] border-t-transparent" />
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen flex-col bg-[#F5F7FB]">
      <Navbar />

      <main className="mx-auto w-full max-w-xl px-4 py-10">
        <div className="mb-6">
          <h1 className="text-xl font-bold text-[#0F172A]">Meu Perfil</h1>
          <p className="mt-1 text-sm text-slate-500">Dados do seu estabelecimento</p>
        </div>

        <div className="rounded-2xl border border-[#DBEAFE] bg-white p-6 shadow-sm">
          <form onSubmit={handleSubmit} className="flex flex-col gap-4">

            {/* CNPJ — somente leitura */}
            <div className="flex flex-col gap-1">
              <label className="text-sm font-medium text-[#0F172A]">CNPJ</label>
              <div className="w-full rounded-xl border border-[#DBEAFE] bg-[#F5F7FB] px-3 py-2.5 text-sm text-slate-500">
                {form.cnpj}
              </div>
              <p className="text-xs text-slate-400">O CNPJ não pode ser alterado após o cadastro</p>
            </div>

            {/* Razão Social — somente leitura */}
            <div className="flex flex-col gap-1">
              <label className="text-sm font-medium text-[#0F172A]">Razão Social / Nome do estabelecimento</label>
              <div className="w-full rounded-xl border border-[#DBEAFE] bg-[#F5F7FB] px-3 py-2.5 text-sm text-slate-500">
                {form.company_name}
              </div>
              <p className="text-xs text-slate-400">A razão social não pode ser alterada após o cadastro</p>
            </div>

            <div className="flex flex-col gap-1">
              <label className="text-sm font-medium text-[#0F172A]">Tipo de estabelecimento</label>
              <select
                value={form.establishment_type}
                onChange={(e) => setForm((f) => ({ ...f, establishment_type: e.target.value }))}
                className="w-full rounded-xl border border-[#DBEAFE] bg-white px-3 py-2.5 text-sm text-[#0F172A] focus:border-[#2563EB] focus:outline-none focus:ring-2 focus:ring-[#DBEAFE]"
              >
                {ESTABLISHMENT_TYPES.map((t) => (
                  <option key={t.value} value={t.value}>{t.label}</option>
                ))}
              </select>
            </div>

            <Input
              label="Nome do responsável"
              value={form.responsible_name}
              onChange={(e) => setForm((f) => ({ ...f, responsible_name: e.target.value }))}
              required
            />

            <Input
              label="WhatsApp"
              value={form.whatsapp}
              onChange={(e) => setForm((f) => ({ ...f, whatsapp: formatWhatsapp(e.target.value) }))}
              placeholder="(11) 99999-9999"
              required
            />

            <hr className="border-[#DBEAFE]" />

            <div className="flex gap-3">
              <Input
                label="Cidade"
                value={form.delivery_city}
                onChange={(e) => setForm((f) => ({ ...f, delivery_city: e.target.value }))}
                className="flex-1"
                required
              />
              <Input
                label="UF"
                value={form.delivery_state}
                onChange={(e) => setForm((f) => ({ ...f, delivery_state: e.target.value.toUpperCase() }))}
                maxLength={2}
                className="w-20"
                placeholder="SP"
                required
              />
            </div>

            <Input
              label="Endereço completo"
              value={form.delivery_address_full}
              onChange={(e) => setForm((f) => ({ ...f, delivery_address_full: e.target.value }))}
              placeholder="Rua, número, bairro"
              required
            />

            <div className="flex flex-col gap-1">
              <label className="text-sm font-medium text-[#0F172A]">Prazo máximo preferido (dias)</label>
              <input
                type="number"
                min={1}
                max={90}
                value={form.max_delivery_days_default}
                onChange={(e) => setForm((f) => ({ ...f, max_delivery_days_default: e.target.value }))}
                placeholder="Ex: 3"
                className="w-full rounded-xl border border-[#DBEAFE] bg-white px-3 py-2.5 text-sm text-[#0F172A] placeholder:text-slate-400 focus:border-[#2563EB] focus:outline-none focus:ring-2 focus:ring-[#DBEAFE]"
              />
              <p className="text-xs text-slate-400">Deixe em branco para sem preferência</p>
            </div>

            <hr className="border-[#DBEAFE]" />

            {/* Preferências de notificação */}
            <div>
              <p className="mb-3 text-sm font-semibold text-[#0F172A]">Preferências de e-mail</p>
              <div className="space-y-3">
                {[
                  {
                    key: "pref_email_monthly_report" as const,
                    label: "Relatório mensal por e-mail",
                    desc: "Resumo de cotações e economia enviado no dia 1 de cada mês",
                  },
                  {
                    key: "pref_email_price_alerts" as const,
                    label: "Alertas de queda de preço",
                    desc: "Notificação quando um produto que você cotou fica mais barato",
                  },
                ].map(({ key, label, desc }) => (
                  <div key={key} className="flex items-start justify-between gap-4 rounded-xl border border-[#DBEAFE] bg-[#F5F7FB] px-4 py-3">
                    <div>
                      <p className="text-sm font-medium text-[#0F172A]">{label}</p>
                      <p className="text-xs text-slate-500">{desc}</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setForm((f) => ({ ...f, [key]: !f[key] }))}
                      className={`relative mt-0.5 h-6 w-11 shrink-0 rounded-full transition-colors ${form[key] ? "bg-[#22C55E]" : "bg-slate-300"}`}
                    >
                      <span className={`absolute top-0.5 left-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform ${form[key] ? "translate-x-5" : ""}`} />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {successMsg && (
              <div className="rounded-xl bg-green-50 px-4 py-3 text-sm font-medium text-green-700">
                ✓ {successMsg}
              </div>
            )}
            {errorMsg && (
              <div className="rounded-xl bg-red-50 px-4 py-3 text-sm text-red-700">
                {errorMsg}
              </div>
            )}

            <Button type="submit" fullWidth loading={saving} size="lg">
              Salvar alterações
            </Button>
          </form>
        </div>
      </main>
    </div>
  );
}
