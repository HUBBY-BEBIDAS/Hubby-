"use client";

import { useEffect, useState, useCallback, useRef } from "react";
import { useRouter } from "next/navigation";
import { useSession } from "next-auth/react";
import Link from "next/link";
import Image from "next/image";
import { Navbar } from "@/components/Navbar";
import { Button } from "@/components/ui/Button";
import { useApiToken, apiFetch } from "@/hooks/useApiToken";

// ─── Tipos ────────────────────────────────────────────────────────────────────

type DeliveryRegion = {
  id: string;
  city: string;
  state: string;
  delivery_days_business: number;
  route_days: string[];
  cutoff_time: string;
  minimum_order_cents: number;
};

type DistributorProfile = {
  id: string;
  company_name: string;
  cnpj: string;
  responsible_name: string;
  whatsapp_commercial: string;
  email_commercial: string;
  logo_key: string | null;
  payment_methods: string[];
  payment_terms_days: number[];
  credit_score_minimum: number;
  credit_accepts_restrictions: boolean;
  credit_min_cnpj_months: number;
  delivery_regions: DeliveryRegion[];
};

type ProductsSummary = {
  active: number;
  inactive: number;
  last_updated_at: string | null;
};

// ─── Constantes ───────────────────────────────────────────────────────────────

const PAYMENT_OPTIONS = [
  { value: "pix",           label: "Pix" },
  { value: "boleto",        label: "Boleto" },
  { value: "credit_card",   label: "Cartão de crédito" },
  { value: "bank_transfer", label: "Transferência bancária" },
  { value: "check",         label: "Cheque" },
] as const;

const WEEK_DAYS = [
  { value: "monday",    label: "Seg" },
  { value: "tuesday",   label: "Ter" },
  { value: "wednesday", label: "Qua" },
  { value: "thursday",  label: "Qui" },
  { value: "friday",    label: "Sex" },
  { value: "saturday",  label: "Sáb" },
] as const;

const CNPJ_MONTHS_OPTIONS = [
  { value: 0,   label: "Sem restrição" },
  { value: 6,   label: "6 meses" },
  { value: 12,  label: "1 ano" },
  { value: 24,  label: "2 anos" },
] as const;

// ─── Helpers ──────────────────────────────────────────────────────────────────

function formatCnpj(v: string) {
  return v.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, "$1.$2.$3/$4-$5");
}

function formatDate(iso: string | null) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit", year: "numeric" });
}

// ─── Componente de seção ──────────────────────────────────────────────────────

function Section({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle?: string;
  children: React.ReactNode;
}) {
  return (
    <section className="mb-6 overflow-hidden rounded-3xl border border-[#DBEAFE] bg-white shadow-sm">
      <div className="border-b border-[#DBEAFE] px-6 py-4">
        <h2 className="text-xs font-semibold uppercase tracking-[0.14em] text-slate-400">{title}</h2>
        {subtitle && <p className="mt-0.5 text-xs text-slate-400">{subtitle}</p>}
      </div>
      <div className="px-6 py-5">{children}</div>
    </section>
  );
}

function SaveMsg({ msg }: { msg: string }) {
  if (!msg) return null;
  const isErr = msg.startsWith("Erro");
  return (
    <p className={`mt-3 text-sm font-medium ${isErr ? "text-red-600" : "text-green-600"}`}>
      {isErr ? "✗ " : "✓ "}{msg}
    </p>
  );
}

// ─── Página principal ─────────────────────────────────────────────────────────

export default function PerfilPage() {
  const { data: session } = useSession({ required: true });
  const token = useApiToken();
  const router = useRouter();

  const role = (session?.user as { role?: string })?.role ?? "";

  // Clientes são redirecionados para a página de perfil do comprador
  useEffect(() => {
    if (role === "client") router.replace("/perfil/cliente");
  }, [role, router]);

  const [profile, setProfile] = useState<DistributorProfile | null>(null);
  const [summary, setSummary] = useState<ProductsSummary | null>(null);
  const [loading, setLoading] = useState(true);

  // ── Seção 1: Dados da empresa ──────────────────────────────────────────────
  const [companyForm, setCompanyForm] = useState({
    responsible_name: "",
    whatsapp_commercial: "",
    email_commercial: "",
  });
  const [companySaving, setCompanySaving] = useState(false);
  const [companyMsg, setCompanyMsg] = useState("");

  // Logo
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [logoUrl, setLogoUrl] = useState<string | null>(null);
  const [logoUploading, setLogoUploading] = useState(false);
  const [logoMsg, setLogoMsg] = useState("");

  // ── Seção 2: Regiões ───────────────────────────────────────────────────────
  const [regions, setRegions] = useState<DeliveryRegion[]>([]);
  const [newRegion, setNewRegion] = useState<Omit<DeliveryRegion, "id">>({
    city: "",
    state: "",
    delivery_days_business: 1,
    route_days: [],
    cutoff_time: "12:00",
    minimum_order_cents: 0,
  });
  const [addingRegion, setAddingRegion] = useState(false);
  const [regionMsg, setRegionMsg] = useState("");
  const [removingId, setRemovingId] = useState<string | null>(null);

  // Import de planilha
  type ImportRow = {
    city: string;
    state: string;
    route_days: string[];
    delivery_days_business: number;
    cutoff_time: string;
    minimum_order_cents: number;
  };
  const importFileRef = useRef<HTMLInputElement>(null);
  const [importRows, setImportRows] = useState<ImportRow[] | null>(null);
  const [importSummary, setImportSummary] = useState<{
    imported: number;
    ignored: number;
    total: number;
  } | null>(null);
  const [importLoading, setImportLoading] = useState(false);
  const [importConfirming, setImportConfirming] = useState(false);
  const [importMsg, setImportMsg] = useState("");
  const [batchDays, setBatchDays] = useState(1);
  const [batchCutoff, setBatchCutoff] = useState("12:00");
  const [batchMinOrder, setBatchMinOrder] = useState(0);

  // ── Seção 3: Pagamento ─────────────────────────────────────────────────────
  const [paymentForm, setPaymentForm] = useState({
    payment_methods: [] as string[],
    payment_terms_days: [] as number[],
  });
  const [paymentSaving, setPaymentSaving] = useState(false);
  const [paymentMsg, setPaymentMsg] = useState("");

  // ── Seção 4: Crédito ───────────────────────────────────────────────────────
  const [creditForm, setCreditForm] = useState({
    use_platform_default: true,
    credit_score_minimum: 500,
    credit_accepts_restrictions: false,
    credit_min_cnpj_months: 6,
  });
  const [creditSaving, setCreditSaving] = useState(false);
  const [creditMsg, setCreditMsg] = useState("");

  // ── Seção 5: ERP ───────────────────────────────────────────────────────────
  type ErpConfig = {
    is_enterprise: boolean;
    webhook_url: string | null;
    webhook_secret_hint: string | null;
    webhook_enabled: boolean;
    has_api_key: boolean;
  };
  type WebhookLogEntry = {
    id: string;
    event: string;
    status_code: number | null;
    success: boolean;
    error_message: string | null;
    created_at: string;
  };
  const [erpConfig, setErpConfig] = useState<ErpConfig | null>(null);
  const [erpForm, setErpForm] = useState({ webhook_url: "", webhook_secret: "", webhook_enabled: false });
  const [erpSaving, setErpSaving] = useState(false);
  const [erpMsg, setErpMsg] = useState("");
  const [erpTesting, setErpTesting] = useState(false);
  const [erpTestResult, setErpTestResult] = useState<{ ok: boolean; status_code?: number | null; error_message?: string | null } | null>(null);
  const [webhookLogs, setWebhookLogs] = useState<WebhookLogEntry[]>([]);
  const [generatingKey, setGeneratingKey] = useState(false);
  const [newApiKey, setNewApiKey] = useState<string | null>(null);

  // ── Fetch ──────────────────────────────────────────────────────────────────

  const fetchProfile = useCallback(async () => {
    if (!token) return;
    setLoading(true);
    try {
      const res = await apiFetch("/api/distributor/profile", { method: "GET", token });
      const data = await res.json();
      if (!res.ok || !data.profile) {
        setLoading(false);
        return;
      }
      const p: DistributorProfile = data.profile;
      setProfile(p);
      setSummary(data.products_summary ?? null);
      setRegions(p.delivery_regions ?? []);
      setCompanyForm({
        responsible_name: p.responsible_name ?? "",
        whatsapp_commercial: p.whatsapp_commercial ?? "",
        email_commercial: p.email_commercial ?? "",
      });

      // Busca URL assinada da logo se houver
      if (p.logo_key) {
        // Fallback dev: logo_key já é uma data URL — usa diretamente
        if (p.logo_key.startsWith("data:")) {
          setLogoUrl(p.logo_key);
        } else {
          apiFetch("/api/distributor/logo/signed", { method: "GET", token })
            .then((r) => r.json())
            .then((d: { url?: string }) => { if (d.url) setLogoUrl(d.url); })
            .catch(() => null);
        }
      }
      setPaymentForm({
        payment_methods: p.payment_methods ?? [],
        payment_terms_days: p.payment_terms_days ?? [],
      });
      const isDefault =
        p.credit_score_minimum === 500 &&
        !p.credit_accepts_restrictions &&
        p.credit_min_cnpj_months === 6;
      setCreditForm({
        use_platform_default: isDefault,
        credit_score_minimum: p.credit_score_minimum,
        credit_accepts_restrictions: p.credit_accepts_restrictions,
        credit_min_cnpj_months: p.credit_min_cnpj_months,
      });
      // Busca config ERP
      apiFetch("/api/distributor/erp/config", { method: "GET", token }).then(async (r) => {
        if (!r.ok) return;
        const d = await r.json() as ErpConfig;
        setErpConfig(d);
        setErpForm({ webhook_url: d.webhook_url ?? "", webhook_secret: "", webhook_enabled: d.webhook_enabled });
        apiFetch("/api/distributor/erp/logs", { method: "GET", token }).then(async (lr) => {
          if (lr.ok) { const ld = await lr.json(); setWebhookLogs(ld.logs ?? []); }
        }).catch(() => {});
      }).catch(() => {});
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => { fetchProfile(); }, [fetchProfile]);

  // Redireciona se não for distribuidora
  useEffect(() => {
    if (role && role !== "distributor_admin" && role !== "distributor_collaborator") {
      router.replace("/");
    }
  }, [role, router]);

  // ── Salvar dados da empresa ────────────────────────────────────────────────

  async function saveCompany() {
    if (!token) return;
    setCompanySaving(true);
    setCompanyMsg("");
    const res = await apiFetch("/api/distributor/profile", {
      method: "PATCH",
      token,
      body: JSON.stringify(companyForm),
    });
    setCompanySaving(false);
    if (res.ok) {
      setCompanyMsg("Dados da empresa salvos com sucesso.");
    } else {
      const d = await res.json();
      setCompanyMsg(`Erro: ${d.error ?? "Falha ao salvar."}`);
    }
  }

  // ── Upload de logo ─────────────────────────────────────────────────────────

  function readFileAsDataUrl(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (ev) => resolve(ev.target?.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  async function handleLogoChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file || !token) return;

    const allowed = ["image/png", "image/jpeg", "image/webp", "image/svg+xml"];
    if (!allowed.includes(file.type)) {
      setLogoMsg("Erro: Formato não suportado. Use PNG, JPG, WebP ou SVG.");
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      setLogoMsg("Erro: Arquivo muito grande. Máximo 2 MB.");
      return;
    }

    setLogoUploading(true);
    setLogoMsg("");

    try {
      // 1. Consulta o servidor sobre o modo de upload disponível
      const presignRes = await apiFetch("/api/distributor/logo/presigned", {
        method: "POST",
        token,
        body: JSON.stringify({ mime_type: file.type }),
      });
      if (!presignRes.ok) {
        const d = await presignRes.json();
        setLogoMsg(`Erro: ${d.error ?? "Falha ao iniciar upload."}`);
        return;
      }

      const presignData = await presignRes.json() as {
        mode?: string;
        uploadUrl?: string;
        key?: string;
      };

      // ── Modo base64 (fallback dev — S3/R2 não configurado) ─────────────────
      if (presignData.mode === "base64") {
        const dataUrl = await readFileAsDataUrl(file);
        const patchRes = await apiFetch("/api/distributor/profile", {
          method: "PATCH",
          token,
          body: JSON.stringify({ logo_base64: dataUrl }),
        });
        if (!patchRes.ok) {
          const d = await patchRes.json();
          setLogoMsg(`Erro: ${d.error ?? "Falha ao salvar logo."}`);
          return;
        }
        setLogoUrl(dataUrl);
        setLogoMsg("Logo atualizada com sucesso.");
        return;
      }

      // ── Modo S3/R2 (produção) ───────────────────────────────────────────────
      const { uploadUrl, key } = presignData;
      if (!uploadUrl || !key) {
        setLogoMsg("Erro: Resposta inválida do servidor.");
        return;
      }

      // 2. PUT direto no storage
      const uploadRes = await fetch(uploadUrl, {
        method: "PUT",
        headers: { "Content-Type": file.type },
        body: file,
      });
      if (!uploadRes.ok) {
        setLogoMsg("Erro: Falha ao enviar o arquivo para o storage.");
        return;
      }

      // 3. Salva a key no perfil
      const patchRes = await apiFetch("/api/distributor/profile", {
        method: "PATCH",
        token,
        body: JSON.stringify({ logo_key: key }),
      });
      if (!patchRes.ok) {
        setLogoMsg("Erro: Logo enviada mas falhou ao salvar no perfil.");
        return;
      }

      // 4. Exibe preview local
      setLogoUrl(URL.createObjectURL(file));
      setLogoMsg("Logo atualizada com sucesso.");
    } catch {
      setLogoMsg("Erro: Falha inesperada no upload.");
    } finally {
      setLogoUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  }

  // ── Salvar pagamento ───────────────────────────────────────────────────────

  async function savePayment() {
    if (!token) return;
    setPaymentSaving(true);
    setPaymentMsg("");
    const res = await apiFetch("/api/distributor/profile", {
      method: "PATCH",
      token,
      body: JSON.stringify(paymentForm),
    });
    setPaymentSaving(false);
    if (res.ok) {
      setPaymentMsg("Formas de pagamento salvas com sucesso.");
    } else {
      const d = await res.json();
      setPaymentMsg(`Erro: ${d.error ?? "Falha ao salvar."}`);
    }
  }

  // ── Salvar crédito ─────────────────────────────────────────────────────────

  async function saveCredit() {
    if (!token) return;
    setCreditSaving(true);
    setCreditMsg("");
    const body = creditForm.use_platform_default
      ? { use_platform_credit_default: true }
      : {
          use_platform_credit_default: false,
          credit_score_minimum: creditForm.credit_score_minimum,
          credit_accepts_restrictions: creditForm.credit_accepts_restrictions,
          credit_min_cnpj_months: creditForm.credit_min_cnpj_months,
        };
    const res = await apiFetch("/api/distributor/profile", {
      method: "PATCH",
      token,
      body: JSON.stringify(body),
    });
    setCreditSaving(false);
    if (res.ok) {
      setCreditMsg("Critério de crédito salvo com sucesso.");
    } else {
      const d = await res.json();
      setCreditMsg(`Erro: ${d.error ?? "Falha ao salvar."}`);
    }
  }

  // ── Adicionar região ───────────────────────────────────────────────────────

  async function addRegion() {
    if (!token) return;
    if (!newRegion.city || !newRegion.state || newRegion.route_days.length === 0) {
      setRegionMsg("Erro: Preencha cidade, estado e ao menos um dia de rota.");
      return;
    }
    setAddingRegion(true);
    setRegionMsg("");
    const res = await apiFetch("/api/distributor/delivery-regions", {
      method: "POST",
      token,
      body: JSON.stringify({
        ...newRegion,
        state: newRegion.state.toUpperCase(),
        minimum_order_cents: Math.round((newRegion.minimum_order_cents ?? 0)),
      }),
    });
    setAddingRegion(false);
    const d = await res.json();
    if (res.ok) {
      const created: DeliveryRegion = d.region;
      // Upsert local: substitui se já existia cidade+estado
      setRegions((prev) => {
        const idx = prev.findIndex(
          (r) => r.city === created.city && r.state === created.state
        );
        return idx >= 0
          ? prev.map((r, i) => (i === idx ? created : r))
          : [...prev, created];
      });
      setNewRegion({
        city: "", state: "", delivery_days_business: 1,
        route_days: [], cutoff_time: "12:00", minimum_order_cents: 0,
      });
      setRegionMsg("Região adicionada com sucesso.");
    } else {
      setRegionMsg(`Erro: ${d.error ?? "Falha ao salvar."}`);
    }
  }

  // ── Remover região ─────────────────────────────────────────────────────────

  async function removeRegion(id: string) {
    if (!token) return;
    setRemovingId(id);
    const res = await apiFetch(`/api/distributor/delivery-regions/${id}`, {
      method: "DELETE",
      token,
    });
    setRemovingId(null);
    if (res.ok) {
      setRegions((prev) => prev.filter((r) => r.id !== id));
    } else {
      const d = await res.json();
      setRegionMsg(`Erro: ${d.error ?? "Falha ao remover."}`);
    }
  }

  // ── Download autenticado de templates ────────────────────────────────────

  async function downloadTemplate(url: string, filename: string) {
    if (!token) return;
    const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
    if (!res.ok) return;
    const blob = await res.blob();
    const href = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = href;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(href);
  }

  // ── Import de planilha de regiões ─────────────────────────────────────────

  async function handleRegionImport(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file || !token) return;

    if (!file.name.toLowerCase().endsWith(".xlsx")) {
      setImportMsg("Erro: Envie um arquivo .xlsx");
      return;
    }

    setImportLoading(true);
    setImportMsg("");
    setImportRows(null);
    setImportSummary(null);

    try {
      const formData = new FormData();
      formData.append("file", file);

      // Usa fetch direto (sem apiFetch) para não sobrescrever o Content-Type do multipart
      const res = await fetch("/api/distributor/delivery-regions/import", {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
        body: formData,
      });

      const data = await res.json() as {
        regions?: Array<{ city: string; state: string; route_days: string[] }>;
        summary?: { imported: number; ignored: number; total: number };
        error?: string;
      };

      if (!res.ok) {
        setImportMsg(`Erro: ${data.error ?? "Falha ao processar a planilha."}`);
        return;
      }

      const rows: ImportRow[] = (data.regions ?? []).map((r) => ({
        ...r,
        delivery_days_business: batchDays,
        cutoff_time: batchCutoff,
        minimum_order_cents: Math.round(batchMinOrder * 100),
      }));

      setImportRows(rows);
      setImportSummary(data.summary ?? null);
    } catch {
      setImportMsg("Erro: Falha inesperada ao processar a planilha.");
    } finally {
      setImportLoading(false);
      if (importFileRef.current) importFileRef.current.value = "";
    }
  }

  function applyBatchToAll() {
    setImportRows((prev) =>
      prev?.map((r) => ({
        ...r,
        delivery_days_business: batchDays,
        cutoff_time: batchCutoff,
        minimum_order_cents: Math.round(batchMinOrder * 100),
      })) ?? null
    );
  }

  function updateImportRow(index: number, patch: Partial<ImportRow>) {
    setImportRows((prev) =>
      prev?.map((r, i) => (i === index ? { ...r, ...patch } : r)) ?? null
    );
  }

  async function confirmRegionImport() {
    if (!token || !importRows || importRows.length === 0) return;
    setImportConfirming(true);
    setImportMsg("");

    const res = await apiFetch("/api/distributor/delivery-regions", {
      method: "POST",
      token,
      body: JSON.stringify({ regions: importRows }),
    });

    setImportConfirming(false);
    const data = await res.json() as {
      regions?: DeliveryRegion[];
      message?: string;
      error?: string;
    };

    if (res.ok && data.regions) {
      setRegions((prev) => {
        const map = new Map(prev.map((r) => [`${r.city}|${r.state}`, r]));
        for (const r of data.regions!) map.set(`${r.city}|${r.state}`, r);
        return Array.from(map.values()).sort((a, b) => a.city.localeCompare(b.city, "pt-BR"));
      });
      setImportRows(null);
      setImportSummary(null);
      setImportMsg(`${data.regions.length} regiões importadas com sucesso.`);
    } else {
      setImportMsg(`Erro: ${data.error ?? "Falha ao confirmar importação."}`);
    }
  }

  // ── Handlers ERP ──────────────────────────────────────────────────────────

  async function saveErpConfig() {
    if (!token) return;
    setErpSaving(true);
    setErpMsg("");
    try {
      const body: Record<string, unknown> = { webhook_enabled: erpForm.webhook_enabled };
      if (erpForm.webhook_url) body.webhook_url = erpForm.webhook_url;
      if (erpForm.webhook_secret) body.webhook_secret = erpForm.webhook_secret;
      const res = await apiFetch("/api/distributor/erp/config", { method: "PATCH", token, body: JSON.stringify(body) });
      const data = await res.json();
      if (res.ok) {
        setErpMsg("Configuração salva com sucesso");
        setErpConfig((prev) => prev ? { ...prev, webhook_url: erpForm.webhook_url || prev.webhook_url, webhook_enabled: erpForm.webhook_enabled } : prev);
        setTimeout(() => setErpMsg(""), 4000);
      } else {
        setErpMsg(data.error ?? "Erro ao salvar");
      }
    } finally {
      setErpSaving(false);
    }
  }

  async function testWebhook() {
    if (!token) return;
    setErpTesting(true);
    setErpTestResult(null);
    try {
      const res = await apiFetch("/api/distributor/erp/webhook/test", { method: "POST", token });
      const data = await res.json();
      setErpTestResult({ ok: data.ok, status_code: data.status_code, error_message: data.error_message });
    } finally {
      setErpTesting(false);
    }
  }

  async function generateApiKey() {
    if (!token || !confirm("Gerar uma nova chave invalidará a anterior. Continuar?")) return;
    setGeneratingKey(true);
    setNewApiKey(null);
    try {
      const res = await apiFetch("/api/distributor/erp/config", { method: "POST", token });
      const data = await res.json();
      if (res.ok) {
        setNewApiKey(data.erp_api_key);
        setErpConfig((prev) => prev ? { ...prev, has_api_key: true } : prev);
      }
    } finally {
      setGeneratingKey(false);
    }
  }

  // ── Skeleton ───────────────────────────────────────────────────────────────

  if (loading) {
    return (
      <div className="flex min-h-screen flex-col bg-[#F5F7FB]">
        <Navbar />
        <main className="mx-auto w-full max-w-2xl flex-1 px-4 py-8">
          {[1, 2, 3, 4, 5].map((n) => (
            <div key={n} className="mb-6 h-40 animate-pulse rounded-3xl bg-[#DBEAFE]/50" />
          ))}
        </main>
      </div>
    );
  }

  const isAdmin = role === "distributor_admin";

  return (
    <div className="flex min-h-screen flex-col bg-[#F5F7FB]">
      <Navbar />

      <main className="mx-auto w-full max-w-2xl flex-1 px-4 pb-12 pt-8">

        <div className="mb-6">
          <h1 className="text-2xl font-semibold text-[#0F172A]">
            Perfil da distribuidora
          </h1>
          {!isAdmin && (
            <p className="mt-1 text-sm text-slate-500">
              Somente administradores podem editar o perfil.
            </p>
          )}
        </div>

        {/* ── 1. Dados da empresa ─────────────────────────────────────────── */}
        <Section title="Dados da empresa">
          <div className="mb-4 grid grid-cols-2 gap-4 rounded-2xl bg-[#F5F7FB] px-4 py-3 text-sm">
            <div>
              <p className="text-xs font-bold uppercase tracking-wide text-slate-400">Razão social</p>
              <p className="mt-0.5 font-medium text-[#0F172A]">{profile?.company_name ?? "—"}</p>
            </div>
            <div>
              <p className="text-xs font-bold uppercase tracking-wide text-slate-400">CNPJ</p>
              <p className="mt-0.5 font-mono font-medium text-[#0F172A]">
                {profile?.cnpj ? formatCnpj(profile.cnpj) : "—"}
              </p>
            </div>
          </div>

          <p className="mb-4 text-xs text-slate-400">
            Razão social e CNPJ são definidos no cadastro e validados na Receita Federal. Para alterá-los,{" "}
            <a href="mailto:contato@sic.com.br" className="text-[#2563EB] underline">
              entre em contato com o suporte
            </a>.
          </p>

          {/* Logo */}
          <div className="mb-5">
            <p className="mb-2 text-sm font-medium text-[#0F172A]">Logo da empresa</p>
            <div className="flex items-center gap-4">
              <div className="flex h-20 w-20 shrink-0 items-center justify-center overflow-hidden rounded-2xl border border-[#DBEAFE] bg-[#F5F7FB]">
                {logoUrl ? (
                  <Image
                    src={logoUrl}
                    alt="Logo"
                    width={80}
                    height={80}
                    className="h-full w-full object-contain"
                    unoptimized
                  />
                ) : (
                  <svg className="h-8 w-8 text-slate-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
                      d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                )}
              </div>
              <div>
                {isAdmin && (
                  <>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/png,image/jpeg,image/webp,image/svg+xml"
                      className="hidden"
                      onChange={handleLogoChange}
                    />
                    <Button
                      size="sm"
                      variant="secondary"
                      loading={logoUploading}
                      onClick={() => fileInputRef.current?.click()}
                    >
                      {logoUploading ? "Enviando…" : "Trocar logo"}
                    </Button>
                    <p className="mt-1 text-xs text-slate-400">PNG, JPG, WebP ou SVG · máx. 2 MB</p>
                  </>
                )}
                {logoMsg && (
                  <p className={`mt-1 text-xs font-medium ${logoMsg.startsWith("Erro") ? "text-red-600" : "text-green-600"}`}>
                    {logoMsg.startsWith("Erro") ? "✗ " : "✓ "}{logoMsg}
                  </p>
                )}
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="mb-1 block text-sm font-medium text-[#0F172A]">
                Nome do responsável
              </label>
              <input
                type="text"
                value={companyForm.responsible_name}
                onChange={(e) => setCompanyForm((p) => ({ ...p, responsible_name: e.target.value }))}
                disabled={!isAdmin}
                className="w-full rounded-xl border border-[#DBEAFE] bg-white px-4 py-2.5 text-sm text-[#0F172A] focus:border-[#2563EB] focus:outline-none disabled:opacity-50"
                placeholder="João Silva"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="mb-1 block text-sm font-medium text-[#0F172A]">
                  WhatsApp comercial
                </label>
                <input
                  type="tel"
                  value={companyForm.whatsapp_commercial}
                  onChange={(e) => setCompanyForm((p) => ({ ...p, whatsapp_commercial: e.target.value }))}
                  disabled={!isAdmin}
                  className="w-full rounded-xl border border-[#DBEAFE] bg-white px-4 py-2.5 text-sm text-[#0F172A] focus:border-[#2563EB] focus:outline-none disabled:opacity-50"
                  placeholder="11999998888"
                />
              </div>
              <div>
                <label className="mb-1 block text-sm font-medium text-[#0F172A]">
                  Email comercial
                </label>
                <input
                  type="email"
                  value={companyForm.email_commercial}
                  onChange={(e) => setCompanyForm((p) => ({ ...p, email_commercial: e.target.value }))}
                  disabled={!isAdmin}
                  className="w-full rounded-xl border border-[#DBEAFE] bg-white px-4 py-2.5 text-sm text-[#0F172A] focus:border-[#2563EB] focus:outline-none disabled:opacity-50"
                  placeholder="vendas@empresa.com.br"
                />
              </div>
            </div>
          </div>

          {isAdmin && (
            <div className="mt-4 flex items-center justify-between">
              <Button size="sm" loading={companySaving} onClick={saveCompany}>
                Salvar dados da empresa
              </Button>
              <SaveMsg msg={companyMsg} />
            </div>
          )}
        </Section>

        {/* ── 2. Regiões e rotas ───────────────────────────────────────────── */}
        <Section title="Regiões e rotas de entrega">

          {/* Lista existente */}
          {regions.length === 0 ? (
            <p className="mb-4 text-sm text-slate-400">
              Nenhuma região cadastrada ainda.
            </p>
          ) : (
            <ul className="mb-5 space-y-3">
              {regions.map((r) => (
                <li
                  key={r.id}
                  className="rounded-2xl border border-[#DBEAFE] bg-[#F5F7FB] px-4 py-3"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-[#0F172A]">
                        {r.city} — {r.state}
                      </p>
                      <div className="mt-1 flex flex-wrap gap-3 text-xs text-slate-500">
                        <span>⏱ {r.delivery_days_business} dia(s) útil(eis)</span>
                        <span>
                          🗓{" "}
                          {r.route_days
                            .map((d) => WEEK_DAYS.find((w) => w.value === d)?.label ?? d)
                            .join(", ")}
                        </span>
                        <span>⏰ corte {r.cutoff_time}</span>
                        {r.minimum_order_cents > 0 && (
                          <span>
                            💰 mínimo{" "}
                            {new Intl.NumberFormat("pt-BR", {
                              style: "currency",
                              currency: "BRL",
                            }).format(r.minimum_order_cents / 100)}
                          </span>
                        )}
                      </div>
                    </div>
                    {isAdmin && (
                      <button
                        onClick={() => removeRegion(r.id)}
                        disabled={removingId === r.id}
                        className="shrink-0 rounded-lg px-3 py-1 text-xs font-medium text-red-500 hover:bg-red-50 disabled:opacity-40"
                      >
                        {removingId === r.id ? "Removendo…" : "Remover"}
                      </button>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          )}

          {/* Formulário de nova região */}
          {isAdmin && (
            <div className="rounded-2xl border border-[#DBEAFE] bg-white p-4">
              <p className="mb-3 text-sm font-bold text-[#0F172A]">Adicionar região</p>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                <div className="col-span-2 sm:col-span-1">
                  <label className="mb-1 block text-xs font-medium text-slate-500">Cidade</label>
                  <input
                    type="text"
                    value={newRegion.city}
                    onChange={(e) => setNewRegion((p) => ({ ...p, city: e.target.value }))}
                    className="w-full rounded-xl border border-[#DBEAFE] bg-[#F5F7FB] px-3 py-2 text-sm text-[#0F172A] focus:border-[#2563EB] focus:outline-none"
                    placeholder="São Paulo"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-medium text-slate-500">Estado (UF)</label>
                  <input
                    type="text"
                    maxLength={2}
                    value={newRegion.state}
                    onChange={(e) => setNewRegion((p) => ({ ...p, state: e.target.value.toUpperCase() }))}
                    className="w-full rounded-xl border border-[#DBEAFE] bg-[#F5F7FB] px-3 py-2 text-sm text-[#0F172A] focus:border-[#2563EB] focus:outline-none"
                    placeholder="SP"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-medium text-slate-500">Prazo (dias úteis)</label>
                  <input
                    type="number"
                    min={1}
                    max={30}
                    value={newRegion.delivery_days_business}
                    onChange={(e) => setNewRegion((p) => ({ ...p, delivery_days_business: Number(e.target.value) }))}
                    className="w-full rounded-xl border border-[#DBEAFE] bg-[#F5F7FB] px-3 py-2 text-sm text-[#0F172A] focus:border-[#2563EB] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-medium text-slate-500">Horário de corte</label>
                  <input
                    type="time"
                    value={newRegion.cutoff_time}
                    onChange={(e) => setNewRegion((p) => ({ ...p, cutoff_time: e.target.value }))}
                    className="w-full rounded-xl border border-[#DBEAFE] bg-[#F5F7FB] px-3 py-2 text-sm text-[#0F172A] focus:border-[#2563EB] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-medium text-slate-500">Pedido mínimo (R$)</label>
                  <input
                    type="number"
                    min={0}
                    step={0.01}
                    value={newRegion.minimum_order_cents / 100}
                    onChange={(e) => setNewRegion((p) => ({ ...p, minimum_order_cents: Math.round(Number(e.target.value) * 100) }))}
                    className="w-full rounded-xl border border-[#DBEAFE] bg-[#F5F7FB] px-3 py-2 text-sm text-[#0F172A] focus:border-[#2563EB] focus:outline-none"
                    placeholder="0,00"
                  />
                </div>
              </div>

              {/* Dias de rota */}
              <div className="mt-3">
                <label className="mb-2 block text-xs font-medium text-slate-500">
                  Dias de rota (dias em que a distribuidora faz entregas)
                </label>
                <div className="flex flex-wrap gap-2">
                  {WEEK_DAYS.map(({ value, label }) => {
                    const checked = newRegion.route_days.includes(value);
                    return (
                      <button
                        key={value}
                        type="button"
                        onClick={() =>
                          setNewRegion((p) => ({
                            ...p,
                            route_days: checked
                              ? p.route_days.filter((d) => d !== value)
                              : [...p.route_days, value],
                          }))
                        }
                        className={[
                          "rounded-lg px-3 py-1.5 text-xs font-bold transition-colors",
                          checked
                            ? "bg-[#2563EB] text-white"
                            : "border border-[#DBEAFE] bg-[#F5F7FB] text-slate-600 hover:bg-[#EFF6FF]",
                        ].join(" ")}
                      >
                        {label}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="mt-4 flex items-center justify-between">
                <Button size="sm" loading={addingRegion} onClick={addRegion}>
                  Adicionar região
                </Button>
                <SaveMsg msg={regionMsg} />
              </div>
            </div>
          )}

          {/* ── Import via planilha ──────────────────────────────────────── */}
          {isAdmin && (
            <div className="mt-4 rounded-2xl border border-[#DBEAFE] bg-white p-4">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <p className="text-sm font-semibold text-[#0F172A]">
                    Importar planilha de municípios
                  </p>
                  <p className="mt-0.5 text-xs text-slate-400">
                    Aceita formato semanal (SEGUNDA-FEIRA, TERÇA-FEIRA…) ou formato padrão com colunas prazo_dias_uteis e horario_corte.
                  </p>
                  <button
                    type="button"
                    onClick={() => downloadTemplate("/api/distributor/delivery-regions/template", "modelo-roteiros-hubby.xlsx")}
                    className="mt-1 inline-flex items-center gap-1 text-xs text-violet-600 hover:underline"
                  >
                    ⬇ Baixar planilha modelo
                  </button>
                </div>
                <div>
                  <input
                    ref={importFileRef}
                    type="file"
                    accept=".xlsx"
                    className="hidden"
                    onChange={handleRegionImport}
                  />
                  <Button
                    size="sm"
                    loading={importLoading}
                    onClick={() => importFileRef.current?.click()}
                  >
                    {importLoading ? "Processando…" : "Selecionar .xlsx"}
                  </Button>
                </div>
              </div>

              {/* Mensagem de erro/sucesso do import */}
              {importMsg && !importRows && <SaveMsg msg={importMsg} />}

              {/* Preview ──────────────────────────────────────────────────── */}
              {importSummary && importRows && (
                <div className="mt-4">
                  {/* Resumo */}
                  <div className="mb-4 flex flex-wrap gap-3">
                    <span className="rounded-xl bg-green-50 px-3 py-1.5 text-xs font-semibold text-green-700">
                      {importSummary.imported} município(s) com entrega
                    </span>
                    <span className="rounded-xl bg-slate-100 px-3 py-1.5 text-xs font-semibold text-slate-500">
                      {importSummary.ignored} ignorado(s) — fora de rota ou sem SIM
                    </span>
                    <span className="rounded-xl bg-[#EFF6FF] px-3 py-1.5 text-xs font-semibold text-[#2563EB]">
                      {importSummary.total} linhas no total
                    </span>
                  </div>

                  {/* Configurações em lote */}
                  <div className="mb-3 rounded-2xl border border-[#DBEAFE] bg-[#F5F7FB] p-3">
                    <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">
                      Aplicar a todos
                    </p>
                    <div className="flex flex-wrap items-end gap-3">
                      <div>
                        <label className="mb-1 block text-xs text-slate-500">Prazo (dias úteis)</label>
                        <input
                          type="number"
                          min={1}
                          max={30}
                          value={batchDays}
                          onChange={(e) => setBatchDays(Number(e.target.value))}
                          className="w-20 rounded-xl border border-[#DBEAFE] bg-white px-2 py-1.5 text-sm text-[#0F172A] focus:border-[#2563EB] focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="mb-1 block text-xs text-slate-500">Horário de corte</label>
                        <input
                          type="time"
                          value={batchCutoff}
                          onChange={(e) => setBatchCutoff(e.target.value)}
                          className="rounded-xl border border-[#DBEAFE] bg-white px-2 py-1.5 text-sm text-[#0F172A] focus:border-[#2563EB] focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="mb-1 block text-xs text-slate-500">Pedido mínimo (R$)</label>
                        <input
                          type="number"
                          min={0}
                          step={0.01}
                          value={batchMinOrder}
                          onChange={(e) => setBatchMinOrder(Number(e.target.value))}
                          className="w-28 rounded-xl border border-[#DBEAFE] bg-white px-2 py-1.5 text-sm text-[#0F172A] focus:border-[#2563EB] focus:outline-none"
                          placeholder="0,00"
                        />
                      </div>
                      <Button size="sm" onClick={applyBatchToAll}>
                        Aplicar a todos
                      </Button>
                    </div>
                  </div>

                  {/* Tabela de preview */}
                  <div className="max-h-80 overflow-y-auto rounded-2xl border border-[#DBEAFE]">
                    <table className="w-full text-xs">
                      <thead className="sticky top-0 bg-[#F5F7FB]">
                        <tr className="border-b border-[#DBEAFE]">
                          <th className="px-3 py-2 text-left font-semibold text-slate-500">Município</th>
                          <th className="px-3 py-2 text-left font-semibold text-slate-500">Dias de rota</th>
                          <th className="px-3 py-2 text-left font-semibold text-slate-500">Prazo</th>
                          <th className="px-3 py-2 text-left font-semibold text-slate-500">Corte</th>
                          <th className="px-3 py-2 text-left font-semibold text-slate-500">Mín. (R$)</th>
                        </tr>
                      </thead>
                      <tbody>
                        {importRows.map((row, i) => (
                          <tr
                            key={`${row.city}-${i}`}
                            className="border-b border-[#DBEAFE]/50 last:border-0 hover:bg-[#F5F7FB]/50"
                          >
                            <td className="px-3 py-2 font-medium text-[#0F172A]">
                              {row.city} — {row.state}
                            </td>
                            <td className="px-3 py-2">
                              <div className="flex flex-wrap gap-1">
                                {row.route_days.map((d) => (
                                  <span
                                    key={d}
                                    className="rounded-md bg-[#DBEAFE] px-1.5 py-0.5 text-[10px] font-semibold text-[#2563EB]"
                                  >
                                    {WEEK_DAYS.find((w) => w.value === d)?.label ?? d}
                                  </span>
                                ))}
                              </div>
                            </td>
                            <td className="px-3 py-2">
                              <input
                                type="number"
                                min={1}
                                max={30}
                                value={row.delivery_days_business}
                                onChange={(e) =>
                                  updateImportRow(i, { delivery_days_business: Number(e.target.value) })
                                }
                                className="w-14 rounded-lg border border-[#DBEAFE] bg-white px-2 py-1 text-center text-xs text-[#0F172A] focus:border-[#2563EB] focus:outline-none"
                              />
                            </td>
                            <td className="px-3 py-2">
                              <input
                                type="time"
                                value={row.cutoff_time}
                                onChange={(e) =>
                                  updateImportRow(i, { cutoff_time: e.target.value })
                                }
                                className="rounded-lg border border-[#DBEAFE] bg-white px-2 py-1 text-xs text-[#0F172A] focus:border-[#2563EB] focus:outline-none"
                              />
                            </td>
                            <td className="px-3 py-2">
                              <input
                                type="number"
                                min={0}
                                step={0.01}
                                value={row.minimum_order_cents / 100}
                                onChange={(e) =>
                                  updateImportRow(i, {
                                    minimum_order_cents: Math.round(Number(e.target.value) * 100),
                                  })
                                }
                                className="w-20 rounded-lg border border-[#DBEAFE] bg-white px-2 py-1 text-xs text-[#0F172A] focus:border-[#2563EB] focus:outline-none"
                              />
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {/* Ações */}
                  <div className="mt-3 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <Button
                        size="sm"
                        loading={importConfirming}
                        onClick={confirmRegionImport}
                      >
                        Confirmar importação ({importRows.length})
                      </Button>
                      <button
                        onClick={() => {
                          setImportRows(null);
                          setImportSummary(null);
                          setImportMsg("");
                        }}
                        className="text-sm text-slate-400 hover:text-slate-600"
                      >
                        Cancelar
                      </button>
                    </div>
                    <SaveMsg msg={importMsg} />
                  </div>
                </div>
              )}
            </div>
          )}
        </Section>

        {/* ── 3. Formas de pagamento ───────────────────────────────────────── */}
        <Section title="Formas de pagamento">
          <div className="space-y-3">
            <div>
              <p className="mb-2 text-xs font-medium text-slate-500">
                Métodos aceitos
              </p>
              <div className="flex flex-wrap gap-2">
                {PAYMENT_OPTIONS.map(({ value, label }) => {
                  const checked = paymentForm.payment_methods.includes(value);
                  return (
                    <button
                      key={value}
                      type="button"
                      disabled={!isAdmin}
                      onClick={() =>
                        setPaymentForm((p) => ({
                          ...p,
                          payment_methods: checked
                            ? p.payment_methods.filter((m) => m !== value)
                            : [...p.payment_methods, value],
                        }))
                      }
                      className={[
                        "rounded-xl px-4 py-2 text-sm font-medium transition-colors disabled:opacity-50",
                        checked
                          ? "bg-[#2563EB] text-white"
                          : "border border-[#DBEAFE] bg-[#F5F7FB] text-slate-600 hover:bg-[#EFF6FF]",
                      ].join(" ")}
                    >
                      {label}
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <p className="mb-2 text-xs font-medium text-slate-500">
                Prazos de pagamento oferecidos
              </p>
              <div className="flex flex-wrap gap-2">
                {[0, 7, 14, 28, 35, 42].map((days) => {
                  const checked = paymentForm.payment_terms_days.includes(days);
                  return (
                    <button
                      key={days}
                      type="button"
                      disabled={!isAdmin}
                      onClick={() =>
                        setPaymentForm((p) => ({
                          ...p,
                          payment_terms_days: checked
                            ? p.payment_terms_days.filter((d) => d !== days)
                            : [...p.payment_terms_days, days].sort((a, b) => a - b),
                        }))
                      }
                      className={[
                        "rounded-xl px-4 py-2 text-sm font-medium transition-colors disabled:opacity-50",
                        checked
                          ? "bg-[#2563EB] text-white"
                          : "border border-[#DBEAFE] bg-[#F5F7FB] text-slate-600 hover:bg-[#EFF6FF]",
                      ].join(" ")}
                    >
                      {days === 0 ? "À vista" : `${days} dias`}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {isAdmin && (
            <div className="mt-4 flex items-center justify-between">
              <Button size="sm" loading={paymentSaving} onClick={savePayment}>
                Salvar formas de pagamento
              </Button>
              <SaveMsg msg={paymentMsg} />
            </div>
          )}
        </Section>

        {/* ── 4. Critério de crédito ───────────────────────────────────────── */}
        <Section title="Critério de análise de crédito">
          <p className="mb-4 text-sm text-slate-500">
            Define quando um cliente é aprovado automaticamente para fazer pedidos. Scores são consultados via bureau de crédito (Serasa/Boa Vista).
          </p>

          {/* Toggle padrão vs personalizado */}
          <div className="mb-4 overflow-hidden rounded-2xl border border-[#DBEAFE]">
            <button
              type="button"
              disabled={!isAdmin}
              onClick={() => setCreditForm((p) => ({ ...p, use_platform_default: true }))}
              className={[
                "flex w-full items-start gap-3 px-4 py-4 text-left transition-colors disabled:opacity-50",
                creditForm.use_platform_default
                  ? "bg-[#EFF6FF]"
                  : "bg-white hover:bg-[#F5F7FB]",
              ].join(" ")}
            >
              <div className={[
                "mt-0.5 h-4 w-4 shrink-0 rounded-full border-2 transition-colors",
                creditForm.use_platform_default
                  ? "border-[#2563EB] bg-[#2563EB]"
                  : "border-slate-300 bg-white",
              ].join(" ")} />
              <div>
                <p className="font-bold text-[#0F172A]">Usar critério padrão da plataforma</p>
                <p className="mt-0.5 text-xs text-slate-500">
                  Score ≥ 500 · Sem restrições graves · CNPJ ativo há ≥ 6 meses
                </p>
              </div>
            </button>

            <div className="border-t border-[#DBEAFE]" />

            <button
              type="button"
              disabled={!isAdmin}
              onClick={() => setCreditForm((p) => ({ ...p, use_platform_default: false }))}
              className={[
                "flex w-full items-start gap-3 px-4 py-4 text-left transition-colors disabled:opacity-50",
                !creditForm.use_platform_default
                  ? "bg-[#EFF6FF]"
                  : "bg-white hover:bg-[#F5F7FB]",
              ].join(" ")}
            >
              <div className={[
                "mt-0.5 h-4 w-4 shrink-0 rounded-full border-2 transition-colors",
                !creditForm.use_platform_default
                  ? "border-[#2563EB] bg-[#2563EB]"
                  : "border-slate-300 bg-white",
              ].join(" ")} />
              <div>
                <p className="font-bold text-[#0F172A]">Definir meu próprio critério</p>
                <p className="mt-0.5 text-xs text-slate-500">
                  Configure o score mínimo, tolerância a restrições e tempo mínimo de CNPJ
                </p>
              </div>
            </button>
          </div>

          {/* Critério personalizado */}
          {!creditForm.use_platform_default && (
            <div className="space-y-5 rounded-2xl border border-[#DBEAFE] bg-[#F5F7FB] p-4">
              <div>
                <label className="mb-1 block text-sm font-medium text-[#0F172A]">
                  Score mínimo para aprovação automática
                  <span className="ml-2 text-xs font-normal text-slate-400">(0 = sem limite, 1000 = máximo)</span>
                </label>
                <div className="flex items-center gap-4">
                  <input
                    type="range"
                    min={0}
                    max={1000}
                    step={50}
                    disabled={!isAdmin}
                    value={creditForm.credit_score_minimum}
                    onChange={(e) => setCreditForm((p) => ({ ...p, credit_score_minimum: Number(e.target.value) }))}
                    className="flex-1 accent-[#2563EB] disabled:opacity-50"
                  />
                  <input
                    type="number"
                    min={0}
                    max={1000}
                    disabled={!isAdmin}
                    value={creditForm.credit_score_minimum}
                    onChange={(e) => setCreditForm((p) => ({ ...p, credit_score_minimum: Number(e.target.value) }))}
                    className="w-20 rounded-xl border border-[#DBEAFE] bg-white px-3 py-1.5 text-center text-sm font-bold text-[#2563EB] focus:border-[#2563EB] focus:outline-none disabled:opacity-50"
                  />
                </div>
                <p className="mt-1 text-xs text-slate-400">
                  Score &lt; {creditForm.credit_score_minimum} → aprovação manual pelo seu time
                </p>
              </div>

              <div>
                <p className="mb-2 text-sm font-medium text-[#0F172A]">
                  Aceitar clientes com restrições no bureau?
                </p>
                <div className="flex gap-3">
                  {[true, false].map((v) => (
                    <button
                      key={String(v)}
                      type="button"
                      disabled={!isAdmin}
                      onClick={() => setCreditForm((p) => ({ ...p, credit_accepts_restrictions: v }))}
                      className={[
                        "rounded-xl px-5 py-2 text-sm font-medium transition-colors disabled:opacity-50",
                        creditForm.credit_accepts_restrictions === v
                          ? "bg-[#2563EB] text-white"
                          : "border border-[#DBEAFE] bg-white text-slate-600 hover:bg-[#EFF6FF]",
                      ].join(" ")}
                    >
                      {v ? "Sim" : "Não"}
                    </button>
                  ))}
                </div>
                <p className="mt-1 text-xs text-slate-400">
                  Restrição = protestos, pendências financeiras ou CNPJ inapto
                </p>
              </div>

              <div>
                <p className="mb-2 text-sm font-medium text-[#0F172A]">
                  Tempo mínimo de CNPJ ativo
                </p>
                <div className="flex flex-wrap gap-2">
                  {CNPJ_MONTHS_OPTIONS.map(({ value, label }) => (
                    <button
                      key={value}
                      type="button"
                      disabled={!isAdmin}
                      onClick={() => setCreditForm((p) => ({ ...p, credit_min_cnpj_months: value }))}
                      className={[
                        "rounded-xl px-4 py-2 text-sm font-medium transition-colors disabled:opacity-50",
                        creditForm.credit_min_cnpj_months === value
                          ? "bg-[#2563EB] text-white"
                          : "border border-[#DBEAFE] bg-white text-slate-600 hover:bg-[#EFF6FF]",
                      ].join(" ")}
                    >
                      {label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {isAdmin && (
            <div className="mt-4 flex items-center justify-between">
              <Button size="sm" loading={creditSaving} onClick={saveCredit}>
                Salvar critério de crédito
              </Button>
              <SaveMsg msg={creditMsg} />
            </div>
          )}
        </Section>

        {/* ── 5. Catálogo de produtos ──────────────────────────────────────── */}
        <Section title="Catálogo de produtos">
          <div className="mb-4 flex flex-wrap gap-4">
            <div className="flex-1 min-w-[120px] rounded-2xl bg-[#EFF6FF] px-4 py-3 text-center">
              <p className="text-3xl font-semibold text-[#2563EB]">{summary?.active ?? 0}</p>
              <p className="mt-0.5 text-xs font-bold uppercase tracking-wide text-[#2563EB]/70">
                ativos
              </p>
            </div>
            <div className="flex-1 min-w-[120px] rounded-2xl bg-[#F5F7FB] px-4 py-3 text-center">
              <p className="text-3xl font-semibold text-slate-400">{summary?.inactive ?? 0}</p>
              <p className="mt-0.5 text-xs font-bold uppercase tracking-wide text-slate-400">
                inativos
              </p>
            </div>
            <div className="flex-1 min-w-[120px] rounded-2xl bg-[#F5F7FB] px-4 py-3 text-center">
              <p className="text-sm font-bold text-[#0F172A]">
                {formatDate(summary?.last_updated_at ?? null)}
              </p>
              <p className="mt-0.5 text-xs font-bold uppercase tracking-wide text-slate-400">
                última atualização
              </p>
            </div>
          </div>

          <Link href="/painel/produtos">
            <Button fullWidth variant="secondary">
              Gerenciar catálogo de produtos →
            </Button>
          </Link>
        </Section>

        {/* ═══════════════ SEÇÃO ERP ═══════════════ */}
        <Section title="Integração ERP" subtitle="Webhook de saída e API key para sistemas externos">
          <div className="flex items-center justify-between mb-5">
            {erpConfig?.is_enterprise ? (
              <span className="rounded-full bg-[#22C55E]/10 px-3 py-1 text-xs font-bold text-[#22C55E]">Enterprise ativo</span>
            ) : (
              <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-bold text-slate-500">🔒 Plano Enterprise</span>
            )}
          </div>

          {!erpConfig?.is_enterprise ? (
            <div className="rounded-xl border border-[#DBEAFE] bg-[#F5F7FB] p-6 text-center">
              <p className="text-2xl">🔒</p>
              <p className="mt-2 font-bold text-[#0F172A]">Disponível no plano Enterprise</p>
              <p className="mt-1 text-sm text-slate-500 max-w-xs mx-auto">
                Conecte seu ERP à plataforma via webhook e API key para sincronizar pedidos automaticamente.
              </p>
            </div>
          ) : (
            <div className="space-y-6">

              {/* Toggle + URL + Secret */}
              <div className="flex flex-col gap-4">
                <div className="flex items-center justify-between rounded-xl border border-[#DBEAFE] bg-[#F5F7FB] px-4 py-3">
                  <div>
                    <p className="text-sm font-medium text-[#0F172A]">Webhook ativo</p>
                    <p className="text-xs text-slate-500">Disparar POST ao ERP quando um pedido for recebido</p>
                  </div>
                  <button
                    onClick={() => setErpForm((f) => ({ ...f, webhook_enabled: !f.webhook_enabled }))}
                    className={`relative h-6 w-11 rounded-full transition-colors ${erpForm.webhook_enabled ? "bg-[#22C55E]" : "bg-slate-300"}`}
                  >
                    <span className={`absolute top-0.5 left-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform ${erpForm.webhook_enabled ? "translate-x-5" : "translate-x-0"}`} />
                  </button>
                </div>

                <div className="flex flex-col gap-1">
                  <label className="text-sm font-medium text-[#0F172A]">URL do webhook</label>
                  <input
                    type="url"
                    value={erpForm.webhook_url}
                    onChange={(e) => setErpForm((f) => ({ ...f, webhook_url: e.target.value }))}
                    placeholder="https://seu-erp.com.br/webhooks/hubby"
                    className="w-full rounded-xl border border-[#DBEAFE] bg-white px-3 py-2.5 text-sm text-[#0F172A] placeholder:text-slate-400 focus:border-[#2563EB] focus:outline-none focus:ring-2 focus:ring-[#DBEAFE]"
                  />
                </div>

                <div className="flex flex-col gap-1">
                  <label className="text-sm font-medium text-[#0F172A]">Secret do webhook</label>
                  <input
                    type="password"
                    value={erpForm.webhook_secret}
                    onChange={(e) => setErpForm((f) => ({ ...f, webhook_secret: e.target.value }))}
                    placeholder={erpConfig.webhook_secret_hint ? `Atual: ${erpConfig.webhook_secret_hint}` : "Defina um secret"}
                    className="w-full rounded-xl border border-[#DBEAFE] bg-white px-3 py-2.5 text-sm text-[#0F172A] placeholder:text-slate-400 focus:border-[#2563EB] focus:outline-none focus:ring-2 focus:ring-[#DBEAFE]"
                  />
                  <p className="text-xs text-slate-400">Enviado como <code className="rounded bg-slate-100 px-1">X-Hubby-Signature: sha256=&lt;hmac&gt;</code> — deixe em branco para manter o atual</p>
                </div>

                {erpMsg && (
                  <p className={`text-sm font-medium ${erpMsg.includes("sucesso") ? "text-[#22C55E]" : "text-red-600"}`}>{erpMsg}</p>
                )}

                <div className="flex gap-3">
                  <Button variant="primary" size="sm" loading={erpSaving} onClick={saveErpConfig}>
                    Salvar configuração
                  </Button>
                  <Button
                    variant="secondary"
                    size="sm"
                    loading={erpTesting}
                    disabled={!erpConfig.webhook_url && !erpForm.webhook_url}
                    onClick={testWebhook}
                  >
                    Testar webhook
                  </Button>
                </div>

                {erpTestResult && (
                  <div className={`rounded-xl px-4 py-3 text-sm ${erpTestResult.ok ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"}`}>
                    {erpTestResult.ok
                      ? `✓ Webhook recebido com sucesso (HTTP ${erpTestResult.status_code})`
                      : `✗ Falha — ${erpTestResult.error_message ?? `HTTP ${erpTestResult.status_code}`}`}
                  </div>
                )}
              </div>

              <div className="h-px bg-[#DBEAFE]" />

              {/* API Key */}
              <div>
                <h3 className="mb-1 text-sm font-bold text-[#0F172A]">API Key</h3>
                <p className="mb-3 text-xs text-slate-500">
                  Use para autenticar chamadas ao endpoint{" "}
                  <code className="rounded bg-slate-100 px-1">POST /api/integrations/erp/orders</code>
                </p>

                {newApiKey ? (
                  <div className="rounded-xl border border-[#22C55E]/30 bg-[#22C55E]/5 p-4">
                    <p className="mb-2 text-xs font-bold text-[#22C55E]">✓ Nova chave gerada — guarde agora, não será exibida novamente:</p>
                    <div className="flex items-center gap-2">
                      <code className="flex-1 break-all rounded-lg border border-[#DBEAFE] bg-white px-3 py-2 font-mono text-xs text-[#0F172A]">
                        {newApiKey}
                      </code>
                      <button
                        onClick={() => { if (newApiKey) navigator.clipboard.writeText(newApiKey); }}
                        className="shrink-0 rounded-lg border border-[#DBEAFE] bg-white px-3 py-2 text-xs font-bold text-slate-600 hover:bg-[#F5F7FB]"
                      >
                        Copiar
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center gap-3">
                    <div className="flex-1 rounded-xl border border-[#DBEAFE] bg-[#F5F7FB] px-3 py-2.5 text-sm text-slate-500">
                      {erpConfig.has_api_key ? "••••••••••••••••••••••••••••••••" : "Nenhuma chave gerada"}
                    </div>
                    <Button variant="secondary" size="sm" loading={generatingKey} onClick={generateApiKey}>
                      {erpConfig.has_api_key ? "Gerar nova" : "Gerar chave"}
                    </Button>
                  </div>
                )}

                {erpConfig.has_api_key && !newApiKey && (
                  <p className="mt-2 text-xs text-amber-600">⚠ Gerar uma nova chave invalida a anterior imediatamente.</p>
                )}
              </div>

              <div className="h-px bg-[#DBEAFE]" />

              {/* Log */}
              <div>
                <h3 className="mb-3 text-sm font-bold text-[#0F172A]">Log de requisições</h3>
                {webhookLogs.length === 0 ? (
                  <p className="text-sm text-slate-400">Nenhuma requisição registrada ainda.</p>
                ) : (
                  <div className="overflow-hidden rounded-xl border border-[#DBEAFE]">
                    <table className="w-full text-xs">
                      <thead className="border-b border-[#DBEAFE] bg-[#F5F7FB]">
                        <tr>
                          <th className="px-3 py-2 text-left font-bold text-slate-500">Evento</th>
                          <th className="px-3 py-2 text-left font-bold text-slate-500">Status</th>
                          <th className="px-3 py-2 text-left font-bold text-slate-500">Resultado</th>
                          <th className="px-3 py-2 text-left font-bold text-slate-500">Data</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#DBEAFE]">
                        {webhookLogs.slice(0, 10).map((log) => (
                          <tr key={log.id} className="bg-white">
                            <td className="px-3 py-2 font-mono text-[#0F172A]">{log.event}</td>
                            <td className="px-3 py-2">
                              <span className={`rounded-full px-2 py-0.5 font-bold ${log.success ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`}>
                                {log.success ? "✓" : "✗"} {log.status_code ?? "—"}
                              </span>
                            </td>
                            <td className="max-w-[180px] truncate px-3 py-2 text-slate-500">{log.error_message ?? "OK"}</td>
                            <td className="px-3 py-2 text-slate-400">
                              {new Date(log.created_at).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" })}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
                <p className="mt-2 text-xs text-slate-400">Últimas 100 chamadas · atualizado ao recarregar</p>
              </div>

              <div className="flex items-center justify-between rounded-xl border border-[#DBEAFE] bg-[#F5F7FB] px-4 py-3">
                <p className="text-sm text-slate-600">Exemplos de payload e validação de assinatura</p>
                <a href="#" className="text-sm font-bold text-[#2563EB] hover:underline">Ver documentação →</a>
              </div>
            </div>
          )}
        </Section>

      </main>
    </div>
  );
}
